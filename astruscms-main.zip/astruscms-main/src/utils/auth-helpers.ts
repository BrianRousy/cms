
import { User } from '@supabase/supabase-js';

/**
 * Gets the user's display name from Supabase User object
 * Tries to get it from user_metadata.full_name first,
 * then falls back to email or a default value
 */
export const getUserDisplayName = (user: User | null): string => {
  if (!user) return 'Guest';
  
  // Try to get name from user_metadata
  const fullName = user.user_metadata?.full_name || '';
  if (fullName) return fullName;
  
  // Fall back to email without domain
  if (user.email) {
    return user.email.split('@')[0];
  }
  
  return 'User';
};

/**
 * Gets the user's avatar URL or returns null
 */
export const getUserAvatar = (user: User | null): string | null => {
  if (!user) return null;
  
  return user.user_metadata?.avatar_url || null;
};

/**
 * Gets user initials from their name or email
 */
export const getUserInitials = (user: User | null): string => {
  const name = getUserDisplayName(user);
  
  if (!name || name === 'Guest' || name === 'User') {
    return 'U';
  }
  
  // If it's an email without domain that was returned
  if (name.includes('@')) {
    return name[0].toUpperCase();
  }
  
  // Get initials from full name
  return name
    .split(' ')
    .map(part => part[0])
    .join('')
    .toUpperCase()
    .substring(0, 2);
};
