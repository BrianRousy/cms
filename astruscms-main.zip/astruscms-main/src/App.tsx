
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import Dashboard from "./pages/Dashboard";
import Cases from "./pages/Cases";
import Calendar from "./pages/Calendar";
import Documents from "./pages/Documents";
import Clients from "./pages/Clients";
import ClientPortal from "./pages/ClientPortal";
import TimeTracking from "./pages/TimeTracking";
import Billing from "./pages/Billing";
import Reports from "./pages/Reports";
import Settings from "./pages/Settings";
import Help from "./pages/Help";
import LegalAssistant from "./pages/LegalAssistant";
import Tasks from "./pages/Tasks";
import LegalLibrary from "./pages/LegalLibrary";
import LegalResearch from "./pages/LegalResearch";
import PrecedentsDB from "./pages/PrecedentsDB";
import Workflow from "./pages/Workflow";
import Security from "./pages/Security";
import HumanResources from "./pages/HumanResources";
import Index from "./pages/Index";
import Login from "./pages/Login";
import NotFound from "./pages/NotFound";
import TermsOfService from "./pages/TermsOfService";
import PrivacyPolicy from "./pages/PrivacyPolicy";

import { AuthProvider, useAuth } from "./context/auth-context";
import Layout from "./components/layout";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ReactQueryDevtools } from "@tanstack/react-query-devtools";
import { Toaster } from "@/components/ui/toaster";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 60 * 1000, // 1 minute
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

// Protected route component
function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  
  if (loading) {
    return <div className="flex items-center justify-center h-screen">
      <div className="animate-spin w-10 h-10 border-t-2 border-purple-500 rounded-full"></div>
    </div>;
  }
  
  if (!user) {
    return <Navigate to="/login" />;
  }
  
  return <>{children}</>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/login" element={<Login />} />
            <Route path="/dashboard" element={<ProtectedRoute><Layout><Dashboard /></Layout></ProtectedRoute>} />
            <Route path="/cases" element={<ProtectedRoute><Layout><Cases /></Layout></ProtectedRoute>} />
            <Route path="/calendar" element={<ProtectedRoute><Layout><Calendar /></Layout></ProtectedRoute>} />
            <Route path="/documents" element={<ProtectedRoute><Layout><Documents /></Layout></ProtectedRoute>} />
            <Route path="/clients" element={<ProtectedRoute><Layout><Clients /></Layout></ProtectedRoute>} />
            <Route path="/client-portal" element={<ProtectedRoute><Layout><ClientPortal /></Layout></ProtectedRoute>} />
            <Route path="/time-tracking" element={<ProtectedRoute><Layout><TimeTracking /></Layout></ProtectedRoute>} />
            <Route path="/billing" element={<ProtectedRoute><Layout><Billing /></Layout></ProtectedRoute>} />
            <Route path="/reports" element={<ProtectedRoute><Layout><Reports /></Layout></ProtectedRoute>} />
            <Route path="/settings" element={<ProtectedRoute><Layout><Settings /></Layout></ProtectedRoute>} />
            <Route path="/help" element={<ProtectedRoute><Layout><Help /></Layout></ProtectedRoute>} />
            <Route path="/legal-assistant" element={<ProtectedRoute><Layout><LegalAssistant /></Layout></ProtectedRoute>} />
            <Route path="/tasks" element={<ProtectedRoute><Layout><Tasks /></Layout></ProtectedRoute>} />
            <Route path="/legal-library" element={<ProtectedRoute><Layout><LegalLibrary /></Layout></ProtectedRoute>} />
            <Route path="/search" element={<ProtectedRoute><Layout><LegalResearch /></Layout></ProtectedRoute>} />
            <Route path="/database" element={<ProtectedRoute><Layout><PrecedentsDB /></Layout></ProtectedRoute>} />
            <Route path="/workflow" element={<ProtectedRoute><Layout><Workflow /></Layout></ProtectedRoute>} />
            <Route path="/security" element={<ProtectedRoute><Layout><Security /></Layout></ProtectedRoute>} />
            <Route path="/human-resources" element={<ProtectedRoute><Layout><HumanResources /></Layout></ProtectedRoute>} />
            <Route path="/terms-of-service" element={<TermsOfService />} />
            <Route path="/privacy-policy" element={<PrivacyPolicy />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
          <Toaster />
        </Router>
      </AuthProvider>
      {process.env.NODE_ENV === "development" && (
        <ReactQueryDevtools initialIsOpen={false} position="bottom" />
      )}
    </QueryClientProvider>
  );
}

export default App;
