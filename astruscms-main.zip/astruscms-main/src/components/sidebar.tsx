
import React, { useState, useEffect } from "react";
import { NavLink, useLocation } from "react-router-dom";
import {
  LayoutDashboard,
  Briefcase,
  Calendar,
  FileText,
  Users,
  Clock,
  BarChart,
  Settings,
  HelpCircle,
  CheckSquare,
  Search,
  BookOpen,
  Database,
  MessageSquare,
  Shield,
  CreditCard,
  Bot,
  Brain,
  Workflow,
  User,
  Receipt,
  FileUp,
  Scale,
  Home,
  Menu,
  X,
  Gavel,
  BookCopy,
  ChevronRight,
  ChevronLeft
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/context/auth-context";
import { motion } from "framer-motion";
import { useIsMobile } from "@/hooks/use-mobile";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

const SidebarLink = ({
  to,
  icon: Icon,
  children,
  badgeCount,
  onClick,
  isCollapsed,
}: {
  to: string;
  icon: React.ElementType;
  children: React.ReactNode;
  badgeCount?: number;
  onClick?: () => void;
  isCollapsed?: boolean;
}) => {
  const location = useLocation();
  const isActive = location.pathname === to;
  
  const content = (
    <NavLink
      to={to}
      className={({ isActive }) =>
        cn(
          "flex items-center gap-3 rounded-lg px-3 py-2 text-gray-500 transition-all hover:text-navy relative group",
          isActive ? "bg-navy bg-opacity-10 text-navy font-medium" : ""
        )
      }
      onClick={onClick}
    >
      <Icon className={cn("h-5 w-5", isActive ? "text-navy" : "text-gray-500 group-hover:text-navy")} />
      {!isCollapsed && <span>{children}</span>}
      {badgeCount && !isCollapsed && (
        <div className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
          {badgeCount}
        </div>
      )}
      {badgeCount && isCollapsed && (
        <div className="absolute -right-1 top-0 bg-red-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">
          {badgeCount}
        </div>
      )}
      {isActive && (
        <motion.div 
          layoutId="sidebar-highlight"
          className="absolute left-0 top-0 h-full w-1 bg-navy rounded-r-md"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.2 }}
        />
      )}
    </NavLink>
  );

  if (isCollapsed) {
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            {content}
          </TooltipTrigger>
          <TooltipContent side="right">
            {children}
            {badgeCount ? ` (${badgeCount})` : ''}
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }

  return content;
};

const SidebarSection = ({ 
  title, 
  children, 
  defaultOpen = true,
  isCollapsed = false
}: { 
  title: string, 
  children: React.ReactNode, 
  defaultOpen?: boolean,
  isCollapsed?: boolean
}) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);
  
  useEffect(() => {
    // When sidebar is collapsed, auto-close all sections
    if (isCollapsed) {
      setIsOpen(false);
    } else {
      setIsOpen(defaultOpen);
    }
  }, [isCollapsed, defaultOpen]);

  if (isCollapsed) {
    return (
      <div className="px-2 py-1">
        <div className="mb-1 border-t border-gray-200 pt-2"></div>
        {children}
      </div>
    );
  }
  
  return (
    <div className="px-3 py-2">
      <div 
        className="mb-2 px-4 text-lg font-semibold tracking-tight flex items-center justify-between cursor-pointer"
        onClick={() => setIsOpen(!isOpen)}
      >
        <span>{title}</span>
        <motion.div
          animate={{ rotate: isOpen ? 0 : -90 }}
          transition={{ duration: 0.2 }}
        >
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 6L8 10L4 6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </motion.div>
      </div>
      <motion.div
        animate={{ 
          height: isOpen ? "auto" : 0,
          opacity: isOpen ? 1 : 0,
        }}
        transition={{ duration: 0.3 }}
        className="space-y-1 overflow-hidden"
      >
        {children}
      </motion.div>
    </div>
  );
};

interface SidebarContentProps {
  newMessages: number;
  newTasks: number;
  closeMobileSidebar?: () => void;
  isCollapsed?: boolean;
}

const SidebarContent = ({ newMessages, newTasks, closeMobileSidebar, isCollapsed }: SidebarContentProps) => (
  <>
    <div className={cn(
      "px-3 py-2 mb-6",
      isCollapsed ? "flex justify-center" : ""
    )}>
      <div className={cn(
        "flex items-center",
        isCollapsed ? "flex-col space-y-2" : "space-x-2"
      )}>
        <div className="bg-navy text-white p-2 rounded-lg">
          <Scale className="h-5 w-5" />
        </div>
        {!isCollapsed && (
          <div>
            <h1 className="text-2xl font-bold text-navy">Astrus CMS</h1>
            <p className="text-xs text-gray-500">Case Management System</p>
          </div>
        )}
      </div>
    </div>
    
    <div className="space-y-1">
      <SidebarSection title="Main" isCollapsed={isCollapsed}>
        <SidebarLink to="/dashboard" icon={LayoutDashboard} onClick={closeMobileSidebar} isCollapsed={isCollapsed}>
          Dashboard
        </SidebarLink>
        <SidebarLink to="/cases" icon={Briefcase} onClick={closeMobileSidebar} isCollapsed={isCollapsed}>
          Cases
        </SidebarLink>
        <SidebarLink to="/tasks" icon={CheckSquare} badgeCount={newTasks} onClick={closeMobileSidebar} isCollapsed={isCollapsed}>
          Tasks
        </SidebarLink>
        <SidebarLink to="/calendar" icon={Calendar} onClick={closeMobileSidebar} isCollapsed={isCollapsed}>
          Calendar
        </SidebarLink>
        <SidebarLink to="/documents" icon={FileText} onClick={closeMobileSidebar} isCollapsed={isCollapsed}>
          Documents
        </SidebarLink>
      </SidebarSection>
      
      <SidebarSection title="Client Management" isCollapsed={isCollapsed}>
        <SidebarLink to="/clients" icon={Users} onClick={closeMobileSidebar} isCollapsed={isCollapsed}>
          Clients
        </SidebarLink>
        <SidebarLink to="/client-portal" icon={MessageSquare} badgeCount={newMessages} onClick={closeMobileSidebar} isCollapsed={isCollapsed}>
          Client Portal
        </SidebarLink>
      </SidebarSection>

      <SidebarSection title="AI Assistant" isCollapsed={isCollapsed}>
        <SidebarLink to="/legal-assistant" icon={Brain} onClick={closeMobileSidebar} isCollapsed={isCollapsed}>
          Legal Assistant
        </SidebarLink>
      </SidebarSection>
      
      <SidebarSection title="Finance" isCollapsed={isCollapsed}>
        <SidebarLink to="/time-tracking" icon={Clock} onClick={closeMobileSidebar} isCollapsed={isCollapsed}>
          Time Tracking
        </SidebarLink>
        <SidebarLink to="/billing" icon={CreditCard} onClick={closeMobileSidebar} isCollapsed={isCollapsed}>
          Billing
        </SidebarLink>
        <SidebarLink to="/reports" icon={BarChart} onClick={closeMobileSidebar} isCollapsed={isCollapsed}>
          Reports
        </SidebarLink>
      </SidebarSection>
      
      <SidebarSection title="Human Resources" isCollapsed={isCollapsed}>
        <SidebarLink to="/human-resources" icon={User} onClick={closeMobileSidebar} isCollapsed={isCollapsed}>
          HR Dashboard
        </SidebarLink>
      </SidebarSection>
      
      <SidebarSection title="Resources" isCollapsed={isCollapsed}>
        <SidebarLink to="/legal-library" icon={BookCopy} onClick={closeMobileSidebar} isCollapsed={isCollapsed}>
          Legal Library
        </SidebarLink>
        <SidebarLink to="/search" icon={Search} onClick={closeMobileSidebar} isCollapsed={isCollapsed}>
          Legal Research
        </SidebarLink>
        <SidebarLink to="/database" icon={Database} onClick={closeMobileSidebar} isCollapsed={isCollapsed}>
          Precedents DB
        </SidebarLink>
        <SidebarLink to="/workflow" icon={Workflow} onClick={closeMobileSidebar} isCollapsed={isCollapsed}>
          Workflow Automation
        </SidebarLink>
      </SidebarSection>
      
      <SidebarSection title="System" isCollapsed={isCollapsed}>
        <SidebarLink to="/security" icon={Shield} onClick={closeMobileSidebar} isCollapsed={isCollapsed}>
          Security & Access
        </SidebarLink>
        <SidebarLink to="/settings" icon={Settings} onClick={closeMobileSidebar} isCollapsed={isCollapsed}>
          Settings
        </SidebarLink>
        <SidebarLink to="/help" icon={HelpCircle} onClick={closeMobileSidebar} isCollapsed={isCollapsed}>
          Help & Support
        </SidebarLink>
      </SidebarSection>

      <SidebarSection title="Legal Documentation" isCollapsed={isCollapsed}>
        <SidebarLink to="/terms-of-service" icon={FileText} onClick={closeMobileSidebar} isCollapsed={isCollapsed}>
          Terms of Service
        </SidebarLink>
        <SidebarLink to="/privacy-policy" icon={Shield} onClick={closeMobileSidebar} isCollapsed={isCollapsed}>
          Privacy Policy
        </SidebarLink>
      </SidebarSection>
    </div>

    {!isCollapsed && (
      <div className="mt-auto">
        <div className="bg-gray-100 rounded-lg p-4 shadow-sm border border-gray-200 m-3">
          <h3 className="text-sm font-medium">Pro Tip</h3>
          <p className="text-xs text-gray-500 mt-1">
            Press <kbd className="px-1 py-0.5 bg-white rounded border text-xs">?</kbd> to view keyboard shortcuts for faster navigation
          </p>
        </div>
      </div>
    )}
  </>
);

const Sidebar = () => {
  const { user } = useAuth();
  const isMobile = useIsMobile();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isCollapsed, setIsCollapsed] = useState(false);
  
  // Notification counts (simulated)
  const newMessages = 3;
  const newTasks = 5;

  const closeMobileSidebar = () => {
    setMobileMenuOpen(false);
  };
  
  if (!user) return null;

  return (
    <>
      {/* Mobile Menu Button */}
      {isMobile && (
        <div className="fixed top-4 left-4 z-40">
          <Button 
            variant="outline" 
            size="icon" 
            className="bg-white border shadow-md"
            onClick={() => setMobileMenuOpen(true)}
          >
            <Menu className="h-5 w-5" />
          </Button>
        </div>
      )}

      {/* Mobile Sidebar */}
      {isMobile && (
        <div 
          className={`fixed inset-0 z-50 bg-black/50 ${mobileMenuOpen ? 'block' : 'hidden'}`}
          onClick={() => setMobileMenuOpen(false)}
        >
          <div 
            className={`fixed inset-y-0 left-0 w-72 bg-white shadow-xl transition-transform transform ${mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}`}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-end p-4">
              <Button variant="ghost" size="icon" onClick={() => setMobileMenuOpen(false)}>
                <X className="h-5 w-5" />
              </Button>
            </div>
            <div className="flex flex-col h-full px-4 py-2 overflow-y-auto">
              <SidebarContent 
                newMessages={newMessages} 
                newTasks={newTasks} 
                closeMobileSidebar={closeMobileSidebar} 
              />
            </div>
          </div>
        </div>
      )}

      {/* Desktop Sidebar */}
      <div 
        className={cn(
          "hidden border-r bg-white shadow-sm md:flex md:fixed md:inset-y-0 z-30 transition-all duration-300 ease-in-out",
          isCollapsed ? "md:w-16 lg:w-20" : "md:w-60 lg:w-72"
        )}
      >
        <div className="flex flex-col h-full px-4 py-6 overflow-y-auto relative">
          {/* Collapse/Expand Button */}
          <Button 
            variant="ghost" 
            size="icon" 
            className="absolute -right-3 top-6 h-6 w-6 bg-white border shadow-sm rounded-full z-10"
            onClick={() => setIsCollapsed(!isCollapsed)}
          >
            {isCollapsed ? (
              <ChevronRight className="h-4 w-4" />
            ) : (
              <ChevronLeft className="h-4 w-4" />
            )}
          </Button>

          <SidebarContent 
            newMessages={newMessages} 
            newTasks={newTasks} 
            isCollapsed={isCollapsed}
          />
        </div>
      </div>
    </>
  );
};

export default Sidebar;
