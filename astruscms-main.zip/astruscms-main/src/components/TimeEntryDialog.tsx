
import React, { useState } from "react";
import { format, differenceInSeconds } from "date-fns";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Calendar as CalendarIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "@/hooks/use-toast";
import { TimeEntry } from "@/services/time-tracking-service";

interface TimeEntryDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (entry: Omit<TimeEntry, 'id' | 'created_at' | 'updated_at'>) => void;
  initialEntry?: Partial<TimeEntry>;
  mode?: 'add' | 'edit';
}

const TimeEntryDialog = ({
  open,
  onOpenChange,
  onSave,
  initialEntry,
  mode = 'add'
}: TimeEntryDialogProps) => {
  const [entry, setEntry] = useState({
    case_id: initialEntry?.case_id || "",
    case_name: initialEntry?.case_name || "",
    task_id: initialEntry?.task_id || "",
    task_name: initialEntry?.task_name || "",
    description: initialEntry?.description || "",
    start_time: initialEntry?.start_time ? new Date(initialEntry.start_time) : new Date(),
    end_time: initialEntry?.end_time ? new Date(initialEntry.end_time) : new Date(),
    billable: initialEntry?.billable !== undefined ? initialEntry.billable : true,
    status: (initialEntry?.status as 'active' | 'completed' | 'billed' | 'unbilled') || "completed",
    duration: initialEntry?.duration || 0,
    billable_amount: initialEntry?.billable_amount || 0,
    user_id: initialEntry?.user_id || "",
  });

  const [hourlyRate, setHourlyRate] = useState(150);

  const calculateBillableAmount = (hours: number) => {
    return Math.round(hours * hourlyRate);
  };

  const handleSubmit = () => {
    const startDateTime = new Date(entry.start_time);
    const endDateTime = new Date(entry.end_time);
    
    const durationInSeconds = differenceInSeconds(endDateTime, startDateTime);
    
    if (durationInSeconds <= 0) {
      toast({
        title: "Invalid Time Range",
        description: "End time must be after start time",
        variant: "destructive"
      });
      return;
    }
    
    // Calculate billable amount based on duration and rate
    const hours = durationInSeconds / 3600;
    const billable_amount = calculateBillableAmount(hours);
    
    onSave({
      ...entry,
      start_time: startDateTime.toISOString(),
      end_time: endDateTime.toISOString(),
      duration: durationInSeconds,
      billable_amount: entry.billable ? billable_amount : 0,
      user_id: entry.user_id || "",
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[525px]">
        <DialogHeader>
          <DialogTitle>{mode === 'add' ? 'Add' : 'Edit'} Time Entry</DialogTitle>
          <DialogDescription>
            {mode === 'add' ? 'Record time spent on a case or task' : 'Update time entry details'}
          </DialogDescription>
        </DialogHeader>
        
        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <Label htmlFor="case">Case</Label>
            <Select 
              value={entry.case_id} 
              onValueChange={(value) => setEntry({
                ...entry, 
                case_id: value,
                case_name: value === "case1" ? "Smith vs. Jones" :
                          value === "case2" ? "ABC Corp Merger" :
                          value === "case3" ? "Estate of Johnson" : ""
              })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select Case" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="case1">Smith vs. Jones</SelectItem>
                <SelectItem value="case2">ABC Corp Merger</SelectItem>
                <SelectItem value="case3">Estate of Johnson</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="grid gap-2">
            <Label htmlFor="task">Task</Label>
            <Select 
              value={entry.task_id} 
              onValueChange={(value) => setEntry({
                ...entry, 
                task_id: value,
                task_name: value === "task1" ? "Document Review" :
                         value === "task2" ? "Client Meeting" :
                         value === "task3" ? "Court Appearance" :
                         value === "task4" ? "Legal Research" : ""
              })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select Task" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="task1">Document Review</SelectItem>
                <SelectItem value="task2">Client Meeting</SelectItem>
                <SelectItem value="task3">Court Appearance</SelectItem>
                <SelectItem value="task4">Legal Research</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="grid gap-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={entry.description}
              onChange={(e) => setEntry({...entry, description: e.target.value})}
              placeholder="Brief description of work done"
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label>Start Time</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant={"outline"}
                    className={cn(
                      "w-full justify-start text-left font-normal",
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {format(entry.start_time, "PPP HH:mm")}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={entry.start_time}
                    onSelect={(date) => date && setEntry({...entry, start_time: date})}
                    initialFocus
                  />
                  <div className="p-3 border-t border-border">
                    <Input
                      type="time"
                      value={format(entry.start_time, "HH:mm")}
                      onChange={(e) => {
                        const [hours, minutes] = e.target.value.split(':').map(Number);
                        const newDate = new Date(entry.start_time);
                        newDate.setHours(hours, minutes);
                        setEntry({...entry, start_time: newDate});
                      }}
                    />
                  </div>
                </PopoverContent>
              </Popover>
            </div>
            
            <div className="grid gap-2">
              <Label>End Time</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant={"outline"}
                    className={cn(
                      "w-full justify-start text-left font-normal",
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {format(entry.end_time, "PPP HH:mm")}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={entry.end_time}
                    onSelect={(date) => date && setEntry({...entry, end_time: date})}
                    initialFocus
                  />
                  <div className="p-3 border-t border-border">
                    <Input
                      type="time"
                      value={format(entry.end_time, "HH:mm")}
                      onChange={(e) => {
                        const [hours, minutes] = e.target.value.split(':').map(Number);
                        const newDate = new Date(entry.end_time);
                        newDate.setHours(hours, minutes);
                        setEntry({...entry, end_time: newDate});
                      }}
                    />
                  </div>
                </PopoverContent>
              </Popover>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label htmlFor="billable">Billable</Label>
              <Select 
                value={entry.billable ? "yes" : "no"} 
                onValueChange={(value) => setEntry({...entry, billable: value === "yes"})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Is this billable?" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="yes">Yes</SelectItem>
                  <SelectItem value="no">No</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="rate">Hourly Rate ($)</Label>
              <Input
                id="rate"
                type="number"
                value={hourlyRate}
                min="0"
                onChange={(e) => {
                  const rate = parseFloat(e.target.value);
                  setHourlyRate(rate);
                  const durationInSeconds = differenceInSeconds(entry.end_time, entry.start_time);
                  const hours = durationInSeconds / 3600;
                  const amount = calculateBillableAmount(hours);
                  setEntry({...entry, billable_amount: amount});
                }}
              />
            </div>
          </div>

          {mode === 'edit' && (
            <div className="grid gap-2">
              <Label htmlFor="status">Status</Label>
              <Select 
                value={entry.status} 
                onValueChange={(value) => setEntry({
                  ...entry, 
                  status: value as 'active' | 'completed' | 'billed' | 'unbilled'
                })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="billed">Billed</SelectItem>
                  <SelectItem value="unbilled">Unbilled</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button 
            onClick={handleSubmit} 
            disabled={!entry.case_name || !entry.task_name}
          >
            {mode === 'add' ? 'Add' : 'Save'} Entry
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default TimeEntryDialog;
