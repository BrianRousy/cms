
import React from 'react';
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";

interface TimeTrackingHeaderProps {
  onAddManualEntry: () => void;
}

const TimeTrackingHeader = ({ onAddManualEntry }: TimeTrackingHeaderProps) => {
  return (
    <div className="flex items-center justify-between">
      <h1 className="text-2xl font-semibold">Time Tracking</h1>
      <Button onClick={onAddManualEntry} className="bg-navy hover:bg-navy/90">
        <Plus className="mr-2 h-4 w-4" />
        Add Manual Entry
      </Button>
    </div>
  );
};

export default TimeTrackingHeader;
