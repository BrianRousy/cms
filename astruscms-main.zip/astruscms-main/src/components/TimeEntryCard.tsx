
import React from "react";
import { format } from "date-fns";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock, Edit, Trash2 } from "lucide-react";
import { TimeEntry } from "@/services/time-tracking-service";

interface TimeEntryCardProps {
  entry: TimeEntry;
  onEdit?: (entry: TimeEntry) => void;
  onDelete?: (id: string) => void;
  isLoading?: boolean;
}

const TimeEntryCard: React.FC<TimeEntryCardProps> = ({ 
  entry, 
  onEdit, 
  onDelete,
  isLoading = false
}) => {
  const calculateBillableAmount = (hours: number, rate: number = 150) => {
    return Math.round(hours * rate);
  };

  // Safely handle the entry data
  const safeEntry = {
    id: entry?.id || '',
    case_name: entry?.case_name || 'Unnamed Case',
    task_name: entry?.task_name || 'Unnamed Task',
    start_time: entry?.start_time || new Date().toISOString(),
    duration: entry?.duration || 0,
    description: entry?.description || '',
    billable: entry?.billable === false ? false : true, // default to true
    billable_amount: entry?.billable_amount || 0
  };

  if (isLoading) {
    return (
      <Card className="animate-pulse">
        <CardContent className="p-4 flex items-center justify-between">
          <div className="flex items-start space-x-4">
            <div className="bg-gray-200 p-2 rounded-md h-9 w-9"></div>
            <div>
              <div className="h-5 bg-gray-200 rounded w-48 mb-2"></div>
              <div className="h-4 bg-gray-200 rounded w-32 mb-2"></div>
              <div className="h-4 bg-gray-200 rounded w-24"></div>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <div className="h-6 bg-gray-200 rounded w-16"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardContent className="p-4 flex items-center justify-between">
        <div className="flex items-start space-x-4">
          <div className="bg-gray-100 p-2 rounded-md">
            <Clock className="h-5 w-5 text-gray-500" />
          </div>
          <div>
            <h3 className="font-medium">{safeEntry.case_name}: {safeEntry.task_name}</h3>
            <p className="text-sm text-gray-500">
              {safeEntry.start_time && format(new Date(safeEntry.start_time), "MMMM d, yyyy")}
              {safeEntry.duration ? `, ${Math.round((safeEntry.duration / 3600) * 10) / 10} hour(s)` : ' (In Progress)'}
            </p>
            {safeEntry.description && (
              <p className="text-sm text-gray-600 mt-1">{safeEntry.description}</p>
            )}
          </div>
        </div>
        <div className="flex items-center space-x-3">
          <Badge className={safeEntry.billable ? "bg-navy" : "bg-gray-500"}>
            ${safeEntry.billable_amount || calculateBillableAmount(
              (safeEntry.duration || 0) / 3600
            )}
          </Badge>
          <div className="flex space-x-1">
            {onEdit && (
              <Button 
                variant="ghost" 
                size="icon"
                title="Edit"
                onClick={() => onEdit(entry)}
              >
                <Edit className="h-4 w-4" />
              </Button>
            )}
            {onDelete && safeEntry.id && (
              <Button 
                variant="ghost" 
                size="icon"
                title="Delete"
                onClick={() => onDelete(safeEntry.id)}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default TimeEntryCard;
