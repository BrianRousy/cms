
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from '@tanstack/react-query';
import { timeTrackingService } from "@/services/time-tracking-service";
import { format, startOfToday, endOfToday, startOfWeek, endOfWeek } from "date-fns";
import { Loader2 } from "lucide-react";

const TimeTrackingStats = () => {
  const { data: todayEntries = [], isLoading: isLoadingToday } = useQuery({
    queryKey: ['timeEntries', 'today-stats'],
    queryFn: async () => {
      const result = await timeTrackingService.getTimeEntriesForPeriod(startOfToday(), endOfToday());
      return Array.isArray(result.data) ? result.data : [];
    },
    refetchOnWindowFocus: true,
    staleTime: 60000 // 1 minute
  });

  const { data: weekEntries = [], isLoading: isLoadingWeek } = useQuery({
    queryKey: ['timeEntries', 'week-stats'],
    queryFn: async () => {
      const result = await timeTrackingService.getTimeEntriesForPeriod(startOfWeek(new Date()), endOfWeek(new Date()));
      return Array.isArray(result.data) ? result.data : [];
    },
    refetchOnWindowFocus: true,
    staleTime: 60000 // 1 minute
  });

  const calculateTotalHours = (entries: any[]) => {
    return entries.reduce((total, entry) => {
      return total + ((entry.duration || 0) / 3600);
    }, 0).toFixed(1);
  };

  const calculateTotalBillable = (entries: any[]) => {
    return entries.reduce((total, entry) => {
      return total + (entry.billable_amount || 0);
    }, 0).toFixed(2);
  };

  const todayHours = calculateTotalHours(todayEntries);
  const weekHours = calculateTotalHours(weekEntries);
  const todayBillable = calculateTotalBillable(todayEntries);
  const weekBillable = calculateTotalBillable(weekEntries);
  
  return (
    <div className="grid gap-4 md:grid-cols-4">
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Today's Hours</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoadingToday ? (
            <div className="flex items-center">
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              <span>Loading...</span>
            </div>
          ) : (
            <>
              <div className="text-2xl font-bold">{todayHours}</div>
              <p className="text-xs text-gray-500">
                hours tracked today
              </p>
            </>
          )}
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Weekly Hours</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoadingWeek ? (
            <div className="flex items-center">
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              <span>Loading...</span>
            </div>
          ) : (
            <>
              <div className="text-2xl font-bold">{weekHours}</div>
              <p className="text-xs text-gray-500">
                hours this week
              </p>
            </>
          )}
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Today's Billable</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoadingToday ? (
            <div className="flex items-center">
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              <span>Loading...</span>
            </div>
          ) : (
            <>
              <div className="text-2xl font-bold">${todayBillable}</div>
              <p className="text-xs text-gray-500">
                billable amount today
              </p>
            </>
          )}
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Weekly Billable</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoadingWeek ? (
            <div className="flex items-center">
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              <span>Loading...</span>
            </div>
          ) : (
            <>
              <div className="text-2xl font-bold">${weekBillable}</div>
              <p className="text-xs text-gray-500">
                billable amount this week
              </p>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default TimeTrackingStats;
