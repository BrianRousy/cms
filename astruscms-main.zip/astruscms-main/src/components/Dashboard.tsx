
import React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { apiService } from "@/services/api-service";
import { format } from "date-fns";

const Dashboard = () => {
  // Get upcoming cases
  const { data: casesResponse, isLoading: isLoadingCases } = useQuery({
    queryKey: ['dashboard-cases'],
    queryFn: () => apiService.cases.getCases({ status: 'open' }),
  });
  
  // Extract cases array from response
  const cases = Array.isArray(casesResponse) ? casesResponse : (casesResponse?.data || []);

  // Get calendar events
  const { data: eventsResponse, isLoading: isLoadingEvents } = useQuery({
    queryKey: ['dashboard-events'],
    queryFn: () => apiService.calendar.getEvents(),
  });
  
  // Extract events array from response
  const events = Array.isArray(eventsResponse) ? eventsResponse : (eventsResponse?.data || []);
  
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">Dashboard</h1>
        <p className="text-muted-foreground">Overview of your legal practice</p>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Upcoming Cases</CardTitle>
            <CardDescription>Cases that need your attention</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoadingCases ? (
              <p>Loading cases...</p>
            ) : cases.length > 0 ? (
              <ul>
                {cases.map((caseItem) => (
                  <li key={caseItem.id} className="py-2 border-b">
                    {caseItem.title} - {caseItem.client_name}
                  </li>
                ))}
              </ul>
            ) : (
              <p>No upcoming cases.</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Calendar Events</CardTitle>
            <CardDescription>Upcoming events and deadlines</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoadingEvents ? (
              <p>Loading events...</p>
            ) : events.length > 0 ? (
              <ul>
                {events.map((event) => (
                  <li key={event.id} className="py-2 border-b">
                    <div className="flex items-center space-x-2">
                      <Calendar className="h-4 w-4" />
                      <span>{event.title} - {format(new Date(event.start_time), "MM/dd/yyyy")}</span>
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <p>No upcoming events.</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>Frequently used actions</CardDescription>
          </CardHeader>
          <CardContent>
            <ul>
              <li className="py-2 border-b">Create New Case</li>
              <li className="py-2 border-b">Schedule Client Meeting</li>
              <li className="py-2 border-b">Upload Document</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;
