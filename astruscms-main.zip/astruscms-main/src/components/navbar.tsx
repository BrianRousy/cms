import React, { useState } from "react";
import { Link } from "react-router-dom";
import {
  Search,
  Bell,
  Calendar,
  FileText,
  BarChart,
  User,
  Settings,
  LogOut,
  Menu,
  Scale,
  X
} from "lucide-react";
import { useAuth } from "../context/auth-context";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { getUserDisplayName, getUserInitials } from "@/utils/auth-helpers";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
  SheetClose
} from "@/components/ui/sheet";
import { mockNotifications } from "@/lib/mock-data";

const Navbar = () => {
  const { user, logout } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  const [showNotifications, setShowNotifications] = useState(false);

  const unreadNotifications = mockNotifications?.filter(n => !n.read) || [];
  const userDisplayName = getUserDisplayName(user);
  const userInitials = getUserInitials(user);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Implement search functionality
    console.log("Searching for:", searchTerm);
  }

  return (
    <header className="border-b border-gray-200 bg-white sticky top-0 z-20 shadow-sm">
      <div className="flex h-16 items-center px-4 md:px-6">
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="ghost" className="md:hidden mr-2" size="icon">
              <Menu className="h-5 w-5" />
              <span className="sr-only">Toggle menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-[240px] sm:w-[300px] md:hidden">
            <SheetHeader className="mb-4">
              <SheetTitle>
                <Link to="/" className="flex items-center gap-2">
                  <div className="bg-navy text-white p-1.5 rounded-md">
                    <Scale className="h-5 w-5" />
                  </div>
                  <span className="text-xl font-bold text-navy">Astrus CMS</span>
                </Link>
              </SheetTitle>
            </SheetHeader>
            <div className="flex flex-col space-y-3 py-4">
              <Link to="/dashboard" className="px-2 py-2 hover:bg-gray-100 rounded-md flex items-center gap-2">
                <span>Dashboard</span>
              </Link>
              <Link to="/cases" className="px-2 py-2 hover:bg-gray-100 rounded-md flex items-center gap-2">
                <span>Cases</span>
              </Link>
              <Link to="/calendar" className="px-2 py-2 hover:bg-gray-100 rounded-md flex items-center gap-2">
                <span>Calendar</span>
              </Link>
              <Link to="/documents" className="px-2 py-2 hover:bg-gray-100 rounded-md flex items-center gap-2">
                <span>Documents</span>
              </Link>
              <Link to="/clients" className="px-2 py-2 hover:bg-gray-100 rounded-md flex items-center gap-2">
                <span>Clients</span>
              </Link>
              <SheetClose asChild>
                <Button variant="outline" className="w-full mt-4" onClick={logout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Log out</span>
                </Button>
              </SheetClose>
            </div>
          </SheetContent>
        </Sheet>
        
        <Link to="/" className="mr-8 hidden md:flex items-center">
          <div className="bg-navy text-white p-1.5 rounded-md mr-2">
            <Scale className="h-5 w-5" />
          </div>
          <span className="text-xl font-bold text-navy">Astrus CMS</span>
        </Link>
        
        <nav className="hidden md:flex items-center space-x-4 lg:space-x-6 mr-auto">
          <Link
            to="/dashboard"
            className="text-sm font-medium transition-colors hover:text-navy"
          >
            Dashboard
          </Link>
          <Link
            to="/cases"
            className="text-sm font-medium transition-colors hover:text-navy"
          >
            Cases
          </Link>
          <Link
            to="/calendar"
            className="text-sm font-medium transition-colors hover:text-navy"
          >
            Calendar
          </Link>
          <Link
            to="/documents"
            className="text-sm font-medium transition-colors hover:text-navy"
          >
            Documents
          </Link>
          <Link
            to="/legal-assistant"
            className="text-sm font-medium transition-colors hover:text-navy"
          >
            AI Assistant
          </Link>
        </nav>
        
        <div className="hidden md:flex md:w-80 lg:w-96">
          <form onSubmit={handleSearch} className="relative w-full">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
            <Input
              type="search"
              placeholder="Search cases, clients..."
              className="w-full bg-white shadow-none appearance-none pl-8 md:w-2/3 lg:w-full pr-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            {searchTerm && (
              <button
                type="button"
                onClick={() => setSearchTerm("")}
                className="absolute right-2.5 top-2.5"
              >
                <X className="h-4 w-4 text-gray-500" />
              </button>
            )}
          </form>
        </div>

        <div className="ml-auto flex items-center space-x-4">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="relative"
                onClick={() => setShowNotifications(!showNotifications)}
              >
                <Bell className="h-5 w-5" />
                {unreadNotifications.length > 0 && (
                  <span className="absolute top-0 right-0 h-4 w-4 rounded-full bg-red-500 text-xs text-white flex items-center justify-center">
                    {unreadNotifications.length}
                  </span>
                )}
                <span className="sr-only">Notifications</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-80">
              <DropdownMenuLabel className="flex justify-between items-center">
                <span>Notifications</span>
                <Button variant="ghost" size="sm" className="h-auto p-1 text-xs">
                  Mark all as read
                </Button>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              {mockNotifications?.slice(0, 5).map((notification) => (
                <DropdownMenuItem key={notification.id} className="flex flex-col items-start p-3 cursor-pointer">
                  <div className="flex items-center w-full">
                    <div className="flex-1">
                      <p className="text-sm font-medium">{notification.title}</p>
                      <p className="text-xs text-gray-500">{notification.description}</p>
                    </div>
                    {!notification.read && (
                      <Badge className="ml-2 bg-blue-500">New</Badge>
                    )}
                  </div>
                  <p className="text-xs text-gray-400 mt-1">{notification.time}</p>
                </DropdownMenuItem>
              ))}
              <DropdownMenuItem className="text-center py-2 cursor-pointer justify-center font-medium text-sm text-blue-600">
                View all notifications
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring hover:bg-accent hover:text-accent-foreground h-9 px-3 py-2">
                <Avatar className="h-8 w-8 mr-2">
                  <AvatarImage src="/placeholder.svg" alt={userDisplayName} />
                  <AvatarFallback className="bg-navy text-white">
                    {userInitials}
                  </AvatarFallback>
                </Avatar>
                <div className="flex flex-col items-start text-left hidden md:block">
                  <span className="text-sm font-semibold leading-none">{userDisplayName}</span>
                  <span className="text-xs text-gray-500 leading-tight">Legal Partner</span>
                </div>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>My Account</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem>
                <User className="mr-2 h-4 w-4" />
                <span>Profile</span>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Calendar className="mr-2 h-4 w-4" />
                <span>Calendar</span>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <FileText className="mr-2 h-4 w-4" />
                <span>Documents</span>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <BarChart className="mr-2 h-4 w-4" />
                <span>Analytics</span>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Settings className="mr-2 h-4 w-4" />
                <span>Settings</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem>
                <Link to="/terms-of-service" className="flex items-center w-full">
                  <FileText className="mr-2 h-4 w-4" />
                  <span>Terms of Service</span>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Link to="/privacy-policy" className="flex items-center w-full">
                  <FileText className="mr-2 h-4 w-4" />
                  <span>Privacy Policy</span>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => logout()} className="text-red-600">
                <LogOut className="mr-2 h-4 w-4" />
                <span>Log out</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
};

export default Navbar;
