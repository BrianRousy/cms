
import React, { useEffect } from "react";
import Navbar from "./navbar";
import Sidebar from "./sidebar";
import { useAuth } from "../context/auth-context";
import { toast } from "@/hooks/use-toast";
import { useIsMobile } from "@/hooks/use-mobile";
import { apiService } from "@/services/api-service";
import { useNavigate } from "react-router-dom";

interface LayoutProps {
  children: React.ReactNode;
}

const Layout = ({ children }: LayoutProps) => {
  const { user, loading } = useAuth();
  const isMobile = useIsMobile();
  const navigate = useNavigate();

  useEffect(() => {
    // Check user authentication and redirect if not authenticated
    if (!loading && !user) {
      toast({
        title: "Authentication Required",
        description: "Please log in to continue",
        variant: "destructive",
      });
      navigate("/login");
      return;
    }

    // Welcome toast when layout mounts for authenticated users
    if (user) {
      // Load user profile from database to ensure we have the most current data
      apiService.users.getCurrent().then(({ data, error }) => {
        if (!error && data) {
          toast({
            title: `Welcome back, ${data.name}`,
            description: "You're logged into Astrus CMS",
            duration: 3000,
          });
        }
      });
    }
  }, [user, loading, navigate]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin w-10 h-10 border-t-2 border-purple-500 rounded-full"></div>
      </div>
    );
  }

  if (!user) {
    return null; // Will be redirected by the useEffect
  }

  return (
    <div className="flex min-h-screen bg-gray-100">
      <Sidebar />
      <div className="flex flex-col flex-1 w-full md:pl-60 lg:pl-72 transition-all duration-300" id="main-content">
        <Navbar />
        <main className="flex-1 overflow-y-auto p-4 md:p-6 pb-20 md:pb-6">
          {/* Add padding bottom for mobile to account for navigation */}
          {children}
        </main>
      </div>
    </div>
  );
};

export default Layout;
