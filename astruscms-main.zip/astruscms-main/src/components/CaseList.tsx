
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Table, TableBody, TableCaption, TableCell,
  TableHead, TableHeader, TableRow
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { apiService } from '@/services/api-service';
import { toast } from '@/hooks/use-toast';
import { Search, Plus, Filter } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { Case } from '@/types';

const CaseList = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filtersState, setFiltersState] = useState({});
  const navigate = useNavigate();

  const { data: casesData, isLoading, error, refetch } = useQuery({
    queryKey: ['cases', filtersState],
    queryFn: () => apiService.cases.getCases(filtersState),
    staleTime: 1000 * 60 * 5, // 5 minutes
    refetchOnWindowFocus: true,
  });

  // Ensure that cases is always an array
  const cases = Array.isArray(casesData) ? casesData : (casesData?.data || []);

  useEffect(() => {
    if (error) {
      console.error('Failed to load cases:', error);
      toast({
        title: 'Error',
        description: 'Failed to load cases. Please try again.',
        variant: 'destructive',
      });
    }
  }, [error]);

  // Filter cases based on search term
  const filteredCases = cases.filter((c) => {
    if (!c) return false;
    const searchLower = searchTerm.toLowerCase();
    return (
      c.title?.toLowerCase().includes(searchLower) ||
      c.case_number?.toLowerCase().includes(searchLower) ||
      c.client_name?.toLowerCase().includes(searchLower)
    );
  });

  const getPriorityColor = (priority: string) => {
    switch (priority?.toLowerCase()) {
      case 'high':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'medium':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'low':
        return 'bg-green-100 text-green-800 border-green-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'open':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'closed':
        return 'bg-gray-100 text-gray-800 border-gray-200';
      case 'pending':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  // Format date helper
  const formatDate = (dateString: string | null | undefined) => {
    if (!dateString) return '-';
    try {
      return new Date(dateString).toLocaleDateString();
    } catch (e) {
      return '-';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-semibold">Case Management</h2>
        <Button onClick={() => navigate('/cases/new')}>
          <Plus className="mr-2 h-4 w-4" />
          New Case
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Open Cases</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {isLoading ? (
                <div className="h-6 w-6 animate-spin rounded-full border-2 border-gray-200 border-t-gray-600" />
              ) : (
                cases.filter((c) => c?.status === "open").length
              )}
            </div>
            <p className="text-xs text-gray-500">Active cases requiring attention</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Pending Cases</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {isLoading ? (
                <div className="h-6 w-6 animate-spin rounded-full border-2 border-gray-200 border-t-gray-600" />
              ) : (
                cases.filter((c) => c?.status === "pending").length
              )}
            </div>
            <p className="text-xs text-gray-500">Waiting for action</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Closed Cases</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {isLoading ? (
                <div className="h-6 w-6 animate-spin rounded-full border-2 border-gray-200 border-t-gray-600" />
              ) : (
                cases.filter((c) => c?.status === "closed").length
              )}
            </div>
            <p className="text-xs text-gray-500">Completed cases</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Cases</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex justify-between mb-6">
            <div className="relative w-full max-w-sm">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
              <Input
                type="search"
                placeholder="Search cases..."
                className="pl-8 w-full"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Button variant="outline" size="sm" onClick={() => refetch()}>
              <Filter className="mr-2 h-4 w-4" />
              Filter
            </Button>
          </div>

          {isLoading ? (
            <div className="flex justify-center items-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
            </div>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Case Details</TableHead>
                    <TableHead>Client</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Priority</TableHead>
                    <TableHead>Progress</TableHead>
                    <TableHead>Due Date</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredCases.length > 0 ? (
                    filteredCases.map((caseItem) => (
                      <TableRow 
                        key={caseItem.id}
                        className="cursor-pointer hover:bg-muted/50"
                        onClick={() => navigate(`/cases/${caseItem.id}`)}
                      >
                        <TableCell>
                          <div className="font-medium">{caseItem.title}</div>
                          <div className="text-sm text-gray-500">
                            {caseItem.case_number}
                          </div>
                        </TableCell>
                        <TableCell>{caseItem.client_name}</TableCell>
                        <TableCell>
                          <Badge
                            variant="outline"
                            className={getStatusColor(caseItem.status)}
                          >
                            {caseItem.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant="outline"
                            className={getPriorityColor(caseItem.priority)}
                          >
                            {caseItem.priority}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Progress
                              value={caseItem.progress}
                              className="h-2 w-[60px]"
                            />
                            <span className="text-sm">{caseItem.progress}%</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          {formatDate(caseItem.due_date)}
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-6">
                        {searchTerm ? 'No cases found matching your search' : 'No cases available'}
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default CaseList;
