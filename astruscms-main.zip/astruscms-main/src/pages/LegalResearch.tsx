
import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import {
  Search,
  BookOpen,
  Filter,
  GraduationCap,
  Scale,
  BookMarked,
  History,
  Star,
  Clock,
  ArrowDownUp,
  Save,
  Share2,
  Bookmark,
  ChevronDown,
  ExternalLink,
  FileText,
  Download,
  Copy,
  BarChart,
  MoreVertical
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useIsMobile } from "@/hooks/use-mobile";

// Mock data for legal research results
const researchResults = [
  {
    id: 1,
    title: "Smith v. Johnson",
    citation: "123 F.3d 456 (9th Cir. 2022)",
    snippet: "The court held that the defendant's actions constituted negligence under the state law's standard of care for professionals...",
    jurisdiction: "Federal",
    date: "2022-05-15",
    relevance: 92,
    source: "Westlaw",
    type: "Case",
    saved: true
  },
  {
    id: 2,
    title: "Reynolds v. ABC Corporation",
    citation: "234 Cal.App.4th 789 (2021)",
    snippet: "In considering the application of the business judgment rule, the court determined that directors are protected when making good faith decisions...",
    jurisdiction: "California",
    date: "2021-11-03",
    relevance: 88,
    source: "LexisNexis",
    type: "Case",
    saved: false
  },
  {
    id: 3,
    title: "Contract Breach: Elements and Remedies",
    citation: "Harvard Law Review, Vol. 135",
    snippet: "This article examines the evolving standards for establishing breach of contract claims in commercial litigation and explores the available remedies...",
    jurisdiction: "N/A",
    date: "2023-02-18",
    relevance: 85,
    source: "HeinOnline",
    type: "Article",
    saved: true
  },
  {
    id: 4,
    title: "Thompson v. City of Springfield",
    citation: "345 Mass. 567 (2020)",
    snippet: "The Supreme Judicial Court clarified the standard for municipal liability in cases involving alleged police misconduct...",
    jurisdiction: "Massachusetts",
    date: "2020-07-22",
    relevance: 79,
    source: "Westlaw",
    type: "Case",
    saved: false
  },
  {
    id: 5,
    title: "Corporate Governance Act of 2021",
    citation: "Pub. L. No. 117-52, 135 Stat. 124",
    snippet: "Section 4(a)(3) imposes new reporting requirements for corporate boards regarding diversity and environmental impact...",
    jurisdiction: "Federal",
    date: "2021-09-30",
    relevance: 76,
    source: "Government Publishing Office",
    type: "Statute",
    saved: false
  }
];

// Mock data for recent searches
const recentSearches = [
  { id: 1, query: "breach of contract damages", date: "2024-04-10", count: 42 },
  { id: 2, query: "corporate negligence standards", date: "2024-04-08", count: 28 },
  { id: 3, query: "intellectual property infringement", date: "2024-04-05", count: 35 },
  { id: 4, query: "employment discrimination evidence", date: "2024-04-01", count: 23 },
];

// Define types for clarity
interface ResearchResult {
  id: number;
  title: string;
  citation: string;
  snippet: string;
  jurisdiction: string;
  date: string;
  relevance: number;
  source: string;
  type: string;
  saved: boolean;
}

interface SelectedFilters {
  jurisdiction: Set<string>;
  source: Set<string>;
  type: Set<string>;
  date: string;
}

const ResultCard = ({ result, onToggleSaved }: { result: ResearchResult; onToggleSaved: (id: number) => void }) => {
  const { toast } = useToast();
  
  const handleCopyCitation = () => {
    navigator.clipboard.writeText(result.citation);
    toast({
      title: "Citation copied",
      description: "Citation copied to clipboard",
    });
  };

  const handleDownload = (format: string) => {
    toast({
      title: `Downloading ${format}`,
      description: `${result.title} is being downloaded as ${format}`,
    });
  };

  return (
    <Card className="hover:shadow-md transition-shadow group">
      <CardContent className="p-6">
        <div className="flex justify-between flex-col md:flex-row gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              {result.type === "Case" ? (
                <Scale className="h-5 w-5 text-navy flex-shrink-0" />
              ) : result.type === "Statute" ? (
                <GraduationCap className="h-5 w-5 text-navy flex-shrink-0" />
              ) : (
                <BookOpen className="h-5 w-5 text-navy flex-shrink-0" />
              )}
              <h3 className="text-lg font-semibold">{result.title}</h3>
            </div>
            <p className="text-sm text-gray-500">{result.citation}</p>
            <p className="text-sm">{result.snippet}</p>
            <div className="flex flex-wrap items-center gap-2 pt-2">
              <Badge variant="secondary">{result.jurisdiction}</Badge>
              <Badge variant="outline">{result.type}</Badge>
              <Badge variant="outline">{result.source}</Badge>
              <Badge variant="outline">{new Date(result.date).toLocaleDateString()}</Badge>
              <Badge className="bg-navy text-white">Relevance: {result.relevance}%</Badge>
            </div>
          </div>
          
          <div className="flex flex-row md:flex-col items-center md:items-end justify-between md:justify-start space-y-0 md:space-y-2">
            <Button variant="ghost" size="icon" onClick={() => onToggleSaved(result.id)}>
              <Bookmark className={`h-5 w-5 ${result.saved ? 'fill-navy text-navy' : 'text-gray-400'}`} />
            </Button>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <MoreVertical className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem>
                  <ExternalLink className="mr-2 h-4 w-4" />
                  View Full Document
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuLabel>Download As</DropdownMenuLabel>
                <DropdownMenuItem onClick={() => handleDownload("PDF")}>
                  <FileText className="mr-2 h-4 w-4" />
                  PDF
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleDownload("Word")}>
                  <FileText className="mr-2 h-4 w-4" />
                  Word Document
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleCopyCitation}>
                  <Copy className="mr-2 h-4 w-4" />
                  Copy Citation
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Share2 className="mr-2 h-4 w-4" />
                  Share
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Save className="mr-2 h-4 w-4" />
                  Save to Case
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

const SearchForm = ({ searchQuery, setSearchQuery, handleSearch, isSearching }: { 
  searchQuery: string; 
  setSearchQuery: (query: string) => void; 
  handleSearch: (e: React.FormEvent) => void; 
  isSearching: boolean 
}) => {
  const quickFilters = [
    "Breach of Contract",
    "Negligence",
    "Intellectual Property",
    "Employment Law",
    "Class Action"
  ];

  return (
    <form onSubmit={handleSearch} className="space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-2 sm:space-y-0 sm:space-x-2">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-2.5 top-2.5 h-5 w-5 text-gray-500" />
          <Input 
            placeholder="Search cases, statutes, regulations..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Button 
          type="submit" 
          className="bg-navy hover:bg-navy/90 w-full sm:w-auto" 
          disabled={isSearching}
        >
          {isSearching ? 'Searching...' : 'Search'}
        </Button>
      </div>
      
      <div className="flex flex-wrap gap-2 items-center">
        <span className="text-sm text-gray-500">Quick Filters:</span>
        {quickFilters.map(filter => (
          <Badge 
            key={filter}
            variant="outline" 
            className="cursor-pointer hover:bg-gray-100" 
            onClick={() => setSearchQuery(filter.toLowerCase())}
          >
            {filter}
          </Badge>
        ))}
      </div>
    </form>
  );
};

const FilterSection = ({ selectedFilters, handleFilterChange, clearFilters }: {
  selectedFilters: SelectedFilters;
  handleFilterChange: (filterType: keyof SelectedFilters, value: string) => void;
  clearFilters: () => void;
}) => {
  const jurisdictions = ["Federal", "California", "Massachusetts"];
  const sources = ["Westlaw", "LexisNexis", "HeinOnline"];
  const types = ["Case", "Statute", "Article"];

  return (
    <>
      <div className="px-2 py-1.5">
        <h4 className="mb-2 text-sm font-medium">Jurisdiction</h4>
        <div className="space-y-2">
          {jurisdictions.map(jurisdiction => (
            <div key={jurisdiction} className="flex items-center space-x-2">
              <Checkbox 
                id={jurisdiction.toLowerCase()} 
                checked={selectedFilters.jurisdiction.has(jurisdiction)}
                onCheckedChange={() => handleFilterChange('jurisdiction', jurisdiction)}
              />
              <Label htmlFor={jurisdiction.toLowerCase()} className="text-sm">{jurisdiction}</Label>
            </div>
          ))}
        </div>
      </div>
      
      <DropdownMenuSeparator />
      
      <div className="px-2 py-1.5">
        <h4 className="mb-2 text-sm font-medium">Source</h4>
        <div className="space-y-2">
          {sources.map(source => (
            <div key={source} className="flex items-center space-x-2">
              <Checkbox 
                id={source.toLowerCase()} 
                checked={selectedFilters.source.has(source)}
                onCheckedChange={() => handleFilterChange('source', source)}
              />
              <Label htmlFor={source.toLowerCase()} className="text-sm">{source}</Label>
            </div>
          ))}
        </div>
      </div>
      
      <DropdownMenuSeparator />
      
      <div className="px-2 py-1.5">
        <h4 className="mb-2 text-sm font-medium">Document Type</h4>
        <div className="space-y-2">
          {types.map(type => (
            <div key={type} className="flex items-center space-x-2">
              <Checkbox 
                id={type.toLowerCase()} 
                checked={selectedFilters.type.has(type)}
                onCheckedChange={() => handleFilterChange('type', type)}
              />
              <Label htmlFor={type.toLowerCase()} className="text-sm">{type}</Label>
            </div>
          ))}
        </div>
      </div>
      
      <DropdownMenuSeparator />
      
      <div className="px-2 py-1.5 flex justify-center">
        <Button variant="outline" size="sm" onClick={clearFilters}>Clear Filters</Button>
      </div>
    </>
  );
};

const LegalResearch = () => {
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<ResearchResult[]>(researchResults);
  const [selectedFilters, setSelectedFilters] = useState<SelectedFilters>({
    jurisdiction: new Set<string>(),
    source: new Set<string>(),
    type: new Set<string>(),
    date: "all"
  });
  const [isSearching, setIsSearching] = useState(false);
  const [activeTab, setActiveTab] = useState("results");

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    
    setIsSearching(true);
    // Simulate API call delay
    setTimeout(() => {
      setIsSearching(false);
      const filtered = researchResults.filter(result => 
        result.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
        result.snippet.toLowerCase().includes(searchQuery.toLowerCase())
      );
      
      setSearchResults(filtered);
      setActiveTab("results");
      
      toast({
        title: "Search Complete",
        description: `Found ${filtered.length} results for "${searchQuery}"`,
      });
    }, 800);
  };

  const toggleSaved = (id: number) => {
    setSearchResults(searchResults.map(result => 
      result.id === id ? { ...result, saved: !result.saved } : result
    ));
    
    const result = searchResults.find(r => r.id === id);
    if (result) {
      toast({
        title: result.saved ? "Removed from Saved Items" : "Added to Saved Items",
        description: result.title,
      });
    }
  };

  const handleFilterChange = (filterType: keyof SelectedFilters, value: string) => {
    setSelectedFilters(prev => {
      const newFilters = { ...prev };
      
      if (filterType === 'date') {
        newFilters.date = value;
      } else {
        const filterSet = new Set(prev[filterType]);
        
        if (filterSet.has(value)) {
          filterSet.delete(value);
        } else {
          filterSet.add(value);
        }
        
        newFilters[filterType] = filterSet;
      }
      
      return newFilters;
    });
  };

  const clearFilters = () => {
    setSelectedFilters({
      jurisdiction: new Set<string>(),
      source: new Set<string>(),
      type: new Set<string>(),
      date: "all"
    });
  };

  const exportResults = (format: string) => {
    toast({
      title: "Results Exported",
      description: `Research results have been exported as ${format.toUpperCase()}.`,
    });
  };

  // Apply filters to results
  const filteredResults = searchResults.filter(result => {
    const jurisdictionMatch = selectedFilters.jurisdiction.size === 0 || 
                            selectedFilters.jurisdiction.has(result.jurisdiction);
    
    const sourceMatch = selectedFilters.source.size === 0 || 
                      selectedFilters.source.has(result.source);
    
    const typeMatch = selectedFilters.type.size === 0 || 
                    selectedFilters.type.has(result.type);
    
    return jurisdictionMatch && sourceMatch && typeMatch;
  });

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold">Legal Research</h1>
          <p className="text-sm text-gray-500">Search legal databases and precedents</p>
        </div>
        <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="w-full sm:w-auto">
                <Download className="mr-2 h-4 w-4" />
                Export
                <ChevronDown className="ml-2 h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuItem onClick={() => exportResults('pdf')}>
                <FileText className="mr-2 h-4 w-4" />
                Export as PDF
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => exportResults('word')}>
                <FileText className="mr-2 h-4 w-4" />
                Export as Word
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => exportResults('csv')}>
                <FileText className="mr-2 h-4 w-4" />
                Export as CSV
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          
          <Button className="bg-navy hover:bg-navy/90 w-full sm:w-auto">
            New Research
          </Button>
        </div>
      </div>

      <Card className="hover:shadow-md transition-shadow">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Search className="h-5 w-5 text-navy" />
            <CardTitle>Legal Research Database</CardTitle>
          </div>
          <CardDescription>Search across cases, statutes, regulations and legal journals</CardDescription>
        </CardHeader>
        
        <CardContent>
          <SearchForm
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            handleSearch={handleSearch}
            isSearching={isSearching}
          />
        </CardContent>
      </Card>

      <Tabs defaultValue="results" value={activeTab} onValueChange={setActiveTab}>
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-4">
          <TabsList className="w-full sm:w-auto">
            <TabsTrigger value="results" className="flex items-center gap-1">
              <BookOpen className="h-4 w-4" />
              Search Results
            </TabsTrigger>
            <TabsTrigger value="saved" className="flex items-center gap-1">
              <Bookmark className="h-4 w-4" />
              Saved
            </TabsTrigger>
            <TabsTrigger value="history" className="flex items-center gap-1">
              <History className="h-4 w-4" />
              Recent Searches
            </TabsTrigger>
          </TabsList>
          
          <div className="flex gap-2 w-full sm:w-auto">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="w-full sm:w-auto">
                  <Filter className="mr-2 h-4 w-4" />
                  Filter
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align="end">
                <DropdownMenuLabel>Filters</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <FilterSection 
                  selectedFilters={selectedFilters}
                  handleFilterChange={handleFilterChange}
                  clearFilters={clearFilters}
                />
              </DropdownMenuContent>
            </DropdownMenu>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="w-full sm:w-auto">
                  <ArrowDownUp className="mr-2 h-4 w-4" />
                  Sort
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem>
                  <Star className="mr-2 h-4 w-4" />
                  Relevance (High to Low)
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Clock className="mr-2 h-4 w-4" />
                  Date (Newest First)
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Clock className="mr-2 h-4 w-4" />
                  Date (Oldest First)
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <BookMarked className="mr-2 h-4 w-4" />
                  Title (A-Z)
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      
        <TabsContent value="results">
          <div className="space-y-6">
            {filteredResults.length === 0 ? (
              <div className="text-center py-12">
                <Search className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                <h3 className="text-lg font-medium">No results found</h3>
                <p className="text-gray-500 mt-2">Try adjusting your search terms or filters</p>
              </div>
            ) : (
              filteredResults.map((result) => (
                <ResultCard key={result.id} result={result} onToggleSaved={toggleSaved} />
              ))
            )}
          </div>
        </TabsContent>
        
        <TabsContent value="saved">
          <div className="space-y-6">
            {searchResults.filter(r => r.saved).length === 0 ? (
              <div className="text-center py-12">
                <Bookmark className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                <h3 className="text-lg font-medium">No saved items</h3>
                <p className="text-gray-500 mt-2">Save research items by clicking the bookmark icon</p>
              </div>
            ) : (
              searchResults.filter(r => r.saved).map((result) => (
                <ResultCard key={result.id} result={result} onToggleSaved={toggleSaved} />
              ))
            )}
          </div>
        </TabsContent>
        
        <TabsContent value="history">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <History className="h-5 w-5 text-navy" />
                <span>Recent Searches</span>
              </CardTitle>
              <CardDescription>Your last 30 days of search history</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentSearches.map((search) => (
                  <div key={search.id} className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-md group">
                    <div className="flex items-center gap-3">
                      <Search className="h-4 w-4 text-gray-500" />
                      <div>
                        <p className="font-medium">{search.query}</p>
                        <p className="text-xs text-gray-500">{new Date(search.date).toLocaleDateString()} • {search.count} results</p>
                      </div>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="opacity-0 group-hover:opacity-100"
                      onClick={() => {
                        setSearchQuery(search.query);
                        handleSearch({ preventDefault: () => {} } as React.FormEvent);
                      }}
                    >
                      Run Again
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
          
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart className="h-5 w-5 text-navy" />
                <span>Search Insights</span>
              </CardTitle>
              <CardDescription>Analytics about your research patterns</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-gray-50 rounded-lg p-4">
                  <h3 className="text-sm font-medium text-gray-500">Most Searched Topic</h3>
                  <p className="text-lg font-semibold mt-1">Contract Law</p>
                  <p className="text-xs text-gray-500 mt-1">28% of searches</p>
                </div>
                
                <div className="bg-gray-50 rounded-lg p-4">
                  <h3 className="text-sm font-medium text-gray-500">Most Cited Case</h3>
                  <p className="text-lg font-semibold mt-1">Smith v. Johnson</p>
                  <p className="text-xs text-gray-500 mt-1">Referenced 14 times</p>
                </div>
                
                <div className="bg-gray-50 rounded-lg p-4">
                  <h3 className="text-sm font-medium text-gray-500">Preferred Source</h3>
                  <p className="text-lg font-semibold mt-1">Westlaw</p>
                  <p className="text-xs text-gray-500 mt-1">42% of searches</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default LegalResearch;
