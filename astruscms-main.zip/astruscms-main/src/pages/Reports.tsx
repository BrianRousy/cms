
import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { format, subMonths } from "date-fns";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from "recharts";
import {
  Download,
  Filter,
  CalendarRange,
  BarChart as BarChartIcon,
  Printer,
  FileUp,
  Mail,
  Clock,
  DollarSign,
  Users,
  BarChart2,
  PieChart as PieChartIcon,
  LineChart as LineChartIcon,
  FileCog
} from "lucide-react";
import { mockCases } from "@/lib/mock-data";
import { useToast } from "@/hooks/use-toast";

// Sample data for financial reports
const financialData = [
  { month: 'Jan', revenue: 45000, expenses: 32000, profit: 13000 },
  { month: 'Feb', revenue: 52000, expenses: 34000, profit: 18000 },
  { month: 'Mar', revenue: 49000, expenses: 33000, profit: 16000 },
  { month: 'Apr', revenue: 56000, expenses: 35000, profit: 21000 },
  { month: 'May', revenue: 62000, expenses: 38000, profit: 24000 },
  { month: 'Jun', revenue: 58000, expenses: 36000, profit: 22000 }
];

// Case distribution data
const caseTypeData = [
  { name: 'Corporate', value: 35, color: '#14213D' },
  { name: 'Personal Injury', value: 25, color: '#FCA311' },
  { name: 'Family', value: 15, color: '#4CAF50' },
  { name: 'Criminal', value: 12, color: '#2196F3' },
  { name: 'Real Estate', value: 8, color: '#9C27B0' },
  { name: 'Other', value: 5, color: '#607D8B' }
];

// Billable hours data
const billableHoursData = [
  { name: 'Week 1', hours: 168 },
  { name: 'Week 2', hours: 182 },
  { name: 'Week 3', hours: 175 },
  { name: 'Week 4', hours: 190 }
];

// Client satisfaction data
const clientSatisfactionData = [
  { name: 'Very Satisfied', value: 65, color: '#4CAF50' },
  { name: 'Satisfied', value: 25, color: '#FCA311' },
  { name: 'Neutral', value: 7, color: '#607D8B' },
  { name: 'Dissatisfied', value: 3, color: '#F44336' }
];

const Reports = () => {
  const { toast } = useToast();
  const [dateRange, setDateRange] = useState({
    from: format(subMonths(new Date(), 3), "yyyy-MM-dd"),
    to: format(new Date(), "yyyy-MM-dd")
  });
  const [reportType, setReportType] = useState("financial");
  const [loading, setLoading] = useState(false);

  const generateReport = () => {
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      toast({
        title: "Report Generated",
        description: `Your ${reportType} report has been generated successfully.`,
      });
    }, 1000);
  };

  const exportReport = (format: string) => {
    setLoading(true);
    // Simulate export process
    setTimeout(() => {
      setLoading(false);
      toast({
        title: "Export Complete",
        description: `Report has been exported as ${format.toUpperCase()}.`,
      });
    }, 1000);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold">Reports & Analytics</h1>
          <p className="text-sm text-gray-500">Generate and analyze performance data</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" onClick={() => exportReport('pdf')}>
            <Download className="mr-2 h-4 w-4" />
            Export PDF
          </Button>
          <Button variant="outline" onClick={() => exportReport('excel')}>
            <FileUp className="mr-2 h-4 w-4" />
            Export Excel
          </Button>
          <Button variant="outline" onClick={() => exportReport('print')}>
            <Printer className="mr-2 h-4 w-4" />
            Print
          </Button>
          <Button variant="outline" onClick={() => exportReport('email')}>
            <Mail className="mr-2 h-4 w-4" />
            Email Report
          </Button>
        </div>
      </div>

      {/* Report Generator */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <FileCog className="h-5 w-5 text-navy" />
            <CardTitle>Report Generator</CardTitle>
          </div>
          <CardDescription>Configure and generate custom reports</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="text-sm font-medium">Report Type</label>
              <Select value={reportType} onValueChange={setReportType}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Select report type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="financial">Financial Reports</SelectItem>
                  <SelectItem value="cases">Case Reports</SelectItem>
                  <SelectItem value="time">Time & Billing</SelectItem>
                  <SelectItem value="client">Client Analytics</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium">From Date</label>
              <Input 
                type="date" 
                className="mt-1" 
                value={dateRange.from}
                onChange={(e) => setDateRange({...dateRange, from: e.target.value})}
              />
            </div>
            <div>
              <label className="text-sm font-medium">To Date</label>
              <Input 
                type="date" 
                className="mt-1"
                value={dateRange.to}
                onChange={(e) => setDateRange({...dateRange, to: e.target.value})}
              />
            </div>
            <div className="flex items-end">
              <Button onClick={generateReport} className="w-full bg-navy hover:bg-navy/90" disabled={loading}>
                {loading ? 'Generating...' : 'Generate Report'}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="financial">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="financial" className="flex items-center space-x-2">
            <BarChartIcon className="h-4 w-4" />
            <span>Financial</span>
          </TabsTrigger>
          <TabsTrigger value="cases" className="flex items-center space-x-2">
            <PieChartIcon className="h-4 w-4" />
            <span>Cases</span>
          </TabsTrigger>
          <TabsTrigger value="time" className="flex items-center space-x-2">
            <Clock className="h-4 w-4" />
            <span>Time & Billing</span>
          </TabsTrigger>
          <TabsTrigger value="client" className="flex items-center space-x-2">
            <Users className="h-4 w-4" />
            <span>Client Analytics</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="financial" className="pt-4 space-y-6">
          <Card className="hover:shadow-md transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="h-5 w-5 text-green-600" />
                <span>Financial Performance</span>
              </CardTitle>
              <CardDescription>Revenue, expenses and profit trends</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={financialData}
                    margin={{
                      top: 20,
                      right: 30,
                      left: 20,
                      bottom: 5,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip 
                      formatter={(value) => `$${value.toLocaleString()}`}
                      labelFormatter={(label) => `Month: ${label}`}
                    />
                    <Legend />
                    <Bar dataKey="revenue" name="Revenue" fill="#14213D" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="expenses" name="Expenses" fill="#FCA311" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="profit" name="Profit" fill="#4CAF50" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
            <CardFooter className="bg-gray-50 border-t px-6 py-3">
              <div className="flex flex-col md:flex-row justify-between w-full">
                <div className="text-sm text-gray-500">
                  <strong className="text-gray-700">Total Revenue:</strong> $322,000
                </div>
                <div className="text-sm text-gray-500">
                  <strong className="text-gray-700">Total Expenses:</strong> $208,000
                </div>
                <div className="text-sm text-gray-500">
                  <strong className="text-gray-700">Net Profit:</strong> $114,000
                </div>
              </div>
            </CardFooter>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="hover:shadow-md transition-shadow">
              <CardHeader>
                <CardTitle className="text-lg">Monthly Billing Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center pb-3 border-b">
                    <span>Current Month Billing</span>
                    <span className="font-semibold">$62,000</span>
                  </div>
                  <div className="flex justify-between items-center pb-3 border-b">
                    <span>Previous Month Billing</span>
                    <span className="font-semibold">$58,000</span>
                  </div>
                  <div className="flex justify-between items-center pb-3 border-b">
                    <span>Outstanding Invoices</span>
                    <span className="font-semibold text-amber-600">$24,500</span>
                  </div>
                  <div className="flex justify-between items-center pb-3 border-b">
                    <span>Overdue Invoices</span>
                    <span className="font-semibold text-red-600">$8,700</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Collection Rate</span>
                    <span className="font-semibold">92%</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover:shadow-md transition-shadow">
              <CardHeader>
                <CardTitle className="text-lg">Revenue By Practice Area</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-60">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={caseTypeData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({name, percent}) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {caseTypeData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => `${value}%`} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="cases" className="pt-4 space-y-6">
          <Card className="hover:shadow-md transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <PieChartIcon className="h-5 w-5 text-blue-600" />
                <span>Case Distribution</span>
              </CardTitle>
              <CardDescription>Breakdown of cases by type and status</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={caseTypeData}
                      cx="50%"
                      cy="50%"
                      labelLine={true}
                      outerRadius={120}
                      fill="#8884d8"
                      dataKey="value"
                      label={({name, percent}) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      {caseTypeData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => `${value}%`} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="hover:shadow-md transition-shadow">
              <CardHeader>
                <CardTitle className="text-lg">Case Status</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center pb-2">
                    <span>Open Cases</span>
                    <span className="font-semibold">{mockCases.filter(c => c.status === 'open').length}</span>
                  </div>
                  <div className="flex justify-between items-center pb-2">
                    <span>Pending Cases</span>
                    <span className="font-semibold">{mockCases.filter(c => c.status === 'pending').length}</span>
                  </div>
                  <div className="flex justify-between items-center pb-2">
                    <span>Closed Cases</span>
                    <span className="font-semibold">{mockCases.filter(c => c.status === 'closed').length}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Archived Cases</span>
                    <span className="font-semibold">{mockCases.filter(c => c.status === 'archived').length}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover:shadow-md transition-shadow">
              <CardHeader>
                <CardTitle className="text-lg">Case Stages</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center pb-2">
                    <span>Intake</span>
                    <span className="font-semibold">{mockCases.filter(c => c.stage === 'intake').length}</span>
                  </div>
                  <div className="flex justify-between items-center pb-2">
                    <span>Discovery</span>
                    <span className="font-semibold">{mockCases.filter(c => c.stage === 'discovery').length}</span>
                  </div>
                  <div className="flex justify-between items-center pb-2">
                    <span>Negotiation</span>
                    <span className="font-semibold">{mockCases.filter(c => c.stage === 'negotiation').length}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Trial/Settlement</span>
                    <span className="font-semibold">
                      {mockCases.filter(c => c.stage === 'trial' || c.stage === 'settlement').length}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover:shadow-md transition-shadow">
              <CardHeader>
                <CardTitle className="text-lg">Case Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center pb-2">
                    <span>Avg. Case Duration</span>
                    <span className="font-semibold">68 days</span>
                  </div>
                  <div className="flex justify-between items-center pb-2">
                    <span>Resolution Rate</span>
                    <span className="font-semibold">72%</span>
                  </div>
                  <div className="flex justify-between items-center pb-2">
                    <span>Success Rate</span>
                    <span className="font-semibold text-green-600">84%</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Avg. Case Value</span>
                    <span className="font-semibold">$42,500</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="time" className="pt-4 space-y-6">
          <Card className="hover:shadow-md transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-amber-600" />
                <span>Billable Hours</span>
              </CardTitle>
              <CardDescription>Time tracking and billable hours analysis</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={billableHoursData}
                    margin={{
                      top: 20,
                      right: 30,
                      left: 20,
                      bottom: 5,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip formatter={(value) => `${value} hours`} />
                    <Legend />
                    <Line type="monotone" dataKey="hours" stroke="#14213D" strokeWidth={2} activeDot={{ r: 8 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="hover:shadow-md transition-shadow">
              <CardHeader>
                <CardTitle className="text-lg">Time Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center pb-2">
                    <span>Total Billable Hours</span>
                    <span className="font-semibold">715</span>
                  </div>
                  <div className="flex justify-between items-center pb-2">
                    <span>Total Non-Billable</span>
                    <span className="font-semibold">124</span>
                  </div>
                  <div className="flex justify-between items-center pb-2">
                    <span>Billable Percentage</span>
                    <span className="font-semibold">85.2%</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Avg. Daily Hours</span>
                    <span className="font-semibold">7.2</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover:shadow-md transition-shadow">
              <CardHeader>
                <CardTitle className="text-lg">Attorney Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center pb-2">
                    <span>Top Performer</span>
                    <span className="font-semibold">Sarah Johnson</span>
                  </div>
                  <div className="flex justify-between items-center pb-2">
                    <span>Most Billable Hours</span>
                    <span className="font-semibold">John Smith (182)</span>
                  </div>
                  <div className="flex justify-between items-center pb-2">
                    <span>Best Utilization Rate</span>
                    <span className="font-semibold">David Wilson (92%)</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Avg. Attorney Rate</span>
                    <span className="font-semibold">$285/hr</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover:shadow-md transition-shadow">
              <CardHeader>
                <CardTitle className="text-lg">Billing Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center pb-2">
                    <span>Realization Rate</span>
                    <span className="font-semibold">92%</span>
                  </div>
                  <div className="flex justify-between items-center pb-2">
                    <span>Collection Rate</span>
                    <span className="font-semibold">88%</span>
                  </div>
                  <div className="flex justify-between items-center pb-2">
                    <span>Avg. Invoice Age</span>
                    <span className="font-semibold">18 days</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Total Unbilled</span>
                    <span className="font-semibold text-amber-600">$42,850</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="client" className="pt-4 space-y-6">
          <Card className="hover:shadow-md transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5 text-purple-600" />
                <span>Client Satisfaction</span>
              </CardTitle>
              <CardDescription>Feedback and satisfaction metrics</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={clientSatisfactionData}
                      cx="50%"
                      cy="50%"
                      labelLine={true}
                      outerRadius={120}
                      fill="#8884d8"
                      dataKey="value"
                      label={({name, percent}) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      {clientSatisfactionData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => `${value}%`} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="hover:shadow-md transition-shadow">
              <CardHeader>
                <CardTitle className="text-lg">Client Acquisition</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center pb-2">
                    <span>New Clients (This Month)</span>
                    <span className="font-semibold">18</span>
                  </div>
                  <div className="flex justify-between items-center pb-2">
                    <span>Client Growth</span>
                    <span className="font-semibold text-green-600">+12%</span>
                  </div>
                  <div className="flex justify-between items-center pb-2">
                    <span>Avg. Acquisition Cost</span>
                    <span className="font-semibold">$850</span>
                  </div>
                  <div className="flex justify-between items-center pb-2">
                    <span>Retention Rate</span>
                    <span className="font-semibold">78%</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Referral Rate</span>
                    <span className="font-semibold">32%</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover:shadow-md transition-shadow">
              <CardHeader>
                <CardTitle className="text-lg">Client Engagement</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center pb-2">
                    <span>Avg. Response Time</span>
                    <span className="font-semibold">4.2 hours</span>
                  </div>
                  <div className="flex justify-between items-center pb-2">
                    <span>Client Portal Usage</span>
                    <span className="font-semibold">68%</span>
                  </div>
                  <div className="flex justify-between items-center pb-2">
                    <span>Communication Frequency</span>
                    <span className="font-semibold">Weekly: 82%</span>
                  </div>
                  <div className="flex justify-between items-center pb-2">
                    <span>NPS Score</span>
                    <span className="font-semibold text-green-600">8.7/10</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Client Feedback Rate</span>
                    <span className="font-semibold">65%</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Reports;
