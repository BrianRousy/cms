import React, { useState, useRef, useEffect } from "react";
import { useAuth } from "@/context/auth-context";
import { getUserDisplayName, getUserAvatar } from "@/utils/auth-helpers";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Bot, Send, Paperclip, Sparkles, Save, FileText, Copy, CheckCircle2, Clock, RotateCcw, Loader2 } from "lucide-react";

const LegalAssistant = () => {
  const { user } = useAuth();
  const userName = getUserDisplayName(user);
  const userAvatar = getUserAvatar(user);
  
  const [messages, setMessages] = useState([
    {
      role: "assistant",
      content: "Hello! I'm your AI legal assistant. How can I help you today?",
    },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState("chat");
  const [selectedTemplate, setSelectedTemplate] = useState("");
  const [documentTitle, setDocumentTitle] = useState("");
  const [documentContent, setDocumentContent] = useState("");
  const [savedDocuments, setSavedDocuments] = useState([
    { id: 1, title: "Cease and Desist Letter", date: "2023-05-15", type: "letter" },
    { id: 2, title: "Non-Disclosure Agreement", date: "2023-05-10", type: "agreement" },
    { id: 3, title: "Client Intake Form", date: "2023-05-05", type: "form" },
  ]);
  const [chatHistory, setChatHistory] = useState([
    { id: 1, title: "Case Research - Smith v. Jones", date: "2023-05-15", messages: 12 },
    { id: 2, title: "Contract Review - ABC Corp", date: "2023-05-10", messages: 8 },
    { id: 3, title: "Legal Strategy - Patent Dispute", date: "2023-05-05", messages: 15 },
  ]);
  
  const messagesEndRef = useRef(null);
  
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };
  
  useEffect(() => {
    scrollToBottom();
  }, [messages]);
  
  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (input.trim() === "") return;
    
    const userMessage = { role: "user", content: input };
    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);
    
    // Simulate AI response
    setTimeout(() => {
      const assistantMessage = {
        role: "assistant",
        content: "I'm simulating a response to your query. In a real implementation, this would connect to an AI service like OpenAI's API to generate a contextually relevant response based on legal knowledge and your specific question.",
      };
      setMessages((prev) => [...prev, assistantMessage]);
      setIsLoading(false);
    }, 1500);
  };
  
  const handleNewDocument = () => {
    setDocumentTitle("");
    setDocumentContent("");
    setActiveTab("document");
  };
  
  const handleSaveDocument = () => {
    if (documentTitle.trim() === "") return;
    
    const newDocument = {
      id: savedDocuments.length + 1,
      title: documentTitle,
      date: new Date().toISOString().split("T")[0],
      type: "draft",
    };
    
    setSavedDocuments((prev) => [...prev, newDocument]);
    alert("Document saved successfully!");
  };
  
  const handleTemplateSelect = (value) => {
    setSelectedTemplate(value);
    
    // Populate with template content based on selection
    if (value === "cease-and-desist") {
      setDocumentTitle("Cease and Desist Letter");
      setDocumentContent(`[SENDER NAME]
[SENDER ADDRESS]
[CITY, STATE ZIP]

[DATE]

[RECIPIENT NAME]
[RECIPIENT ADDRESS]
[CITY, STATE ZIP]

Re: Cease and Desist - [VIOLATION TYPE]

Dear [RECIPIENT NAME],

This letter serves as a formal notice to cease and desist all actions described herein...

Sincerely,

[YOUR NAME]
[YOUR TITLE]`);
    } else if (value === "nda") {
      setDocumentTitle("Non-Disclosure Agreement");
      setDocumentContent(`NON-DISCLOSURE AGREEMENT

This Non-Disclosure Agreement (the "Agreement") is entered into as of [DATE] by and between:

[PARTY A NAME], located at [PARTY A ADDRESS] ("Disclosing Party"), and
[PARTY B NAME], located at [PARTY B ADDRESS] ("Receiving Party").

1. Definition of Confidential Information...`);
    }
  };
  
  const UserMessage = ({ content }) => (
    <div className="flex items-start gap-3 mb-4">
      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-navy text-white flex items-center justify-center">
        {userAvatar ? (
          <img src={userAvatar} alt={userName} className="w-8 h-8 rounded-full" />
        ) : (
          <div>{userName.charAt(0)}</div>
        )}
      </div>
      <div className="bg-gray-100 p-3 rounded-lg max-w-[85%]">
        <p className="text-sm">{content}</p>
      </div>
    </div>
  );
  
  const AssistantMessage = ({ content }) => (
    <div className="flex items-start gap-3 mb-4">
      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center">
        <Bot size={18} />
      </div>
      <div className="bg-purple-50 border border-purple-100 p-3 rounded-lg max-w-[85%]">
        <p className="text-sm">{content}</p>
      </div>
    </div>
  );
  
  const LoadingIndicator = () => (
    <div className="flex items-start gap-3 mb-4">
      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center">
        <Bot size={18} />
      </div>
      <div className="bg-purple-50 border border-purple-100 p-3 rounded-lg">
        <div className="flex space-x-2">
          <div className="w-2 h-2 rounded-full bg-purple-400 animate-bounce" style={{ animationDelay: "0ms" }}></div>
          <div className="w-2 h-2 rounded-full bg-purple-400 animate-bounce" style={{ animationDelay: "150ms" }}></div>
          <div className="w-2 h-2 rounded-full bg-purple-400 animate-bounce" style={{ animationDelay: "300ms" }}></div>
        </div>
      </div>
    </div>
  );
  
  return (
    <div className="container mx-auto py-6">
      <div className="flex flex-col space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold">Legal Assistant</h1>
          <div className="flex space-x-2">
            <Button variant="outline" onClick={() => setActiveTab("chat")}>
              Chat
            </Button>
            <Button variant="outline" onClick={handleNewDocument}>
              New Document
            </Button>
          </div>
        </div>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="chat">AI Chat</TabsTrigger>
            <TabsTrigger value="document">Document Editor</TabsTrigger>
            <TabsTrigger value="history">History</TabsTrigger>
          </TabsList>
          
          <TabsContent value="chat" className="border rounded-lg p-4 min-h-[600px] flex flex-col">
            <div className="flex-1 overflow-y-auto mb-4">
              <ScrollArea className="h-[500px] pr-4">
                {messages.map((message, index) => (
                  message.role === "user" ? (
                    <UserMessage key={index} content={message.content} />
                  ) : (
                    <AssistantMessage key={index} content={message.content} />
                  )
                ))}
                {isLoading && <LoadingIndicator />}
                <div ref={messagesEndRef} />
              </ScrollArea>
            </div>
            
            <form onSubmit={handleSendMessage} className="flex items-end gap-2">
              <div className="flex-1 relative">
                <Textarea
                  placeholder="Type your message here..."
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  className="resize-none min-h-[80px]"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="absolute bottom-2 right-2"
                >
                  <Paperclip className="h-5 w-5" />
                </Button>
              </div>
              <Button type="submit" disabled={isLoading || input.trim() === ""}>
                {isLoading ? <Loader2 className="h-5 w-5 animate-spin" /> : <Send className="h-5 w-5" />}
              </Button>
            </form>
          </TabsContent>
          
          <TabsContent value="document" className="border rounded-lg p-4 min-h-[600px]">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="md:col-span-1 space-y-4">
                <div>
                  <h3 className="text-sm font-medium mb-2">Templates</h3>
                  <Select value={selectedTemplate} onValueChange={handleTemplateSelect}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select template" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="blank">Blank Document</SelectItem>
                      <SelectItem value="cease-and-desist">Cease and Desist</SelectItem>
                      <SelectItem value="nda">Non-Disclosure Agreement</SelectItem>
                      <SelectItem value="client-intake">Client Intake Form</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium mb-2">AI Assist</h3>
                  <div className="space-y-2">
                    <Button variant="outline" className="w-full justify-start" size="sm">
                      <Sparkles className="h-4 w-4 mr-2" />
                      Improve Writing
                    </Button>
                    <Button variant="outline" className="w-full justify-start" size="sm">
                      <Sparkles className="h-4 w-4 mr-2" />
                      Simplify Language
                    </Button>
                    <Button variant="outline" className="w-full justify-start" size="sm">
                      <Sparkles className="h-4 w-4 mr-2" />
                      Add Legal Citations
                    </Button>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium mb-2">Actions</h3>
                  <div className="space-y-2">
                    <Button variant="outline" className="w-full justify-start" size="sm" onClick={handleSaveDocument}>
                      <Save className="h-4 w-4 mr-2" />
                      Save Document
                    </Button>
                    <Button variant="outline" className="w-full justify-start" size="sm">
                      <FileText className="h-4 w-4 mr-2" />
                      Export as PDF
                    </Button>
                    <Button variant="outline" className="w-full justify-start" size="sm">
                      <Copy className="h-4 w-4 mr-2" />
                      Copy to Clipboard
                    </Button>
                  </div>
                </div>
              </div>
              
              <div className="md:col-span-3 space-y-4">
                <Input
                  placeholder="Document Title"
                  value={documentTitle}
                  onChange={(e) => setDocumentTitle(e.target.value)}
                  className="text-lg font-medium"
                />
                <Textarea
                  placeholder="Start typing your document content here..."
                  value={documentContent}
                  onChange={(e) => setDocumentContent(e.target.value)}
                  className="min-h-[450px] font-mono text-sm"
                />
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="history" className="border rounded-lg p-4 min-h-[600px]">
            <Tabs defaultValue="chats">
              <TabsList>
                <TabsTrigger value="chats">Chat History</TabsTrigger>
                <TabsTrigger value="documents">Saved Documents</TabsTrigger>
              </TabsList>
              
              <TabsContent value="chats" className="mt-4">
                <div className="space-y-4">
                  {chatHistory.map((chat) => (
                    <Card key={chat.id}>
                      <CardHeader className="py-3">
                        <div className="flex justify-between items-start">
                          <div>
                            <CardTitle className="text-base">{chat.title}</CardTitle>
                            <CardDescription>
                              {chat.date} • {chat.messages} messages
                            </CardDescription>
                          </div>
                          <Badge variant="outline" className="ml-2">
                            <Clock className="h-3 w-3 mr-1" />
                            Recent
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardFooter className="py-2 flex justify-end gap-2">
                        <Button variant="ghost" size="sm">
                          <RotateCcw className="h-4 w-4 mr-1" />
                          Continue
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Copy className="h-4 w-4 mr-1" />
                          Copy
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              </TabsContent>
              
              <TabsContent value="documents" className="mt-4">
                <div className="space-y-4">
                  {savedDocuments.map((doc) => (
                    <Card key={doc.id}>
                      <CardHeader className="py-3">
                        <div className="flex justify-between items-start">
                          <div>
                            <CardTitle className="text-base">{doc.title}</CardTitle>
                            <CardDescription>
                              {doc.date} • {doc.type}
                            </CardDescription>
                          </div>
                          <Badge variant="outline" className="ml-2">
                            {doc.type === "draft" ? (
                              <>
                                <Clock className="h-3 w-3 mr-1" />
                                Draft
                              </>
                            ) : (
                              <>
                                <CheckCircle2 className="h-3 w-3 mr-1" />
                                Final
                              </>
                            )}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardFooter className="py-2 flex justify-end gap-2">
                        <Button variant="ghost" size="sm">
                          <FileText className="h-4 w-4 mr-1" />
                          Edit
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Copy className="h-4 w-4 mr-1" />
                          Duplicate
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default LegalAssistant;
