
import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import {
  Settings as SettingsIcon,
  Bell,
  User,
  Lock,
  Mail,
  Globe,
  Palette,
  Brush,
  SunMedium,
  Moon,
  Monitor,
  Phone
} from "lucide-react";

const Settings = () => {
  const { toast } = useToast();
  const [generalForm, setGeneralForm] = useState({
    firmName: "Johnson & Associates",
    email: "admin@astrus-cms.com",
    phone: "+1 (555) 123-4567",
    timezone: "America/New_York",
    language: "en-US",
    dateFormat: "MM/DD/YYYY",
    timeFormat: "12h"
  });

  const [notifications, setNotifications] = useState({
    email: true,
    push: true,
    sms: false,
    deadlineReminders: true,
    newCaseAssignments: true,
    clientMessages: true,
    documentUpdates: false,
    system: true
  });

  const [appearance, setAppearance] = useState({
    theme: "light",
    density: "comfortable",
    defaultView: "dashboard"
  });

  const [security, setSecurity] = useState({
    twoFactorAuth: true,
    sessionTimeout: "30",
    passwordPolicy: "strong",
    loginAttempts: "5"
  });

  const handleSaveGeneral = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Settings Saved",
      description: "Your general settings have been updated.",
    });
  };

  const handleSaveNotifications = () => {
    toast({
      title: "Notification Settings Updated",
      description: "Your notification preferences have been saved.",
    });
  };

  const handleSaveAppearance = () => {
    toast({
      title: "Appearance Settings Updated",
      description: "Your appearance settings have been updated.",
    });
  };

  const handleSaveSecurity = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Security Settings Updated",
      description: "Your security settings have been saved.",
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">System Settings</h1>
          <p className="text-sm text-gray-500">Configure your Astrus CMS preferences</p>
        </div>
        <Button className="bg-navy hover:bg-navy/90">Save All Changes</Button>
      </div>

      <Tabs defaultValue="general" className="w-full">
        <TabsList className="grid grid-cols-4 w-full max-w-2xl mb-4">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="appearance">Appearance</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
        </TabsList>

        <TabsContent value="general">
          <Card>
            <form onSubmit={handleSaveGeneral}>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <SettingsIcon className="h-5 w-5 text-navy" />
                  <CardTitle>General Settings</CardTitle>
                </div>
                <CardDescription>Configure basic system settings</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="firmName">Firm Name</Label>
                    <Input 
                      id="firmName" 
                      value={generalForm.firmName}
                      onChange={(e) => setGeneralForm({...generalForm, firmName: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Primary Email</Label>
                    <Input 
                      id="email" 
                      type="email"
                      value={generalForm.email}
                      onChange={(e) => setGeneralForm({...generalForm, email: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Contact Phone</Label>
                    <Input 
                      id="phone" 
                      value={generalForm.phone}
                      onChange={(e) => setGeneralForm({...generalForm, phone: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="timezone">Timezone</Label>
                    <Select value={generalForm.timezone} onValueChange={(value) => setGeneralForm({...generalForm, timezone: value})}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select timezone" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="America/New_York">Eastern Time (ET)</SelectItem>
                        <SelectItem value="America/Chicago">Central Time (CT)</SelectItem>
                        <SelectItem value="America/Denver">Mountain Time (MT)</SelectItem>
                        <SelectItem value="America/Los_Angeles">Pacific Time (PT)</SelectItem>
                        <SelectItem value="Europe/London">London (GMT)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <Separator />

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="language">Language</Label>
                    <Select value={generalForm.language} onValueChange={(value) => setGeneralForm({...generalForm, language: value})}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select language" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="en-US">English (US)</SelectItem>
                        <SelectItem value="en-GB">English (UK)</SelectItem>
                        <SelectItem value="es">Spanish</SelectItem>
                        <SelectItem value="fr">French</SelectItem>
                        <SelectItem value="de">German</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="dateFormat">Date Format</Label>
                    <Select value={generalForm.dateFormat} onValueChange={(value) => setGeneralForm({...generalForm, dateFormat: value})}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select date format" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="MM/DD/YYYY">MM/DD/YYYY</SelectItem>
                        <SelectItem value="DD/MM/YYYY">DD/MM/YYYY</SelectItem>
                        <SelectItem value="YYYY-MM-DD">YYYY-MM-DD</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="timeFormat">Time Format</Label>
                    <Select value={generalForm.timeFormat} onValueChange={(value) => setGeneralForm({...generalForm, timeFormat: value})}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select time format" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="12h">12-hour (AM/PM)</SelectItem>
                        <SelectItem value="24h">24-hour</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-end">
                <Button type="submit" className="bg-navy hover:bg-navy/90">Save General Settings</Button>
              </CardFooter>
            </form>
          </Card>
        </TabsContent>

        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Bell className="h-5 w-5 text-navy" />
                <CardTitle>Notification Preferences</CardTitle>
              </div>
              <CardDescription>Configure how you receive notifications</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="space-y-2">
                  <Label className="text-base">Notification Channels</Label>
                  <div className="grid grid-cols-1 gap-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Mail className="h-4 w-4 text-gray-500" />
                        <Label htmlFor="email-notifications" className="font-normal">Email Notifications</Label>
                      </div>
                      <Switch 
                        id="email-notifications" 
                        checked={notifications.email}
                        onCheckedChange={(checked) => setNotifications({...notifications, email: checked})}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Bell className="h-4 w-4 text-gray-500" />
                        <Label htmlFor="push-notifications" className="font-normal">Push Notifications</Label>
                      </div>
                      <Switch 
                        id="push-notifications"
                        checked={notifications.push}
                        onCheckedChange={(checked) => setNotifications({...notifications, push: checked})}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Phone className="h-4 w-4 text-gray-500" />
                        <Label htmlFor="sms-notifications" className="font-normal">SMS Notifications</Label>
                      </div>
                      <Switch 
                        id="sms-notifications"
                        checked={notifications.sms}
                        onCheckedChange={(checked) => setNotifications({...notifications, sms: checked})}
                      />
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div className="space-y-2">
                  <Label className="text-base">Events</Label>
                  <div className="grid grid-cols-1 gap-4">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="deadline-reminders" className="font-normal">Deadline Reminders</Label>
                      <Switch 
                        id="deadline-reminders"
                        checked={notifications.deadlineReminders}
                        onCheckedChange={(checked) => setNotifications({...notifications, deadlineReminders: checked})}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label htmlFor="case-assignments" className="font-normal">New Case Assignments</Label>
                      <Switch 
                        id="case-assignments"
                        checked={notifications.newCaseAssignments}
                        onCheckedChange={(checked) => setNotifications({...notifications, newCaseAssignments: checked})}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label htmlFor="client-messages" className="font-normal">Client Messages</Label>
                      <Switch 
                        id="client-messages"
                        checked={notifications.clientMessages}
                        onCheckedChange={(checked) => setNotifications({...notifications, clientMessages: checked})}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label htmlFor="document-updates" className="font-normal">Document Updates</Label>
                      <Switch 
                        id="document-updates"
                        checked={notifications.documentUpdates}
                        onCheckedChange={(checked) => setNotifications({...notifications, documentUpdates: checked})}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label htmlFor="system-notifications" className="font-normal">System Notifications</Label>
                      <Switch 
                        id="system-notifications"
                        checked={notifications.system}
                        onCheckedChange={(checked) => setNotifications({...notifications, system: checked})}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button onClick={handleSaveNotifications} className="bg-navy hover:bg-navy/90">
                Save Notification Settings
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="appearance">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Palette className="h-5 w-5 text-navy" />
                <CardTitle>Appearance</CardTitle>
              </div>
              <CardDescription>Customize the look and feel of Astrus CMS</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label className="text-base">Theme</Label>
                <div className="grid grid-cols-3 gap-4 pt-2">
                  <div 
                    className={`cursor-pointer flex flex-col items-center justify-center p-4 rounded-lg border-2 ${appearance.theme === 'light' ? 'border-navy bg-gray-50' : 'border-gray-200'}`}
                    onClick={() => setAppearance({...appearance, theme: 'light'})}
                  >
                    <SunMedium className="h-6 w-6 mb-2 text-yellow-500" />
                    <span className="text-sm font-medium">Light</span>
                  </div>
                  <div 
                    className={`cursor-pointer flex flex-col items-center justify-center p-4 rounded-lg border-2 ${appearance.theme === 'dark' ? 'border-navy bg-gray-50' : 'border-gray-200'}`}
                    onClick={() => setAppearance({...appearance, theme: 'dark'})}
                  >
                    <Moon className="h-6 w-6 mb-2 text-indigo-600" />
                    <span className="text-sm font-medium">Dark</span>
                  </div>
                  <div 
                    className={`cursor-pointer flex flex-col items-center justify-center p-4 rounded-lg border-2 ${appearance.theme === 'system' ? 'border-navy bg-gray-50' : 'border-gray-200'}`}
                    onClick={() => setAppearance({...appearance, theme: 'system'})}
                  >
                    <Monitor className="h-6 w-6 mb-2 text-gray-600" />
                    <span className="text-sm font-medium">System</span>
                  </div>
                </div>
              </div>
              
              <Separator />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="density">Display Density</Label>
                  <Select value={appearance.density} onValueChange={(value) => setAppearance({...appearance, density: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select display density" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="comfortable">Comfortable</SelectItem>
                      <SelectItem value="compact">Compact</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="defaultView">Default View</Label>
                  <Select value={appearance.defaultView} onValueChange={(value) => setAppearance({...appearance, defaultView: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select default view" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="dashboard">Dashboard</SelectItem>
                      <SelectItem value="cases">Cases</SelectItem>
                      <SelectItem value="tasks">Tasks</SelectItem>
                      <SelectItem value="calendar">Calendar</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button onClick={handleSaveAppearance} className="bg-navy hover:bg-navy/90">Save Appearance Settings</Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="security">
          <Card>
            <form onSubmit={handleSaveSecurity}>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Lock className="h-5 w-5 text-navy" />
                  <CardTitle>Security Settings</CardTitle>
                </div>
                <CardDescription>Configure security and access settings</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="two-factor">Two-Factor Authentication</Label>
                    <p className="text-sm text-gray-500">Require two-factor authentication for all users</p>
                  </div>
                  <Switch 
                    id="two-factor"
                    checked={security.twoFactorAuth}
                    onCheckedChange={(checked) => setSecurity({...security, twoFactorAuth: checked})}
                  />
                </div>
                
                <Separator />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="sessionTimeout">Session Timeout (minutes)</Label>
                    <Input 
                      id="sessionTimeout" 
                      type="number"
                      value={security.sessionTimeout}
                      onChange={(e) => setSecurity({...security, sessionTimeout: e.target.value})}
                    />
                    <p className="text-xs text-gray-500">Time before automatic logout due to inactivity</p>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="loginAttempts">Max Login Attempts</Label>
                    <Input 
                      id="loginAttempts" 
                      type="number"
                      value={security.loginAttempts}
                      onChange={(e) => setSecurity({...security, loginAttempts: e.target.value})}
                    />
                    <p className="text-xs text-gray-500">Number of failed login attempts before lockout</p>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="passwordPolicy">Password Policy</Label>
                  <Select value={security.passwordPolicy} onValueChange={(value) => setSecurity({...security, passwordPolicy: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select password policy" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="basic">Basic (8+ characters)</SelectItem>
                      <SelectItem value="moderate">Moderate (8+ chars, uppercase, lowercase)</SelectItem>
                      <SelectItem value="strong">Strong (8+ chars, uppercase, lowercase, number, symbol)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
              <CardFooter className="flex justify-end">
                <Button type="submit" className="bg-navy hover:bg-navy/90">Save Security Settings</Button>
              </CardFooter>
            </form>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Settings;
