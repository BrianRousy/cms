
import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import {
  Workflow as WorkflowIcon,
  Plus,
  Search,
  ArrowRight,
  CheckCircle2,
  Clock,
  FileText,
  Mail,
  MessageSquare,
  AlertCircle,
  Calendar,
  BarChart,
  Play,
  Pause,
  Copy,
  Edit,
  Trash2,
  FileUp,
  ExternalLink
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";

// Mock workflow templates
const workflowTemplates = [
  {
    id: "1",
    name: "New Client Onboarding",
    description: "Automated workflow for onboarding new clients",
    category: "Client Management",
    steps: 8,
    status: "active"
  },
  {
    id: "2",
    name: "Document Review Process",
    description: "Standard document review and approval workflow",
    category: "Document Management",
    steps: 5,
    status: "active"
  },
  {
    id: "3",
    name: "Court Filing Preparation",
    description: "Workflow for preparing and filing court documents",
    category: "Litigation",
    steps: 12,
    status: "active"
  },
  {
    id: "4",
    name: "Case Closure Process",
    description: "Steps for properly closing a legal case",
    category: "Case Management",
    steps: 7,
    status: "inactive"
  },
  {
    id: "5",
    name: "Invoice Generation & Delivery",
    description: "Automatic invoice creation and delivery workflow",
    category: "Billing",
    steps: 4,
    status: "active"
  }
];

// Mock workflow steps for the onboarding template
const onboardingSteps = [
  {
    id: "step1",
    name: "Initial Client Contact",
    type: "manual",
    assignedTo: "User",
    description: "Record initial client information and case details",
    status: "completed"
  },
  {
    id: "step2",
    name: "Send Welcome Email",
    type: "automated",
    description: "Automatically send welcome email with intake forms",
    trigger: "Previous step completion",
    status: "completed"
  },
  {
    id: "step3",
    name: "Collect Client Documents",
    type: "manual",
    assignedTo: "User",
    description: "Gather and organize all required client documents",
    status: "in_progress" 
  },
  {
    id: "step4",
    name: "Conflict Check",
    type: "automated",
    description: "Run automated conflict check against client database",
    trigger: "Previous step completion",
    status: "pending"
  },
  {
    id: "step5",
    name: "Fee Agreement Creation",
    type: "automated",
    description: "Generate fee agreement based on case type",
    trigger: "Conflict check approval",
    status: "pending"
  },
  {
    id: "step6",
    name: "Client Portal Setup",
    type: "automated", 
    description: "Create client portal access and send credentials",
    trigger: "Fee agreement signed",
    status: "pending"
  },
  {
    id: "step7",
    name: "Case File Creation",
    type: "automated",
    description: "Create standardized case file structure in document system",
    trigger: "Client portal setup complete",
    status: "pending"
  },
  {
    id: "step8",
    name: "Initial Strategy Meeting",
    type: "manual",
    assignedTo: "Attorney",
    description: "Schedule and conduct initial strategy meeting with client",
    status: "pending"
  }
];

// Mock integrations
const integrations = [
  {
    id: "microsoft",
    name: "Microsoft Office 365",
    description: "Connect to Office apps and services",
    icon: "M",
    status: "connected",
    type: "document"
  },
  {
    id: "google",
    name: "Google Workspace",
    description: "Connect to Gmail, Calendar, and Drive",
    icon: "G",
    status: "connected",
    type: "document"
  },
  {
    id: "docusign",
    name: "DocuSign",
    description: "Electronic signature integration",
    icon: "D",
    status: "not_connected",
    type: "document"
  },
  {
    id: "quickbooks",
    name: "QuickBooks",
    description: "Accounting software integration",
    icon: "Q",
    status: "connected",
    type: "finance"
  },
  {
    id: "zapier",
    name: "Zapier",
    description: "Connect to 3,000+ other apps",
    icon: "Z",
    status: "not_connected",
    type: "automation"
  },
  {
    id: "dropbox",
    name: "Dropbox",
    description: "Cloud storage integration",
    icon: "D",
    status: "not_connected",
    type: "document"
  }
];

const Workflow = () => {
  const [activeTab, setActiveTab] = useState("templates");
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();
  const [selectedTemplate, setSelectedTemplate] = useState(workflowTemplates[0]);
  
  const handleCreateWorkflow = () => {
    toast({
      title: "Workflow Created",
      description: "New workflow has been created successfully",
    });
  };
  
  const handleActivateWorkflow = (id: string) => {
    toast({
      title: "Workflow Activated",
      description: "Workflow has been activated successfully",
    });
  };
  
  const handleConnectIntegration = (id: string) => {
    toast({
      title: "Integration Connected",
      description: `Successfully connected to ${integrations.find(i => i.id === id)?.name}`,
    });
  };

  // Filter templates based on search query
  const filteredTemplates = workflowTemplates.filter(template => {
    if (!searchQuery) return true;
    
    return (
      template.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      template.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      template.category.toLowerCase().includes(searchQuery.toLowerCase())
    );
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Workflow Automation</h1>
          <p className="text-sm text-gray-500">
            Create and manage automated workflows for your firm
          </p>
        </div>
        <Dialog>
          <DialogTrigger asChild>
            <Button className="bg-navy hover:bg-navy/90">
              <Plus className="mr-2 h-4 w-4" />
              Create Workflow
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Create New Workflow</DialogTitle>
              <DialogDescription>
                Set up a new automated workflow for your processes
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <label htmlFor="name" className="text-sm font-medium">Workflow Name</label>
                <Input id="name" placeholder="Enter workflow name" />
              </div>
              
              <div className="grid gap-2">
                <label htmlFor="description" className="text-sm font-medium">Description</label>
                <Textarea id="description" placeholder="Describe the purpose of this workflow" />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <label htmlFor="category" className="text-sm font-medium">Category</label>
                  <Select>
                    <SelectTrigger id="category">
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="client">Client Management</SelectItem>
                      <SelectItem value="case">Case Management</SelectItem>
                      <SelectItem value="document">Document Management</SelectItem>
                      <SelectItem value="billing">Billing & Payments</SelectItem>
                      <SelectItem value="litigation">Litigation</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <label htmlFor="trigger" className="text-sm font-medium">Initial Trigger</label>
                  <Select>
                    <SelectTrigger id="trigger">
                      <SelectValue placeholder="Select trigger" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="manual">Manual Start</SelectItem>
                      <SelectItem value="new_client">New Client Created</SelectItem>
                      <SelectItem value="new_case">New Case Created</SelectItem>
                      <SelectItem value="document_upload">Document Uploaded</SelectItem>
                      <SelectItem value="deadline">Approaching Deadline</SelectItem>
                      <SelectItem value="custom">Custom Trigger</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="border-t pt-4 mt-2">
                <h4 className="font-medium mb-3">Start from Template (Optional)</h4>
                <div className="space-y-2">
                  {workflowTemplates.slice(0, 3).map((template) => (
                    <div key={template.id} className="flex items-center space-x-2 border rounded-md p-2">
                      <input
                        type="radio"
                        id={`template-${template.id}`}
                        name="template"
                        className="rounded border-gray-300"
                      />
                      <label htmlFor={`template-${template.id}`} className="text-sm flex-1">
                        <div className="font-medium">{template.name}</div>
                        <div className="text-xs text-gray-500">{template.description}</div>
                      </label>
                      <Badge className="bg-gray-200 text-gray-700">{template.steps} steps</Badge>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline">Cancel</Button>
              <Button onClick={handleCreateWorkflow}>
                Create Workflow
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="templates" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="w-full md:w-auto grid grid-cols-3 md:inline-flex">
          <TabsTrigger value="templates">Workflow Templates</TabsTrigger>
          <TabsTrigger value="active">Active Workflows</TabsTrigger>
          <TabsTrigger value="integrations">Integrations</TabsTrigger>
        </TabsList>
        
        <TabsContent value="templates" className="mt-6">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                  <CardTitle>Workflow Templates</CardTitle>
                  <CardDescription>
                    Pre-built workflow templates for common legal processes
                  </CardDescription>
                </div>
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                  <Input 
                    placeholder="Search templates..." 
                    className="pl-8 w-full md:w-60" 
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {filteredTemplates.map((template) => (
                  <div
                    key={template.id}
                    className={`border ${template.id === selectedTemplate.id ? 'border-navy' : ''} rounded-lg p-4 cursor-pointer hover:border-navy transition-colors`}
                    onClick={() => setSelectedTemplate(template)}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-medium">{template.name}</h3>
                        <p className="text-sm text-gray-500 mt-1">{template.description}</p>
                        <div className="flex items-center space-x-2 mt-2">
                          <Badge variant="outline" className="bg-gray-100">
                            {template.category}
                          </Badge>
                          <span className="text-xs text-gray-500">
                            {template.steps} steps
                          </span>
                        </div>
                      </div>
                      <Badge 
                        className={template.status === "active" ? "bg-green-600" : "bg-gray-400"}
                      >
                        {template.status === "active" ? "Active" : "Inactive"}
                      </Badge>
                    </div>
                    <div className="mt-4 flex items-center justify-end space-x-2">
                      <Button variant="outline" size="sm">View Details</Button>
                      
                      {template.status !== "active" ? (
                        <Button 
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleActivateWorkflow(template.id);
                          }}
                        >
                          <Play className="h-4 w-4 mr-1" />
                          Activate
                        </Button>
                      ) : (
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            toast({
                              title: "Workflow Copied",
                              description: `A copy of "${template.name}" has been created`,
                            });
                          }}
                        >
                          <Copy className="h-4 w-4 mr-1" />
                          Clone
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
          
          <div className="mt-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Workflow Detail: {selectedTemplate.name}</CardTitle>
                    <CardDescription>{selectedTemplate.description}</CardDescription>
                  </div>
                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm">
                      <Edit className="h-4 w-4 mr-1" />
                      Edit
                    </Button>
                    <Button variant="outline" size="sm">
                      <Copy className="h-4 w-4 mr-1" />
                      Clone
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <div className="border-t py-4 px-6">
                  <h3 className="text-sm font-medium mb-3">Workflow Steps</h3>
                </div>
                
                <div className="divide-y">
                  {onboardingSteps.map((step, index) => (
                    <div key={step.id} className="flex items-start p-6">
                      <div className="flex-shrink-0 mr-4">
                        {step.status === "completed" ? (
                          <div className="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center text-green-600">
                            <CheckCircle2 className="h-5 w-5" />
                          </div>
                        ) : step.status === "in_progress" ? (
                          <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-600">
                            <Clock className="h-5 w-5" />
                          </div>
                        ) : (
                          <div className="h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center text-gray-600">
                            {index + 1}
                          </div>
                        )}
                        
                        {index < onboardingSteps.length - 1 && (
                          <div className="h-full ml-4 border-l border-dashed border-gray-300" style={{height: '40px'}}></div>
                        )}
                      </div>
                      
                      <div className="flex-1">
                        <div className="flex items-start justify-between">
                          <div>
                            <h4 className="font-medium">{step.name}</h4>
                            <p className="text-sm text-gray-500 mt-1">{step.description}</p>
                          </div>
                          <Badge 
                            className={
                              step.status === "completed" ? "bg-green-600" : 
                              step.status === "in_progress" ? "bg-blue-600" : "bg-gray-400"
                            }
                          >
                            {step.status === "completed" ? "Completed" : 
                             step.status === "in_progress" ? "In Progress" : "Pending"}
                          </Badge>
                        </div>
                        
                        <div className="flex items-center mt-3 text-xs text-gray-500 space-x-3">
                          <div className="flex items-center">
                            <Badge variant="outline" className="bg-gray-100 mr-2">
                              {step.type === "automated" ? "Automated" : "Manual"}
                            </Badge>
                          </div>
                          
                          {step.type === "automated" && step.trigger && (
                            <div className="flex items-center">
                              <span>Trigger: {step.trigger}</span>
                            </div>
                          )}
                          
                          {step.type === "manual" && step.assignedTo && (
                            <div className="flex items-center">
                              <span>Assigned to: {step.assignedTo}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
              <CardFooter className="border-t flex justify-between">
                <Button variant="outline" onClick={() => toast({
                  title: "Download Complete",
                  description: `Workflow "${selectedTemplate.name}" has been downloaded as PDF`,
                })}>
                  <FileUp className="h-4 w-4 mr-2" />
                  Export Workflow
                </Button>
                
                {selectedTemplate.status !== "active" ? (
                  <Button onClick={() => handleActivateWorkflow(selectedTemplate.id)}>
                    <Play className="h-4 w-4 mr-2" />
                    Activate Workflow
                  </Button>
                ) : (
                  <Button variant="outline" className="border-red-200 text-red-600 hover:bg-red-50 hover:text-red-700">
                    <Pause className="h-4 w-4 mr-2" />
                    Deactivate Workflow
                  </Button>
                )}
              </CardFooter>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="active" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Active Workflows</CardTitle>
              <CardDescription>
                Monitor and manage your currently active workflows
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {workflowTemplates
                  .filter(template => template.status === "active")
                  .map((workflow) => (
                  <div key={workflow.id} className="border rounded-lg p-4">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="font-medium">{workflow.name}</h3>
                        <p className="text-sm text-gray-500 mt-1">{workflow.description}</p>
                      </div>
                      <div className="flex flex-col items-end">
                        <Badge className="bg-green-600 mb-2">Active</Badge>
                        <span className="text-xs text-gray-500">12 instances</span>
                      </div>
                    </div>
                    
                    <div className="bg-gray-50 rounded-md p-3 mb-4">
                      <h4 className="text-sm font-medium mb-2">Active Instances</h4>
                      <div className="space-y-3">
                        {[
                          { client: "John Smith", case: "Smith v. Jones", progress: 75 },
                          { client: "ABC Corporation", case: "Merger Documentation", progress: 30 },
                          { client: "Estate of Williams", case: "Will Execution", progress: 50 },
                        ].map((instance, idx) => (
                          <div key={idx} className="flex items-center space-x-3">
                            <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center text-xs">
                              {instance.client.split(" ").map(n => n[0]).join("")}
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center justify-between text-sm">
                                <span>{instance.case}</span>
                                <span className="text-xs text-gray-500">{instance.progress}% complete</span>
                              </div>
                              <div className="w-full bg-gray-200 rounded-full h-1.5 mt-1">
                                <div
                                  className={`h-1.5 rounded-full ${
                                    instance.progress > 60 ? "bg-green-600" :
                                    instance.progress > 30 ? "bg-blue-600" : "bg-amber-500"
                                  }`}
                                  style={{ width: `${instance.progress}%` }}
                                ></div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Badge variant="outline" className="bg-gray-100">
                          {workflow.category}
                        </Badge>
                        <span className="text-xs text-gray-500">
                          Last triggered 2 hours ago
                        </span>
                      </div>
                      <div className="space-x-2">
                        <Button variant="outline" size="sm" onClick={() => toast({
                          title: "Workflow Paused",
                          description: `"${workflow.name}" has been paused`,
                        })}>
                          <Pause className="h-4 w-4 mr-1" />
                          Pause
                        </Button>
                        <Button variant="ghost" size="sm">
                          View Details
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
                
                <div className="text-center py-4 border rounded-lg border-dashed">
                  <WorkflowIcon className="h-10 w-10 text-gray-300 mx-auto mb-3" />
                  <h3 className="text-lg font-medium text-gray-700">Create a New Workflow</h3>
                  <p className="text-sm text-gray-500 mt-1 mb-4 max-w-md mx-auto">
                    Automate repetitive tasks and standardize processes by creating a new workflow.
                  </p>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="h-4 w-4 mr-2" />
                        Create Workflow
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      {/* Use the same dialog content as in the main create workflow button */}
                    </DialogContent>
                  </Dialog>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <div className="grid gap-6 md:grid-cols-2 mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Workflow Analytics</CardTitle>
                <CardDescription>Performance metrics for your workflows</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid gap-4 grid-cols-2">
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <p className="text-sm text-gray-500 mb-1">Active Workflows</p>
                      <p className="text-2xl font-semibold">4</p>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <p className="text-sm text-gray-500 mb-1">Instances</p>
                      <p className="text-2xl font-semibold">27</p>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <p className="text-sm text-gray-500 mb-1">Avg. Completion</p>
                      <p className="text-2xl font-semibold">3.2 days</p>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <p className="text-sm text-gray-500 mb-1">Success Rate</p>
                      <p className="text-2xl font-semibold">94%</p>
                    </div>
                  </div>
                  
                  <div className="pt-4">
                    <h4 className="text-sm font-medium mb-3">Most Active Workflows</h4>
                    <div className="space-y-2">
                      {[
                        { name: "New Client Onboarding", instances: 12, percentage: 45 },
                        { name: "Document Review Process", instances: 8, percentage: 30 },
                        { name: "Court Filing Preparation", instances: 4, percentage: 15 },
                        { name: "Invoice Generation", instances: 3, percentage: 10 },
                      ].map((workflow, idx) => (
                        <div key={idx} className="space-y-1">
                          <div className="flex justify-between text-sm">
                            <span>{workflow.name}</span>
                            <span className="text-gray-500">{workflow.instances} instances</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div
                              className="bg-navy h-2 rounded-full"
                              style={{ width: `${workflow.percentage}%` }}
                            ></div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
                <CardDescription>Latest workflow events and actions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { icon: CheckCircle2, color: "text-green-600", bg: "bg-green-100", title: "Workflow Completed", description: "New Client Onboarding for Smith v. Jones", time: "10 minutes ago" },
                    { icon: AlertCircle, color: "text-amber-600", bg: "bg-amber-100", title: "Manual Approval Needed", description: "Document Review Process - Contract Review", time: "1 hour ago" },
                    { icon: Mail, color: "text-blue-600", bg: "bg-blue-100", title: "Email Notification Sent", description: "Court Filing Preparation - Filing Deadline", time: "2 hours ago" },
                    { icon: FileText, color: "text-gray-600", bg: "bg-gray-100", title: "Document Generated", description: "Fee Agreement for ABC Corporation", time: "5 hours ago" },
                    { icon: Play, color: "text-green-600", bg: "bg-green-100", title: "Workflow Started", description: "Invoice Generation for Williams Estate", time: "1 day ago" },
                  ].map((activity, idx) => (
                    <div key={idx} className="flex items-start space-x-3">
                      <div className={`h-8 w-8 rounded-full ${activity.bg} flex items-center justify-center ${activity.color}`}>
                        <activity.icon className="h-4 w-4" />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">{activity.title}</p>
                        <p className="text-xs text-gray-500">{activity.description}</p>
                        <p className="text-xs text-gray-400 mt-1">{activity.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
              <CardFooter className="border-t">
                <Button variant="ghost" className="w-full" size="sm">
                  View All Activity
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="integrations" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>System Integrations</CardTitle>
              <CardDescription>
                Connect external apps and services to enhance workflow automation
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2">
                {integrations.map((integration) => (
                  <div key={integration.id} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className={`h-10 w-10 rounded-md ${
                          integration.type === "document" ? "bg-blue-100 text-blue-600" :
                          integration.type === "finance" ? "bg-green-100 text-green-600" :
                          "bg-purple-100 text-purple-600"
                        } flex items-center justify-center font-bold`}>
                          {integration.icon}
                        </div>
                        <div>
                          <h4 className="font-medium">{integration.name}</h4>
                          <p className="text-xs text-gray-500">{integration.description}</p>
                        </div>
                      </div>
                      <div>
                        {integration.status === "connected" ? (
                          <Badge className="bg-green-600">Connected</Badge>
                        ) : (
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => handleConnectIntegration(integration.id)}
                          >
                            Connect
                          </Button>
                        )}
                      </div>
                    </div>
                    
                    {integration.status === "connected" && (
                      <div className="mt-4 flex items-center justify-between">
                        <div className="text-xs text-gray-500">
                          Last synced: 30 minutes ago
                        </div>
                        <div className="space-x-2">
                          <Button size="sm" variant="ghost">
                            <ExternalLink className="h-3 w-3 mr-1" />
                            Open
                          </Button>
                          <Button size="sm" variant="ghost" onClick={() => toast({
                            title: "Sync Started",
                            description: `Syncing data with ${integration.name}`,
                          })}>
                            Sync Now
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
                
                <div className="border border-dashed rounded-lg p-4 flex flex-col items-center justify-center text-center">
                  <Plus className="h-8 w-8 text-gray-300 mb-2" />
                  <h4 className="font-medium">Add Custom Integration</h4>
                  <p className="text-xs text-gray-500 mt-1 mb-3">
                    Connect to additional services via API
                  </p>
                  <Button size="sm" onClick={() => toast({
                    title: "Coming Soon",
                    description: "Custom API integrations will be available soon",
                  })}>
                    Add Integration
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <div className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>API Access</CardTitle>
                <CardDescription>Access the LawFirm Pro API for custom integrations</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium mb-2">API Key</h3>
                    <div className="flex items-center justify-between">
                      <div className="relative flex-1 mr-4">
                        <Input 
                          type="password" 
                          value="••••••••••••••••••••••••••••••"
                          disabled
                          className="pr-12"
                        />
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="absolute right-0 top-0 h-full"
                          onClick={() => toast({
                            title: "API Key Copied",
                            description: "API key has been copied to clipboard",
                          })}
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                      </div>
                      <Button onClick={() => toast({
                        title: "API Key Regenerated",
                        description: "A new API key has been generated",
                      })}>
                        Regenerate Key
                      </Button>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium mb-3">Available Endpoints</h3>
                    <div className="rounded-md border divide-y">
                      {[
                        { method: "GET", endpoint: "/api/v1/cases", description: "Retrieve case information" },
                        { method: "POST", endpoint: "/api/v1/documents", description: "Upload and manage documents" },
                        { method: "GET", endpoint: "/api/v1/clients", description: "Access client data" },
                        { method: "POST", endpoint: "/api/v1/workflow", description: "Trigger workflow actions" },
                      ].map((api, idx) => (
                        <div key={idx} className="flex items-center p-3">
                          <Badge 
                            variant="outline" 
                            className={api.method === "GET" ? "bg-blue-100 text-blue-800" : "bg-green-100 text-green-800"}
                          >
                            {api.method}
                          </Badge>
                          <code className="mx-3 bg-gray-100 px-1 py-0.5 rounded text-sm">
                            {api.endpoint}
                          </code>
                          <span className="text-sm text-gray-500 flex-1">{api.description}</span>
                          <Button variant="ghost" size="sm">
                            Docs
                          </Button>
                        </div>
                      ))}
                    </div>
                    <div className="flex justify-end mt-4">
                      <Button variant="outline" onClick={() => toast({
                        title: "Documentation Opened",
                        description: "API documentation will open in a new tab",
                      })}>
                        View Full API Documentation
                      </Button>
                    </div>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium mb-2">Webhook Configuration</h3>
                    <p className="text-xs text-gray-500 mb-4">
                      Configure webhooks to notify your systems when events occur in LawFirm Pro
                    </p>
                    <div className="space-y-3">
                      <div className="grid gap-2">
                        <label className="text-xs font-medium">Webhook URL</label>
                        <Input placeholder="https://your-app.com/webhook" />
                      </div>
                      <div className="grid gap-2">
                        <label className="text-xs font-medium">Events to Subscribe</label>
                        <div className="grid grid-cols-2 gap-2">
                          <div className="flex items-center space-x-2">
                            <input type="checkbox" id="case-created" className="rounded border-gray-300" />
                            <label htmlFor="case-created" className="text-xs">Case Created</label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <input type="checkbox" id="doc-uploaded" className="rounded border-gray-300" />
                            <label htmlFor="doc-uploaded" className="text-xs">Document Uploaded</label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <input type="checkbox" id="workflow-complete" className="rounded border-gray-300" />
                            <label htmlFor="workflow-complete" className="text-xs">Workflow Completed</label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <input type="checkbox" id="deadline-approach" className="rounded border-gray-300" />
                            <label htmlFor="deadline-approach" className="text-xs">Deadline Approaching</label>
                          </div>
                        </div>
                      </div>
                      <Button className="w-full" onClick={() => toast({
                        title: "Webhook Saved",
                        description: "Your webhook configuration has been saved",
                      })}>
                        Save Webhook Configuration
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Workflow;
