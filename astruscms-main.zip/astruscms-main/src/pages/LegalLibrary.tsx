
import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Search, Plus, FileText, BookOpen, Filter, Download, Share, Clock } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

// Mock data for legal resources
const legalResources = [
  {
    id: "1",
    title: "Contract Drafting Templates",
    category: "templates",
    type: "document",
    dateAdded: "2023-12-15",
    lastUpdated: "2024-02-20",
    tags: ["contracts", "templates", "commercial"],
    downloads: 145,
    description: "A collection of standard contract templates for various business needs"
  },
  {
    id: "2",
    title: "Litigation Procedure Guide",
    category: "guides",
    type: "document",
    dateAdded: "2023-11-10",
    lastUpdated: "2024-03-05",
    tags: ["litigation", "procedure", "court"],
    downloads: 87,
    description: "Comprehensive guide on litigation procedures and best practices"
  },
  {
    id: "3",
    title: "Employment Law Update 2024",
    category: "research",
    type: "document",
    dateAdded: "2024-01-25",
    lastUpdated: "2024-01-25",
    tags: ["employment", "labor", "legal updates"],
    downloads: 112,
    description: "Latest updates on employment law changes for 2024"
  },
  {
    id: "4",
    title: "Patent Application Templates",
    category: "templates",
    type: "document",
    dateAdded: "2023-09-18",
    lastUpdated: "2024-02-12",
    tags: ["patents", "intellectual property", "templates"],
    downloads: 56,
    description: "Standard templates and guides for patent applications"
  },
  {
    id: "5",
    title: "Tax Law Research Materials",
    category: "research",
    type: "document",
    dateAdded: "2023-10-30",
    lastUpdated: "2024-03-18",
    tags: ["tax", "research", "irs"],
    downloads: 93,
    description: "Research materials and case studies on tax law"
  },
];

const LegalLibrary = () => {
  const [activeTab, setActiveTab] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();
  
  const filteredResources = legalResources.filter(resource => {
    // Filter by tab
    if (activeTab !== "all" && resource.category !== activeTab) {
      return false;
    }
    
    // Filter by search query
    if (searchQuery && !resource.title.toLowerCase().includes(searchQuery.toLowerCase()) &&
        !resource.description.toLowerCase().includes(searchQuery.toLowerCase()) &&
        !resource.tags.join(" ").toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    
    return true;
  });

  const handleDownload = (resourceId: string) => {
    const resource = legalResources.find(r => r.id === resourceId);
    toast({
      title: "Download Started",
      description: `Downloading "${resource?.title}"`,
    });
  };

  const handleAddResource = (data: any) => {
    toast({
      title: "Resource Added",
      description: "The resource has been added to the library",
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold">Legal Resource Library</h1>
          <p className="text-sm text-gray-500">
            Access legal templates, research materials, and guides
          </p>
        </div>
        
        <Dialog>
          <DialogTrigger asChild>
            <Button className="bg-navy hover:bg-navy/90">
              <Plus className="mr-2 h-4 w-4" />
              Add Resource
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[550px]">
            <DialogHeader>
              <DialogTitle>Add New Resource</DialogTitle>
              <DialogDescription>
                Upload a new document or link to the legal resource library
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <label htmlFor="title" className="text-sm font-medium">Title</label>
                <Input id="title" placeholder="Resource title" />
              </div>
              <div className="grid gap-2">
                <label htmlFor="description" className="text-sm font-medium">Description</label>
                <Input id="description" placeholder="Resource description" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <label htmlFor="category" className="text-sm font-medium">Category</label>
                  <Select>
                    <SelectTrigger id="category">
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="templates">Templates</SelectItem>
                      <SelectItem value="guides">Guides</SelectItem>
                      <SelectItem value="research">Research</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <label htmlFor="tags" className="text-sm font-medium">Tags</label>
                  <Input id="tags" placeholder="Enter tags, separated by commas" />
                </div>
              </div>
              <div className="grid gap-2">
                <label className="text-sm font-medium">Upload File</label>
                <div className="border-2 border-dashed border-gray-300 rounded-md p-6 flex flex-col items-center">
                  <FileText className="h-10 w-10 text-gray-400 mb-2" />
                  <p className="text-sm text-gray-500 mb-2">Drag and drop your file here, or click to browse</p>
                  <Button variant="outline" size="sm">Choose File</Button>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button type="submit" onClick={() => handleAddResource({})}>
                Add Resource
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader className="space-y-1">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <CardTitle>Legal Resources</CardTitle>
            <div className="relative w-full md:w-72">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
              <Input
                placeholder="Search resources..."
                className="pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
          <CardDescription>
            Access legal templates, research materials, and precedent documents
          </CardDescription>
        </CardHeader>
        <div className="px-6">
          <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-4 mb-4">
              <TabsTrigger value="all">All Resources</TabsTrigger>
              <TabsTrigger value="templates">Templates</TabsTrigger>
              <TabsTrigger value="guides">Guides</TabsTrigger>
              <TabsTrigger value="research">Research</TabsTrigger>
            </TabsList>
            <TabsContent value="all" className="mt-0">
              {renderResourceList(filteredResources, handleDownload)}
            </TabsContent>
            <TabsContent value="templates" className="mt-0">
              {renderResourceList(filteredResources, handleDownload)}
            </TabsContent>
            <TabsContent value="guides" className="mt-0">
              {renderResourceList(filteredResources, handleDownload)}
            </TabsContent>
            <TabsContent value="research" className="mt-0">
              {renderResourceList(filteredResources, handleDownload)}
            </TabsContent>
          </Tabs>
        </div>
      </Card>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Recently Viewed</CardTitle>
            <CardDescription>Resources you've accessed recently</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {legalResources.slice(0, 3).map((resource) => (
                <div key={resource.id} className="flex items-center space-x-3">
                  <div className="h-10 w-10 rounded-md bg-gray-100 flex items-center justify-center">
                    <FileText className="h-5 w-5 text-gray-500" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">{resource.title}</p>
                    <p className="text-xs text-gray-500">Viewed 2 days ago</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Popular Resources</CardTitle>
            <CardDescription>Most downloaded resources</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {legalResources
                .sort((a, b) => b.downloads - a.downloads)
                .slice(0, 3)
                .map((resource) => (
                <div key={resource.id} className="flex items-center space-x-3">
                  <div className="h-10 w-10 rounded-md bg-gray-100 flex items-center justify-center">
                    <FileText className="h-5 w-5 text-gray-500" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">{resource.title}</p>
                    <p className="text-xs text-gray-500">{resource.downloads} downloads</p>
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => handleDownload(resource.id)}>
                    <Download className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

// Helper function to render the resource list
const renderResourceList = (resources: any[], handleDownload: (id: string) => void) => {
  if (resources.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <BookOpen className="h-12 w-12 text-gray-300 mb-3" />
        <h3 className="text-lg font-medium text-gray-900">
          No resources found
        </h3>
        <p className="text-sm text-gray-500 mt-1 mb-4 max-w-xs mx-auto">
          No resources match your current search or filter criteria.
        </p>
      </div>
    );
  }
  
  return (
    <div className="divide-y">
      {resources.map((resource) => (
        <div key={resource.id} className="py-4">
          <div className="flex items-start justify-between">
            <div className="flex items-start space-x-3">
              <div className="h-10 w-10 rounded-md bg-gray-100 flex items-center justify-center mt-1">
                <FileText className="h-5 w-5 text-gray-500" />
              </div>
              <div>
                <h3 className="font-medium">{resource.title}</h3>
                <p className="text-sm text-gray-500 mt-1">{resource.description}</p>
                <div className="flex flex-wrap gap-2 mt-2">
                  {resource.tags.map((tag: string) => (
                    <Badge key={tag} variant="outline" className="bg-gray-100">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={() => handleDownload(resource.id)}>
                <Download className="h-4 w-4 mr-1" />
                Download
              </Button>
              <Button size="sm" variant="ghost">
                <Share className="h-4 w-4" />
              </Button>
            </div>
          </div>
          <div className="flex items-center gap-4 mt-3 text-xs text-gray-500">
            <div className="flex items-center">
              <Clock className="h-3 w-3 mr-1" />
              <span>Added {resource.dateAdded}</span>
            </div>
            <div>Last updated {resource.lastUpdated}</div>
            <div>{resource.downloads} downloads</div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default LegalLibrary;
