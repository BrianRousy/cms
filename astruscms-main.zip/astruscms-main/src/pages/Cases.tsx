
import React, { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar } from "@/components/ui/calendar";
import { useToast } from "@/hooks/use-toast";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  ArrowUpDown,
  MoreHorizontal,
  Plus,
  Search,
  Filter,
  FileText,
  Calendar as CalendarIcon,
  CheckCircle2,
  ExternalLink,
  Copy,
  Trash2,
  CalendarIcon as CalendarLucide,
} from "lucide-react";
import { mockCases, getUserById } from "@/lib/mock-data";
import { format, parseISO } from "date-fns";
import { Case } from "@/types";
import { cn } from "@/lib/utils";

const Cases = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [isNewCaseDialogOpen, setIsNewCaseDialogOpen] = useState(false);
  const [cases, setCases] = useState(mockCases);
  const { toast } = useToast();

  // New case form state
  const [newCase, setNewCase] = useState<Partial<Case>>({
    title: "",
    caseNumber: `CASE-${Math.floor(1000 + Math.random() * 9000)}`,
    client: "",
    status: "open",
    priority: "medium",
    dueDate: new Date().toISOString(),
    progress: 0,
    assignedTo: []
  });

  const handleCreateCase = () => {
    const createdCase = {
      ...newCase,
      id: `case-${Date.now()}`,
      progress: 0,
      createdAt: new Date().toISOString(),
      assignedTo: [newCase.assignedTo || "user-1"].flat()
    } as Case;
    
    setCases([createdCase, ...cases]);
    setIsNewCaseDialogOpen(false);
    
    toast({
      title: "Case Created",
      description: `Case "${createdCase.title}" has been created successfully.`,
      duration: 3000,
    });

    // Reset form
    setNewCase({
      title: "",
      caseNumber: `CASE-${Math.floor(1000 + Math.random() * 9000)}`,
      client: "",
      status: "open",
      priority: "medium",
      dueDate: new Date().toISOString(),
      progress: 0,
      assignedTo: []
    });
  };

  const filteredCases = cases.filter((caseItem) =>
    caseItem.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    caseItem.caseNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
    caseItem.client.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusColor = (status: Case["status"]) => {
    switch (status) {
      case "open":
        return "bg-green-100 text-green-800 border-green-200";
      case "closed":
        return "bg-gray-100 text-gray-800 border-gray-200";
      case "pending":
        return "bg-amber-100 text-amber-800 border-amber-200";
      case "archived":
        return "bg-blue-100 text-blue-800 border-blue-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getPriorityColor = (priority: Case["priority"]) => {
    switch (priority) {
      case "high":
        return "bg-red-100 text-red-800 border-red-200";
      case "medium":
        return "bg-amber-100 text-amber-800 border-amber-200";
      case "low":
        return "bg-green-100 text-green-800 border-green-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold">Cases</h1>
          <p className="text-sm text-gray-500">
            Manage and track all your legal cases
          </p>
        </div>

        <Dialog open={isNewCaseDialogOpen} onOpenChange={setIsNewCaseDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-navy hover:bg-navy-light">
              <Plus className="mr-2 h-4 w-4" />
              New Case
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[550px]">
            <DialogHeader>
              <DialogTitle>Create New Case</DialogTitle>
              <DialogDescription>
                Enter the details for the new case. Required fields are marked with an asterisk (*).
              </DialogDescription>
            </DialogHeader>
            
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="title">
                  Case Title <span className="text-red-500">*</span>
                </Label>
                <Input 
                  id="title" 
                  value={newCase.title} 
                  onChange={(e) => setNewCase({...newCase, title: e.target.value})} 
                  placeholder="Enter case title"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="caseNumber">
                    Case Number <span className="text-red-500">*</span>
                  </Label>
                  <Input 
                    id="caseNumber" 
                    value={newCase.caseNumber} 
                    onChange={(e) => setNewCase({...newCase, caseNumber: e.target.value})} 
                  />
                </div>
                
                <div className="grid gap-2">
                  <Label htmlFor="client">
                    Client <span className="text-red-500">*</span>
                  </Label>
                  <Input 
                    id="client" 
                    value={newCase.client} 
                    onChange={(e) => setNewCase({...newCase, client: e.target.value})} 
                    placeholder="Client name"
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="status">Status</Label>
                  <Select 
                    value={newCase.status} 
                    onValueChange={(value) => setNewCase({...newCase, status: value as Case["status"]})}
                  >
                    <SelectTrigger id="status">
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="open">Open</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="closed">Closed</SelectItem>
                      <SelectItem value="archived">Archived</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="grid gap-2">
                  <Label htmlFor="priority">Priority</Label>
                  <Select 
                    value={newCase.priority} 
                    onValueChange={(value) => setNewCase({...newCase, priority: value as Case["priority"]})}
                  >
                    <SelectTrigger id="priority">
                      <SelectValue placeholder="Select priority" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="grid gap-2">
                <Label>Due Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant={"outline"}
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !newCase.dueDate && "text-muted-foreground"
                      )}
                    >
                      <CalendarLucide className="mr-2 h-4 w-4" />
                      {newCase.dueDate ? format(new Date(newCase.dueDate), "PPP") : "Select date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={newCase.dueDate ? new Date(newCase.dueDate) : undefined}
                      onSelect={(date) => date && setNewCase({...newCase, dueDate: date.toISOString()})}
                      initialFocus
                      className="p-3 pointer-events-auto"
                    />
                  </PopoverContent>
                </Popover>
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="description">Case Description</Label>
                <Textarea 
                  id="description" 
                  value={newCase.description || ''} 
                  onChange={(e) => setNewCase({...newCase, description: e.target.value})} 
                  placeholder="Provide details about this case"
                  rows={4}
                />
              </div>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsNewCaseDialogOpen(false)}>
                Cancel
              </Button>
              <Button 
                onClick={handleCreateCase}
                disabled={!newCase.title || !newCase.caseNumber || !newCase.client}
              >
                Create Case
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Open Cases</CardTitle>
            <CardDescription>
              {cases.filter((c) => c.status === "open").length} total
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {cases.filter((c) => c.status === "open").length}
            </div>
            <p className="text-xs text-gray-500">+2 from last month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Pending Cases</CardTitle>
            <CardDescription>
              {cases.filter((c) => c.status === "pending").length} total
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {cases.filter((c) => c.status === "pending").length}
            </div>
            <p className="text-xs text-gray-500">Waiting for action</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Closed Cases</CardTitle>
            <CardDescription>
              {cases.filter((c) => c.status === "closed").length} total
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {cases.filter((c) => c.status === "closed").length}
            </div>
            <p className="text-xs text-gray-500">This year</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Cases</CardTitle>
          <CardDescription>Manage and view case details</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4 mb-4 items-start md:items-center justify-between">
            <div className="relative w-full md:w-96">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
              <Input
                type="search"
                placeholder="Search cases..."
                className="pl-8 w-full"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            <div className="flex gap-2">
              <Button variant="outline" size="sm" className="h-9">
                <Filter className="mr-2 h-4 w-4" />
                Filter
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="h-9">
                    <ArrowUpDown className="mr-2 h-4 w-4" />
                    Sort
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <DropdownMenuLabel>Sort by</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem>Case Title A-Z</DropdownMenuItem>
                  <DropdownMenuItem>Case Title Z-A</DropdownMenuItem>
                  <DropdownMenuItem>Date (Newest)</DropdownMenuItem>
                  <DropdownMenuItem>Date (Oldest)</DropdownMenuItem>
                  <DropdownMenuItem>Priority (High-Low)</DropdownMenuItem>
                  <DropdownMenuItem>Priority (Low-High)</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>

          <Tabs defaultValue="all" className="w-full">
            <TabsList className="mb-4">
              <TabsTrigger value="all">All Cases</TabsTrigger>
              <TabsTrigger value="open">Open Cases</TabsTrigger>
              <TabsTrigger value="pending">Pending</TabsTrigger>
              <TabsTrigger value="closed">Closed</TabsTrigger>
            </TabsList>
            
            <TabsContent value="all">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Case Details</TableHead>
                      <TableHead>Client</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Priority</TableHead>
                      <TableHead>Progress</TableHead>
                      <TableHead>Due Date</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredCases.map((caseItem) => {
                      const assignedUsers = caseItem.assignedTo.map((id) =>
                        getUserById(id)
                      );

                      return (
                        <TableRow key={caseItem.id}>
                          <TableCell>
                            <div className="font-medium">{caseItem.title}</div>
                            <div className="text-sm text-gray-500">
                              {caseItem.caseNumber}
                            </div>
                          </TableCell>
                          <TableCell>{caseItem.client}</TableCell>
                          <TableCell>
                            <Badge
                              variant="outline"
                              className={getStatusColor(caseItem.status)}
                            >
                              {caseItem.status}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge
                              variant="outline"
                              className={getPriorityColor(caseItem.priority)}
                            >
                              {caseItem.priority}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Progress
                                value={caseItem.progress}
                                className="h-2 w-[60px]"
                              />
                              <span className="text-sm">{caseItem.progress}%</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            {format(new Date(caseItem.dueDate), "MMM d, yyyy")}
                          </TableCell>
                          <TableCell>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-8 w-8 p-0"
                                >
                                  <MoreHorizontal className="h-4 w-4" />
                                  <span className="sr-only">Open menu</span>
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end" className="w-[160px]">
                                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                <DropdownMenuSeparator />
                                <Link to={`/cases/${caseItem.id}`}>
                                  <DropdownMenuItem>
                                    <ExternalLink className="mr-2 h-4 w-4" />
                                    View Details
                                  </DropdownMenuItem>
                                </Link>
                                <DropdownMenuItem>
                                  <FileText className="mr-2 h-4 w-4" />
                                  View Documents
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <CalendarIcon className="mr-2 h-4 w-4" />
                                  Schedule Event
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <CheckCircle2 className="mr-2 h-4 w-4" />
                                  Add Task
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem>
                                  <Copy className="mr-2 h-4 w-4" />
                                  Duplicate
                                </DropdownMenuItem>
                                <DropdownMenuItem className="text-red-600">
                                  <Trash2 className="mr-2 h-4 w-4" />
                                  Delete
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
                {filteredCases.length === 0 && (
                  <div className="text-center p-4 border-t">
                    <p className="text-gray-500">No cases found matching your search criteria.</p>
                  </div>
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="open">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Case Details</TableHead>
                      <TableHead>Client</TableHead>
                      <TableHead>Priority</TableHead>
                      <TableHead>Progress</TableHead>
                      <TableHead>Due Date</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredCases
                      .filter(c => c.status === "open")
                      .map((caseItem) => (
                        <TableRow key={caseItem.id}>
                          <TableCell>
                            <div className="font-medium">{caseItem.title}</div>
                            <div className="text-sm text-gray-500">{caseItem.caseNumber}</div>
                          </TableCell>
                          <TableCell>{caseItem.client}</TableCell>
                          <TableCell>
                            <Badge
                              variant="outline"
                              className={getPriorityColor(caseItem.priority)}
                            >
                              {caseItem.priority}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Progress value={caseItem.progress} className="h-2 w-[60px]" />
                              <span className="text-sm">{caseItem.progress}%</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            {format(new Date(caseItem.dueDate), "MMM d, yyyy")}
                          </TableCell>
                          <TableCell>
                            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                              <MoreHorizontal className="h-4 w-4" />
                              <span className="sr-only">Open menu</span>
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
                {filteredCases.filter(c => c.status === "open").length === 0 && (
                  <div className="text-center p-4 border-t">
                    <p className="text-gray-500">No open cases found.</p>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="pending">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Case Details</TableHead>
                      <TableHead>Client</TableHead>
                      <TableHead>Priority</TableHead>
                      <TableHead>Progress</TableHead>
                      <TableHead>Due Date</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredCases
                      .filter(c => c.status === "pending")
                      .map((caseItem) => (
                        <TableRow key={caseItem.id}>
                          <TableCell>
                            <div className="font-medium">{caseItem.title}</div>
                            <div className="text-sm text-gray-500">{caseItem.caseNumber}</div>
                          </TableCell>
                          <TableCell>{caseItem.client}</TableCell>
                          <TableCell>
                            <Badge
                              variant="outline"
                              className={getPriorityColor(caseItem.priority)}
                            >
                              {caseItem.priority}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Progress value={caseItem.progress} className="h-2 w-[60px]" />
                              <span className="text-sm">{caseItem.progress}%</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            {format(new Date(caseItem.dueDate), "MMM d, yyyy")}
                          </TableCell>
                          <TableCell>
                            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                              <MoreHorizontal className="h-4 w-4" />
                              <span className="sr-only">Open menu</span>
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
                {filteredCases.filter(c => c.status === "pending").length === 0 && (
                  <div className="text-center p-4 border-t">
                    <p className="text-gray-500">No pending cases found.</p>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="closed">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Case Details</TableHead>
                      <TableHead>Client</TableHead>
                      <TableHead>Priority</TableHead>
                      <TableHead>Progress</TableHead>
                      <TableHead>Closed Date</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredCases
                      .filter(c => c.status === "closed")
                      .map((caseItem) => (
                        <TableRow key={caseItem.id}>
                          <TableCell>
                            <div className="font-medium">{caseItem.title}</div>
                            <div className="text-sm text-gray-500">{caseItem.caseNumber}</div>
                          </TableCell>
                          <TableCell>{caseItem.client}</TableCell>
                          <TableCell>
                            <Badge
                              variant="outline"
                              className={getPriorityColor(caseItem.priority)}
                            >
                              {caseItem.priority}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Progress value={caseItem.progress} className="h-2 w-[60px]" />
                              <span className="text-sm">{caseItem.progress}%</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            {format(new Date(caseItem.dueDate), "MMM d, yyyy")}
                          </TableCell>
                          <TableCell>
                            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                              <MoreHorizontal className="h-4 w-4" />
                              <span className="sr-only">Open menu</span>
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
                {filteredCases.filter(c => c.status === "closed").length === 0 && (
                  <div className="text-center p-4 border-t">
                    <p className="text-gray-500">No closed cases found.</p>
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default Cases;
