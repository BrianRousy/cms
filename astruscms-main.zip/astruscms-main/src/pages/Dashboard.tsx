
import React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import {
  BarChart,
  Bar,
  AreaChart,
  Area,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from "recharts";
import {
  Briefcase,
  Calendar,
  CheckCircle2,
  Clock,
  FileText,
  Flag,
  Hourglass,
  Users,
  ArrowRight,
  BarChart as BarChartIcon
} from "lucide-react";
import {
  mockCases, 
  mockTasks, 
  mockEvents, 
  getUpcomingEvents,
  getUserById
} from "@/lib/mock-data";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const Dashboard = () => {
  const openCases = mockCases.filter((c) => c.status === "open");
  const upcomingEvents = getUpcomingEvents(7);
  const pendingTasks = mockTasks.filter((t) => t.status !== "completed");
  
  // Mock data for charts
  const casesByStage = [
    { name: "Intake", value: mockCases.filter((c) => c.stage === "intake").length },
    { name: "Discovery", value: mockCases.filter((c) => c.stage === "discovery").length },
    { name: "Negotiation", value: mockCases.filter((c) => c.stage === "negotiation").length },
    { name: "Trial", value: mockCases.filter((c) => c.stage === "trial").length },
    { name: "Settlement", value: mockCases.filter((c) => c.stage === "settlement").length },
    { name: "Closed", value: mockCases.filter((c) => c.stage === "closed").length },
  ];
  
  const taskCompletionData = [
    { name: "To Do", value: mockTasks.filter((t) => t.status === "todo").length, color: "rgba(252, 163, 17, 0.8)" },
    { name: "In Progress", value: mockTasks.filter((t) => t.status === "in-progress").length, color: "rgba(20, 33, 61, 0.7)" },
    { name: "Completed", value: mockTasks.filter((t) => t.status === "completed").length, color: "rgba(76, 175, 80, 0.7)" },
  ];

  // Mock data for case statistics
  const caseStatisticsData = [
    { name: "Personal Injury", value: 15 },
    { name: "Corporate", value: 12 },
    { name: "Criminal", value: 8 },
    { name: "Family", value: 10 },
    { name: "Real Estate", value: 5 },
  ];

  // Performance data for the chart
  const performanceData = [
    { name: 'Week 1', billable: 65, revenue: 18000, resolution: 60 },
    { name: 'Week 2', billable: 70, revenue: 21000, resolution: 65 },
    { name: 'Week 3', billable: 68, revenue: 19500, resolution: 62 },
    { name: 'Week 4', billable: 72.5, revenue: 24500, resolution: 67 },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h1 className="text-2xl font-semibold">Dashboard</h1>
        <div className="text-sm text-gray-500 px-3 py-1 bg-gray-100 rounded-full">
          {format(new Date(), "EEEE, MMMM d, yyyy")}
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="hover:shadow-md transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">
              Active Cases
            </CardTitle>
            <Briefcase className="h-4 w-4 text-navy" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{openCases.length}</div>
            <p className="text-xs text-gray-500">
              +2 new cases this month
            </p>
            <Link to="/cases" className="mt-2 flex items-center text-xs text-navy hover:underline">
              View all cases <ArrowRight className="ml-1 h-3 w-3" />
            </Link>
          </CardContent>
        </Card>
        <Card className="hover:shadow-md transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">
              Upcoming Events
            </CardTitle>
            <Calendar className="h-4 w-4 text-navy" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{upcomingEvents.length}</div>
            <p className="text-xs text-gray-500">
              Next: {upcomingEvents.length > 0 ? format(new Date(upcomingEvents[0].start), "MMM d, h:mm a") : "None"}
            </p>
            <Link to="/calendar" className="mt-2 flex items-center text-xs text-navy hover:underline">
              View calendar <ArrowRight className="ml-1 h-3 w-3" />
            </Link>
          </CardContent>
        </Card>
        <Card className="hover:shadow-md transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">
              Pending Tasks
            </CardTitle>
            <CheckCircle2 className="h-4 w-4 text-navy" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{pendingTasks.length}</div>
            <p className="text-xs text-gray-500">
              {mockTasks.filter((t) => t.status === "completed").length} completed
            </p>
            <Link to="/tasks" className="mt-2 flex items-center text-xs text-navy hover:underline">
              View all tasks <ArrowRight className="ml-1 h-3 w-3" />
            </Link>
          </CardContent>
        </Card>
        <Card className="hover:shadow-md transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">
              Documents
            </CardTitle>
            <FileText className="h-4 w-4 text-navy" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">24</div>
            <p className="text-xs text-gray-500">
              5 awaiting review
            </p>
            <Link to="/documents" className="mt-2 flex items-center text-xs text-navy hover:underline">
              View documents <ArrowRight className="ml-1 h-3 w-3" />
            </Link>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card className="hover:shadow-md transition-shadow">
          <CardHeader>
            <CardTitle>Case Overview</CardTitle>
            <CardDescription>
              Distribution of cases by stage
            </CardDescription>
          </CardHeader>
          <CardContent className="pl-2">
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart 
                  data={casesByStage}
                  margin={{
                    top: 10,
                    right: 30,
                    left: 0,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="value" fill="rgba(20, 33, 61, 0.7)" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        <Card className="hover:shadow-md transition-shadow">
          <CardHeader>
            <CardTitle>Task Status</CardTitle>
            <CardDescription>
              Current task completion status
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={taskCompletionData}
                    cx="50%"
                    cy="50%"
                    labelLine={true}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                    label={({name, percent}) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  >
                    {taskCompletionData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card className="md:col-span-1 lg:col-span-1 hover:shadow-md transition-shadow">
          <CardHeader>
            <CardTitle>Upcoming Deadlines</CardTitle>
            <CardDescription>Next 7 days</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {mockTasks
                .filter((task) => {
                  const dueDate = new Date(task.dueDate);
                  const today = new Date();
                  const sevenDaysLater = new Date();
                  sevenDaysLater.setDate(today.getDate() + 7);
                  return dueDate >= today && dueDate <= sevenDaysLater;
                })
                .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime())
                .slice(0, 3)
                .map((task) => {
                  const priorityColor = 
                    task.priority === "high" 
                      ? "text-red-500" 
                      : task.priority === "medium" 
                      ? "text-amber-500" 
                      : "text-green-500";
                  return (
                    <div key={task.id} className="flex items-center justify-between group p-2 hover:bg-gray-50 rounded-lg transition-colors">
                      <div className="space-y-1">
                        <p className="text-sm font-medium">{task.title}</p>
                        <div className="flex items-center text-xs text-gray-500">
                          <Hourglass className={`mr-1 h-3 w-3 ${priorityColor}`} />
                          <span>{format(new Date(task.dueDate), "MMM d, yyyy")}</span>
                        </div>
                      </div>
                      <Badge
                        variant="outline"
                        className={
                          task.priority === "high"
                            ? "text-red-500 border-red-200 bg-red-50"
                            : task.priority === "medium"
                            ? "text-amber-500 border-amber-200 bg-amber-50"
                            : "text-green-500 border-green-200 bg-green-50"
                        }
                      >
                        {task.priority}
                      </Badge>
                    </div>
                  );
                })}
                <Button variant="outline" size="sm" className="w-full mt-2">
                  View all deadlines
                </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="md:col-span-1 lg:col-span-1 hover:shadow-md transition-shadow">
          <CardHeader>
            <CardTitle>Active Cases</CardTitle>
            <CardDescription>
              Recently updated cases
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {openCases.slice(0, 3).map((caseItem) => (
                <div key={caseItem.id} className="flex items-center justify-between group p-2 hover:bg-gray-50 rounded-lg transition-colors">
                  <div className="space-y-1">
                    <p className="text-sm font-medium leading-none">
                      {caseItem.title}
                    </p>
                    <p className="text-xs text-gray-500">
                      {caseItem.caseNumber}
                    </p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge
                      variant="outline"
                      className={
                        caseItem.priority === "high"
                          ? "text-red-500 border-red-200 bg-red-50"
                          : caseItem.priority === "medium"
                          ? "text-amber-500 border-amber-200 bg-amber-50"
                          : "text-green-500 border-green-200 bg-green-50"
                      }
                    >
                      {caseItem.priority}
                    </Badge>
                    <div className="w-24">
                      <Progress value={caseItem.progress} className="h-2" />
                    </div>
                  </div>
                </div>
              ))}
              <Button variant="outline" size="sm" className="w-full mt-2">
                <Link to="/cases" className="w-full flex items-center justify-center">
                  View all cases
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
        
        <Card className="md:col-span-2 lg:col-span-1 hover:shadow-md transition-shadow">
          <CardHeader>
            <CardTitle>Upcoming Events</CardTitle>
            <CardDescription>
              Events in the next 7 days
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {upcomingEvents.slice(0, 3).map((event) => (
                <div key={event.id} className="flex items-start space-x-4 group p-2 hover:bg-gray-50 rounded-lg transition-colors">
                  <div className="bg-gray-100 rounded-md p-2 h-10 w-10 flex items-center justify-center">
                    {event.eventType === "court-date" ? (
                      <Briefcase className="h-5 w-5 text-navy" />
                    ) : event.eventType === "client-meeting" ? (
                      <Users className="h-5 w-5 text-navy" />
                    ) : (
                      <Flag className="h-5 w-5 text-navy" />
                    )}
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm font-medium leading-none">
                      {event.title}
                    </p>
                    <p className="text-xs text-gray-500">
                      {format(new Date(event.start), "MMM d, h:mm a")}
                      {event.location && ` • ${event.location}`}
                    </p>
                  </div>
                </div>
              ))}
              <Button variant="outline" size="sm" className="w-full mt-2">
                <Link to="/calendar" className="w-full flex items-center justify-center">
                  View all events
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Card className="col-span-3 hover:shadow-md transition-shadow">
        <CardHeader>
          <CardTitle>Case Statistics</CardTitle>
          <CardDescription>Overview of your active cases by type</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={caseStatisticsData}
                margin={{
                  top: 10,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="value" fill="rgba(20, 33, 61, 0.7)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
      
      <Card className="hover:shadow-md transition-shadow">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Performance Overview</CardTitle>
            <CardDescription>
              Key performance indicators for the firm
            </CardDescription>
          </div>
          <Tabs defaultValue="week" className="w-[200px]">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="week">Week</TabsTrigger>
              <TabsTrigger value="month">Month</TabsTrigger>
              <TabsTrigger value="year">Year</TabsTrigger>
            </TabsList>
          </Tabs>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <div className="flex flex-col justify-between p-4 bg-gray-50 rounded-lg">
              <div className="space-y-1">
                <div className="text-xs text-gray-500">Billable Hours</div>
                <div className="text-2xl font-bold">72.5</div>
              </div>
              <div className="mt-2 flex items-center text-xs">
                <span className="text-green-500 mr-1">+12%</span> from last period
              </div>
            </div>
            <div className="flex flex-col justify-between p-4 bg-gray-50 rounded-lg">
              <div className="space-y-1">
                <div className="text-xs text-gray-500">Revenue Generated</div>
                <div className="text-2xl font-bold">$24,500</div>
              </div>
              <div className="mt-2 flex items-center text-xs">
                <span className="text-green-500 mr-1">+8%</span> from last period
              </div>
            </div>
            <div className="flex flex-col justify-between p-4 bg-gray-50 rounded-lg">
              <div className="space-y-1">
                <div className="text-xs text-gray-500">Case Resolution Rate</div>
                <div className="text-2xl font-bold">67%</div>
              </div>
              <div className="mt-2 flex items-center text-xs">
                <span className="text-amber-500 mr-1">-3%</span> from last period
              </div>
            </div>
          </div>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={performanceData}
                margin={{
                  top: 10,
                  right: 30,
                  left: 0,
                  bottom: 0,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Area type="monotone" dataKey="billable" stackId="1" stroke="#14213D" fill="rgba(20, 33, 61, 0.7)" />
                <Area type="monotone" dataKey="resolution" stackId="2" stroke="#FCA311" fill="rgba(252, 163, 17, 0.5)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Dashboard;
