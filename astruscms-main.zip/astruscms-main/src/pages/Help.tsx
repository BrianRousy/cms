
import React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const Help = () => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Help & Support</h1>
        <Button className="bg-navy hover:bg-navy/90">Contact Support</Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Help Center</CardTitle>
          <CardDescription>Get help with using the application</CardDescription>
        </CardHeader>
        <CardContent className="text-center py-10">
          <h3 className="text-lg font-medium">Support Resources</h3>
          <p className="mt-2 text-sm text-gray-500">
            This page will provide help documentation and support resources
          </p>
        </CardContent>
      </Card>
    </div>
  );
};

export default Help;
