
import React, { useState } from "react";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format, addDays, isToday, parseISO, isSameDay } from "date-fns";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { CalendarIcon, Clock, Plus, Users, Bell, Mail, Check, Calendar as CalendarIcon2, X } from "lucide-react";
import { Switch } from "@/components/ui/switch";

// Mock data for events
const initialEvents = [
  {
    id: 1,
    title: "Client Meeting - Johnson Case",
    description: "Initial consultation regarding divorce proceedings",
    start: new Date(new Date().setHours(10, 0, 0, 0)),
    end: new Date(new Date().setHours(11, 30, 0, 0)),
    type: "meeting",
    location: "Conference Room A",
    attendees: ["John Smith", "Sarah Johnson"],
    reminder: true
  },
  {
    id: 2,
    title: "Court Hearing - Smith v. Davis",
    description: "Preliminary hearing for civil case #CR-2023-45678",
    start: addDays(new Date(new Date().setHours(14, 0, 0, 0)), 1),
    end: addDays(new Date(new Date().setHours(16, 0, 0, 0)), 1),
    type: "court",
    location: "County Courthouse, Room 304",
    attendees: ["Michael Smith", "Legal Team"],
    reminder: true
  },
  {
    id: 3,
    title: "Document Review - Brown Estate",
    description: "Review estate planning documents before client sign-off",
    start: addDays(new Date(new Date().setHours(13, 0, 0, 0)), 2),
    end: addDays(new Date(new Date().setHours(15, 0, 0, 0)), 2),
    type: "task",
    location: "Office",
    attendees: ["Robert Brown"],
    reminder: false
  }
];

const CalendarPage = () => {
  const [date, setDate] = useState<Date>(new Date());
  const [events, setEvents] = useState(initialEvents);
  const [selectedEvent, setSelectedEvent] = useState<any | null>(null);
  const [newEvent, setNewEvent] = useState({
    title: "",
    description: "",
    start: new Date(),
    end: new Date(),
    type: "meeting",
    location: "",
    attendees: "",
    reminder: true
  });
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { toast } = useToast();

  const handleDateSelect = (date: Date | undefined) => {
    if (date) {
      setDate(date);
    }
  };

  const handleAddEvent = () => {
    const createdEvent = {
      ...newEvent,
      id: events.length + 1,
      attendees: newEvent.attendees.split(',').map(a => a.trim())
    };
    
    setEvents([...events, createdEvent]);
    setIsDialogOpen(false);
    
    toast({
      title: "Event Created",
      description: `${createdEvent.title} has been added to your calendar.`,
      duration: 3000,
    });

    // Reset form fields
    setNewEvent({
      title: "",
      description: "",
      start: new Date(),
      end: new Date(),
      type: "meeting",
      location: "",
      attendees: "",
      reminder: true
    });
    
    if (newEvent.reminder) {
      toast({
        title: "Email Notification Sent",
        description: "A notification email has been sent to all attendees.",
        duration: 3000,
      });
    }
  };

  // Filter events for the selected day
  const dayEvents = events.filter(event => 
    isSameDay(event.start, date)
  ).sort((a, b) => a.start.getTime() - b.start.getTime());

  // Function to determine day state for calendar
  const getDayState = (day: Date) => {
    const hasEvents = events.some(event => isSameDay(event.start, day));
    
    if (isToday(day) && hasEvents) {
      return "today-with-events";
    } else if (isToday(day)) {
      return "today";
    } else if (hasEvents) {
      return "has-events";
    }
    return "";
  };

  const getEventTypeStyles = (type: string) => {
    switch(type) {
      case "meeting":
        return "bg-blue-100 text-blue-800 border-blue-200";
      case "court":
        return "bg-red-100 text-red-800 border-red-200";
      case "task":
        return "bg-green-100 text-green-800 border-green-200";
      case "deadline":
        return "bg-amber-100 text-amber-800 border-amber-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Calendar</h1>
          <p className="text-sm text-gray-500">
            Manage your appointments, court dates, and deadlines
          </p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-navy hover:bg-navy/90">
              <Plus className="mr-2 h-4 w-4" />
              New Event
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[525px]">
            <DialogHeader>
              <DialogTitle>Add New Calendar Event</DialogTitle>
              <DialogDescription>
                Create a new event, meeting, or deadline in your calendar.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="title">Title</Label>
                <Input 
                  id="title" 
                  value={newEvent.title} 
                  onChange={(e) => setNewEvent({...newEvent, title: e.target.value})} 
                  placeholder="Event title"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label>Start Date & Time</Label>
                  <div className="flex gap-2">
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant={"outline"}
                          className={cn(
                            "w-full justify-start text-left font-normal",
                            !newEvent.start && "text-muted-foreground"
                          )}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {format(newEvent.start, "PPP")}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={newEvent.start}
                          onSelect={(date) => date && setNewEvent({...newEvent, start: date})}
                          initialFocus
                          className="p-3 pointer-events-auto"
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>
                
                <div className="grid gap-2">
                  <Label>End Date & Time</Label>
                  <div className="flex gap-2">
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant={"outline"}
                          className={cn(
                            "w-full justify-start text-left font-normal",
                            !newEvent.end && "text-muted-foreground"
                          )}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {format(newEvent.end, "PPP")}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={newEvent.end}
                          onSelect={(date) => date && setNewEvent({...newEvent, end: date})}
                          initialFocus
                          className="p-3 pointer-events-auto"
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="type">Event Type</Label>
                <Select 
                  value={newEvent.type}
                  onValueChange={(value) => setNewEvent({...newEvent, type: value})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select event type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="meeting">Client Meeting</SelectItem>
                    <SelectItem value="court">Court Appearance</SelectItem>
                    <SelectItem value="task">Task</SelectItem>
                    <SelectItem value="deadline">Deadline</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="location">Location</Label>
                <Input 
                  id="location" 
                  value={newEvent.location} 
                  onChange={(e) => setNewEvent({...newEvent, location: e.target.value})} 
                  placeholder="Event location"
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="attendees">Attendees</Label>
                <Input 
                  id="attendees" 
                  value={newEvent.attendees} 
                  onChange={(e) => setNewEvent({...newEvent, attendees: e.target.value})} 
                  placeholder="Comma-separated names or email addresses"
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="description">Description</Label>
                <Textarea 
                  id="description" 
                  value={newEvent.description} 
                  onChange={(e) => setNewEvent({...newEvent, description: e.target.value})} 
                  placeholder="Add details about this event"
                />
              </div>
              
              <div className="flex items-center space-x-2">
                <Switch 
                  id="reminder"
                  checked={newEvent.reminder}
                  onCheckedChange={(checked) => setNewEvent({...newEvent, reminder: checked})} 
                />
                <Label htmlFor="reminder" className="flex items-center gap-2">
                  <Mail className="h-4 w-4" /> Send email notifications
                </Label>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
              <Button onClick={handleAddEvent} disabled={!newEvent.title}>Create Event</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-1 h-auto">
          <CardHeader>
            <CardTitle>Calendar</CardTitle>
            <CardDescription>Select a date to view events</CardDescription>
          </CardHeader>
          <CardContent>
            <Calendar
              mode="single"
              selected={date}
              onSelect={handleDateSelect}
              className="mx-auto"
              modifiers={{
                today: (day) => isToday(day),
                'has-events': (day) => events.some(event => isSameDay(event.start, day))
              }}
              modifiersStyles={{
                today: { fontWeight: 'bold', backgroundColor: '#f0f9ff', color: '#0369a1' },
                'has-events': { backgroundColor: '#818cf8', color: 'white', fontWeight: 'bold' }
              }}
              classNames={{
                day_today: 'bg-blue-50 text-blue-900 font-bold',
                day_selected: 'bg-navy !text-white hover:bg-navy hover:text-white font-bold',
              }}
            />
          </CardContent>
          <CardFooter className="border-t p-4 flex items-start gap-4 flex-col">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-blue-500"></div>
              <span className="text-xs">Client Meeting</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500"></div>
              <span className="text-xs">Court Appearance</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-green-500"></div>
              <span className="text-xs">Task</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-amber-500"></div>
              <span className="text-xs">Deadline</span>
            </div>
          </CardFooter>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <div>
              <CardTitle>{format(date, 'EEEE, MMMM d, yyyy')}</CardTitle>
              <CardDescription>
                {dayEvents.length === 0 
                  ? "No events scheduled" 
                  : `${dayEvents.length} event${dayEvents.length === 1 ? '' : 's'} scheduled`
                }
              </CardDescription>
            </div>
            <Dialog>
              <DialogTrigger asChild>
                <Button size="sm">
                  <Plus className="h-4 w-4 mr-1" /> Add
                </Button>
              </DialogTrigger>
              <DialogContent>
                {/* Reuse same content as New Event dialog */}
              </DialogContent>
            </Dialog>
          </CardHeader>
          <CardContent className="max-h-[500px] overflow-y-auto">
            {dayEvents.length > 0 ? (
              <div className="space-y-4">
                {dayEvents.map((event) => (
                  <Card key={event.id} className="overflow-hidden border-l-4" style={{
                    borderLeftColor: event.type === 'meeting' 
                      ? '#3b82f6' 
                      : event.type === 'court' 
                        ? '#ef4444' 
                        : event.type === 'deadline'
                          ? '#f59e0b'
                          : '#10b981'
                  }}>
                    <CardHeader className="p-4 pb-2">
                      <div className="flex justify-between">
                        <div>
                          <CardTitle className="text-lg">{event.title}</CardTitle>
                          <CardDescription>
                            {format(event.start, "h:mm a")} - {format(event.end, "h:mm a")}
                          </CardDescription>
                        </div>
                        <div className="flex gap-2">
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <Bell className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <Mail className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="p-4 pt-0 pb-2">
                      <div className="text-sm text-gray-500 space-y-2">
                        <p>{event.description}</p>
                        <div className="flex items-center gap-1 text-xs">
                          <Clock className="h-3 w-3 text-gray-400" /> 
                          <span className="text-gray-600">Duration: {
                            (event.end.getTime() - event.start.getTime()) / (1000 * 60) === 60
                              ? "1 hour"
                              : (event.end.getTime() - event.start.getTime()) / (1000 * 60) < 60
                                ? `${(event.end.getTime() - event.start.getTime()) / (1000 * 60)} minutes`
                                : `${(event.end.getTime() - event.start.getTime()) / (1000 * 60 * 60)} hours`
                          }</span>
                        </div>
                        {event.location && (
                          <div className="flex items-center gap-1 text-xs">
                            <CalendarIcon2 className="h-3 w-3 text-gray-400" /> 
                            <span className="text-gray-600">{event.location}</span>
                          </div>
                        )}
                        {event.attendees && event.attendees.length > 0 && (
                          <div className="flex items-center gap-1 text-xs">
                            <Users className="h-3 w-3 text-gray-400" /> 
                            <span className="text-gray-600">
                              {event.attendees.join(", ")}
                            </span>
                          </div>
                        )}
                      </div>
                    </CardContent>
                    <CardFooter className="p-2 bg-gray-50 flex justify-end gap-2">
                      <Button variant="outline" size="sm">
                        <Check className="h-3 w-3 mr-1" /> Complete
                      </Button>
                      <Button variant="outline" size="sm">
                        <X className="h-3 w-3 mr-1" /> Cancel
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-10">
                <CalendarIcon2 className="h-12 w-12 mx-auto text-gray-300 mb-3" />
                <h3 className="text-lg font-medium text-gray-900">No Events Today</h3>
                <p className="text-gray-500 mt-1 mb-3 max-w-sm mx-auto">
                  There are no events scheduled for this day. Click the button below to add a new event.
                </p>
                <Button onClick={() => setIsDialogOpen(true)} className="mx-auto">
                  <Plus className="h-4 w-4 mr-2" /> Add Event
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Upcoming Events Section */}
      <Card>
        <CardHeader>
          <CardTitle>Upcoming Events</CardTitle>
          <CardDescription>Your schedule for the next 7 days</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="all" className="w-full">
            <TabsList className="mb-4">
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="meetings">Meetings</TabsTrigger>
              <TabsTrigger value="court">Court</TabsTrigger>
              <TabsTrigger value="deadlines">Deadlines</TabsTrigger>
            </TabsList>
            <TabsContent value="all" className="space-y-4">
              {events.map(event => (
                <div key={event.id} className="flex items-center gap-4 p-3 rounded-lg border hover:bg-gray-50 transition-colors cursor-pointer">
                  <div className="w-2 h-10 rounded-full" style={{
                    backgroundColor: event.type === 'meeting' 
                      ? '#3b82f6' 
                      : event.type === 'court' 
                        ? '#ef4444' 
                        : event.type === 'deadline'
                          ? '#f59e0b'
                          : '#10b981'
                  }}></div>
                  <div className="flex-1">
                    <h4 className="font-medium">{event.title}</h4>
                    <p className="text-sm text-gray-500">
                      {format(event.start, "E, MMM d")} • {format(event.start, "h:mm a")} to {format(event.end, "h:mm a")}
                    </p>
                  </div>
                  <div>
                    <Button variant="ghost" size="sm">Details</Button>
                  </div>
                </div>
              ))}
            </TabsContent>
            <TabsContent value="meetings">
              {events.filter(e => e.type === 'meeting').length > 0 ? (
                events.filter(e => e.type === 'meeting').map(event => (
                  <div key={event.id} className="flex items-center gap-4 p-3 rounded-lg border hover:bg-gray-50 transition-colors cursor-pointer">
                    <div className="w-2 h-10 rounded-full bg-blue-500"></div>
                    <div className="flex-1">
                      <h4 className="font-medium">{event.title}</h4>
                      <p className="text-sm text-gray-500">
                        {format(event.start, "E, MMM d")} • {format(event.start, "h:mm a")} to {format(event.end, "h:mm a")}
                      </p>
                    </div>
                    <div>
                      <Button variant="ghost" size="sm">Details</Button>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8 text-gray-500">No upcoming meetings</div>
              )}
            </TabsContent>
            <TabsContent value="court">
              {events.filter(e => e.type === 'court').length > 0 ? (
                events.filter(e => e.type === 'court').map(event => (
                  <div key={event.id} className="flex items-center gap-4 p-3 rounded-lg border hover:bg-gray-50 transition-colors cursor-pointer">
                    <div className="w-2 h-10 rounded-full bg-red-500"></div>
                    <div className="flex-1">
                      <h4 className="font-medium">{event.title}</h4>
                      <p className="text-sm text-gray-500">
                        {format(event.start, "E, MMM d")} • {format(event.start, "h:mm a")} to {format(event.end, "h:mm a")}
                      </p>
                    </div>
                    <div>
                      <Button variant="ghost" size="sm">Details</Button>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8 text-gray-500">No upcoming court appearances</div>
              )}
            </TabsContent>
            <TabsContent value="deadlines">
              <div className="text-center py-8 text-gray-500">No upcoming deadlines</div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default CalendarPage;
