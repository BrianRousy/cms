
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Filter, Database, FileText, Calendar, ArrowUpDown, Plus } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";

const PrecedentsDB = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const navigate = useNavigate();

  const handleAdd = () => {
    toast({
      title: "Feature Coming Soon",
      description: "The ability to add precedents will be available in a future update.",
      duration: 3000,
    });
  };

  const mockPrecedents = [
    {
      id: 1,
      title: "Smith v. Johnson",
      court: "Supreme Court",
      year: 2023,
      category: "Contract Law",
      description: "Landmark case establishing new standard for breach of contract damages.",
    },
    {
      id: 2,
      title: "State v. Williams",
      court: "Appeals Court",
      year: 2022,
      category: "Criminal Law",
      description: "Important ruling on evidence admissibility in criminal proceedings.",
    },
    {
      id: 3,
      title: "Davis Corp v. Miller Inc",
      court: "Federal Court",
      year: 2021,
      category: "Corporate Law",
      description: "Key decision on shareholder rights in corporate governance disputes.",
    }
  ];

  const filteredPrecedents = mockPrecedents.filter(
    (precedent) =>
      precedent.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      precedent.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
      precedent.court.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Legal Precedents Database</h1>
          <p className="text-sm text-gray-500">
            Search, manage and analyze important legal precedents
          </p>
        </div>
        <Button className="bg-navy hover:bg-navy/90" onClick={handleAdd}>
          <Plus className="mr-2 h-4 w-4" />
          Add Precedent
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Precedents</CardTitle>
            <CardDescription>Available in the system</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockPrecedents.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Most Referenced</CardTitle>
            <CardDescription>Popular precedents</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-md font-medium">Smith v. Johnson</div>
            <div className="text-xs text-gray-500">Referenced in 15 cases</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Latest Addition</CardTitle>
            <CardDescription>Recently added</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-md font-medium">State v. Williams</div>
            <div className="text-xs text-gray-500">Added 2 days ago</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Precedents Library</CardTitle>
          <CardDescription>Browse and search legal precedents</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4 mb-4 items-start md:items-center justify-between">
            <div className="relative w-full md:w-96">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
              <Input 
                type="search" 
                placeholder="Search precedents..." 
                className="pl-8 w-full"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            <div className="flex gap-2">
              <Button variant="outline" size="sm" className="h-9">
                <Filter className="mr-2 h-4 w-4" />
                Filter
              </Button>
              <Button variant="outline" size="sm" className="h-9">
                <ArrowUpDown className="mr-2 h-4 w-4" />
                Sort
              </Button>
            </div>
          </div>

          <Tabs defaultValue="all" className="w-full">
            <TabsList className="mb-4">
              <TabsTrigger value="all">All Precedents</TabsTrigger>
              <TabsTrigger value="recent">Recent</TabsTrigger>
              <TabsTrigger value="favorites">Favorites</TabsTrigger>
            </TabsList>
            <TabsContent value="all" className="space-y-4">
              {filteredPrecedents.length > 0 ? (
                filteredPrecedents.map((precedent) => (
                  <Card key={precedent.id} className="overflow-hidden">
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="text-lg">{precedent.title}</CardTitle>
                          <CardDescription>{precedent.court}, {precedent.year}</CardDescription>
                        </div>
                        <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-200">
                          {precedent.category}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="pb-3">
                      <p className="text-sm text-gray-600">{precedent.description}</p>
                    </CardContent>
                    <CardFooter className="bg-gray-50 pt-2 pb-2 flex justify-end gap-2">
                      <Button variant="outline" size="sm">
                        <FileText className="h-4 w-4 mr-1" /> View
                      </Button>
                      <Button variant="outline" size="sm">
                        <Database className="h-4 w-4 mr-1" /> Cite
                      </Button>
                    </CardFooter>
                  </Card>
                ))
              ) : (
                <div className="text-center py-10">
                  <Database className="h-12 w-12 mx-auto text-gray-300 mb-2" />
                  <h3 className="text-lg font-medium">No precedents found</h3>
                  <p className="text-gray-500 mt-1">
                    Try adjusting your search or filters
                  </p>
                </div>
              )}
            </TabsContent>
            <TabsContent value="recent">
              <div className="text-center py-10">
                <Calendar className="h-12 w-12 mx-auto text-gray-300 mb-2" />
                <h3 className="text-lg font-medium">Recent Precedents</h3>
                <p className="text-gray-500 mt-1">
                  Your recently viewed precedents will appear here
                </p>
              </div>
            </TabsContent>
            <TabsContent value="favorites">
              <div className="text-center py-10">
                <Database className="h-12 w-12 mx-auto text-gray-300 mb-2" />
                <h3 className="text-lg font-medium">Favorite Precedents</h3>
                <p className="text-gray-500 mt-1">
                  You haven't added any precedents to your favorites yet
                </p>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default PrecedentsDB;
