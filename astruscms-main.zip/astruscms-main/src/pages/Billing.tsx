
import React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const Billing = () => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Billing</h1>
        <div className="flex space-x-2">
          <Button variant="outline">Generate Invoice</Button>
          <Button className="bg-navy hover:bg-navy/90">New Payment</Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Billing Dashboard</CardTitle>
          <CardDescription>Manage invoices and payments</CardDescription>
        </CardHeader>
        <CardContent className="text-center py-10">
          <h3 className="text-lg font-medium">Billing System</h3>
          <p className="mt-2 text-sm text-gray-500">
            This page will be implemented with comprehensive billing features
          </p>
        </CardContent>
      </Card>
    </div>
  );
};

export default Billing;
