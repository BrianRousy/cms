
import React from "react";
import { ScrollArea } from "@/components/ui/scroll-area";
import Layout from "@/components/layout";
import { Separator } from "@/components/ui/separator";

const PrivacyPolicy = () => {
  return (
    <Layout>
      <div className="container max-w-4xl mx-auto py-8 px-4">
        <h1 className="text-3xl font-bold text-navy mb-6">Privacy Policy</h1>
        <Separator className="mb-6" />
        
        <ScrollArea className="h-[70vh]">
          <div className="space-y-6 pr-4">
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">1. Introduction</h2>
              <p className="text-gray-700">
                Astrus CMS ("we," "our," or "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our legal case management system. Please read this Privacy Policy carefully.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">2. Information We Collect</h2>
              <p className="text-gray-700 mb-3">We may collect the following types of information:</p>
              <ul className="list-disc pl-6 space-y-2 text-gray-700">
                <li><strong>Personal Information:</strong> Name, email address, phone number, job title, and other contact details.</li>
                <li><strong>Case Information:</strong> Details about legal cases, client information, court documents, and related data.</li>
                <li><strong>Usage Data:</strong> Information about how you interact with our Service, including access times, pages viewed, and features used.</li>
                <li><strong>Device Information:</strong> Information about the device you use to access our Service, including IP address, browser type, and operating system.</li>
              </ul>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">3. How We Use Your Information</h2>
              <p className="text-gray-700 mb-3">We use your information for the following purposes:</p>
              <ul className="list-disc pl-6 space-y-2 text-gray-700">
                <li>To provide and maintain our Service</li>
                <li>To authenticate your identity and maintain account security</li>
                <li>To personalize your experience with our Service</li>
                <li>To respond to your inquiries and provide customer support</li>
                <li>To send administrative information, such as updates and security alerts</li>
                <li>To improve our Service through analysis of usage patterns</li>
                <li>To comply with legal obligations</li>
              </ul>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">4. Data Security</h2>
              <p className="text-gray-700">
                We implement appropriate security measures to protect your information from unauthorized access, alteration, disclosure, or destruction. These measures include encryption, access controls, regular security assessments, and staff training. However, no internet transmission or electronic storage method is 100% secure, and we cannot guarantee absolute security.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">5. Data Retention</h2>
              <p className="text-gray-700">
                We retain your information for as long as necessary to fulfill the purposes outlined in this Privacy Policy, unless a longer retention period is required by law or for legitimate business purposes. When we no longer need your information, we will securely delete or anonymize it.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">6. Sharing Your Information</h2>
              <p className="text-gray-700 mb-3">We may share your information with:</p>
              <ul className="list-disc pl-6 space-y-2 text-gray-700">
                <li><strong>Service Providers:</strong> Third-party vendors who help us operate our Service, such as hosting providers, analytics services, and customer support tools.</li>
                <li><strong>Legal Requirements:</strong> To comply with applicable laws, regulations, legal processes, or governmental requests.</li>
                <li><strong>Business Transfers:</strong> In connection with a merger, acquisition, or sale of all or part of our assets.</li>
                <li><strong>With Your Consent:</strong> With your explicit consent for purposes not covered by this Privacy Policy.</li>
              </ul>
              <p className="text-gray-700 mt-3">
                We do not sell your personal information to third parties.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">7. Your Rights</h2>
              <p className="text-gray-700 mb-3">Depending on your location, you may have certain rights regarding your information:</p>
              <ul className="list-disc pl-6 space-y-2 text-gray-700">
                <li>Access to your personal information</li>
                <li>Correction of inaccurate or incomplete information</li>
                <li>Deletion of your information under certain circumstances</li>
                <li>Restriction of processing of your information</li>
                <li>Data portability (receiving your information in a structured format)</li>
                <li>Objection to processing of your information</li>
                <li>Withdrawal of consent</li>
              </ul>
              <p className="text-gray-700 mt-3">
                To exercise these rights, please contact us using the information provided in the "Contact Us" section.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">8. Children's Privacy</h2>
              <p className="text-gray-700">
                Our Service is not directed to children under the age of 18. We do not knowingly collect personal information from children. If you believe we have collected information from a child, please contact us immediately.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">9. Changes to This Privacy Policy</h2>
              <p className="text-gray-700">
                We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last Updated" date. You are advised to review this Privacy Policy periodically for any changes.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">10. Contact Us</h2>
              <p className="text-gray-700">
                If you have questions or concerns about this Privacy Policy or our data practices, please contact us at privacy@astruscms.com.
              </p>
            </section>
            
            <div className="mt-8 text-gray-500 text-sm">
              <p>Last Updated: April 13, 2025</p>
            </div>
          </div>
        </ScrollArea>
      </div>
    </Layout>
  );
};

export default PrivacyPolicy;
