
import React, { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Play, Square, Plus, Filter, Activity, Loader2 } from "lucide-react";
import { format, startOfToday, endOfToday, startOfWeek, endOfWeek, startOfMonth, endOfMonth } from "date-fns";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { timeTrackingService, TimeEntry } from "@/services/time-tracking-service";
import { toast } from "@/hooks/use-toast";
import TimeEntryDialog from "@/components/TimeEntryDialog";
import TimeEntryCard from "@/components/TimeEntryCard";
import TimeTrackingHeader from "@/components/TimeTrackingHeader";
import TimeTrackingStats from "@/components/TimeTrackingStats";

const TimeTracking = () => {
  const queryClient = useQueryClient();
  const [isTracking, setIsTracking] = useState(false);
  const [activeEntry, setActiveEntry] = useState<TimeEntry | null>(null);
  const [timer, setTimer] = useState(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const [selectedTab, setSelectedTab] = useState("recent");
  const [isManualEntryOpen, setIsManualEntryOpen] = useState(false);
  const [isEditEntryOpen, setIsEditEntryOpen] = useState(false);
  const [editingEntry, setEditingEntry] = useState<TimeEntry | null>(null);
  
  const [currentEntry, setCurrentEntry] = useState({
    case_id: "",
    case_name: "",
    task_id: "",
    task_name: "",
    description: "",
  });

  const { data: timeEntries = [], isLoading } = useQuery({
    queryKey: ['timeEntries', selectedTab],
    queryFn: async () => {
      let result: TimeEntry[] = [];
      
      switch (selectedTab) {
        case "today":
          const todayResult = await timeTrackingService.getTimeEntriesForPeriod(startOfToday(), endOfToday());
          result = todayResult.data || [];
          break;
        case "week":
          const weekResult = await timeTrackingService.getTimeEntriesForPeriod(startOfWeek(new Date()), endOfWeek(new Date()));
          result = weekResult.data || [];
          break;
        case "month":
          const monthResult = await timeTrackingService.getTimeEntriesForPeriod(startOfMonth(new Date()), endOfMonth(new Date()));
          result = monthResult.data || [];
          break;
        default:
          const allResult = await timeTrackingService.getTimeEntries();
          result = allResult.data || [];
          break;
      }
      
      return result;
    },
    refetchOnWindowFocus: false
  });

  const startTracking = useMutation({
    mutationFn: timeTrackingService.startTimeEntry,
    onSuccess: (response) => {
      queryClient.invalidateQueries({ queryKey: ['timeEntries'] });
      if (response && response.data) {
        // Fix: Extract the TimeEntry from the response before setting state
        const timeEntryData = response.data as TimeEntry;
        setActiveEntry(timeEntryData);
      } else {
        setActiveEntry(null);
      }
      setIsTracking(true);
      startTimer();
      toast({
        title: "Time Tracking Started",
        description: `Tracking time for ${currentEntry.task_name || "task"}`,
      });
    },
  });

  const stopTracking = useMutation({
    mutationFn: ({ id, endTime, duration }: { id: string; endTime: string; duration: number }) => 
      timeTrackingService.stopTimeEntry(id, endTime, duration),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['timeEntries'] });
      setActiveEntry(null);
      setIsTracking(false);
      stopTimer();
      toast({
        title: "Time Tracking Stopped",
        description: `Tracked for ${formatTime(timer)}`,
      });
    },
  });

  const addManualEntry = useMutation({
    mutationFn: timeTrackingService.addManualEntry,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['timeEntries'] });
      setIsManualEntryOpen(false);
      toast({
        title: "Time Entry Added",
        description: "Manual time entry added successfully",
      });
    },
  });

  const updateEntry = useMutation({
    mutationFn: ({ id, updates }: { id: string; updates: Partial<TimeEntry> }) => 
      timeTrackingService.updateTimeEntry(id, updates),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['timeEntries'] });
      setIsEditEntryOpen(false);
      setEditingEntry(null);
      toast({
        title: "Time Entry Updated",
        description: "Entry updated successfully",
      });
    },
  });

  const deleteEntry = useMutation({
    mutationFn: timeTrackingService.deleteTimeEntry,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['timeEntries'] });
      toast({
        title: "Time Entry Deleted",
        description: "Entry deleted successfully",
      });
    },
  });

  const startTimer = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    
    setTimer(0);
    timerRef.current = setInterval(() => {
      setTimer(prev => prev + 1);
    }, 1000);
  };

  const stopTimer = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  };

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const toggleTracking = () => {
    if (isTracking && activeEntry) {
      stopTracking.mutate({
        id: activeEntry.id!,
        endTime: new Date().toISOString(),
        duration: timer
      });
    } else {
      startTracking.mutate({
        case_id: currentEntry.case_id,
        case_name: currentEntry.case_name || "Unnamed Case",
        task_id: currentEntry.task_id,
        task_name: currentEntry.task_name || "Unnamed Task",
        description: currentEntry.description,
        start_time: new Date().toISOString(),
        billable: true,
        status: 'active',
        user_id: "" // Will be set by service
      });
    }
  };

  const handleEditEntry = (entry: TimeEntry) => {
    setEditingEntry(entry);
    setIsEditEntryOpen(true);
  };

  const handleDeleteEntry = (id: string) => {
    if (confirm("Are you sure you want to delete this time entry?")) {
      deleteEntry.mutate(id);
    }
  };

  const handleSaveEdit = (entryData: Omit<TimeEntry, 'id' | 'created_at' | 'updated_at'>) => {
    if (!editingEntry?.id) return;
    
    updateEntry.mutate({
      id: editingEntry.id,
      updates: entryData
    });
  };

  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, []);

  return (
    <div className="space-y-6">
      <TimeTrackingHeader 
        onAddManualEntry={() => setIsManualEntryOpen(true)} 
      />

      <Card>
        <CardHeader className="pb-3">
          <CardTitle>Track Time</CardTitle>
          <CardDescription>Record billable hours for cases and tasks</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-4">
            <div className="col-span-2 md:col-span-1">
              <Select
                value={currentEntry.case_id}
                onValueChange={(value) => setCurrentEntry({
                  ...currentEntry, 
                  case_id: value,
                  case_name: value === "case1" ? "Smith vs. Jones" :
                            value === "case2" ? "ABC Corp Merger" :
                            value === "case3" ? "Estate of Johnson" : ""
                })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select Case" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="case1">Smith vs. Jones</SelectItem>
                  <SelectItem value="case2">ABC Corp Merger</SelectItem>
                  <SelectItem value="case3">Estate of Johnson</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="col-span-2 md:col-span-1">
              <Select
                value={currentEntry.task_id}
                onValueChange={(value) => setCurrentEntry({
                  ...currentEntry, 
                  task_id: value,
                  task_name: value === "task1" ? "Document Review" :
                           value === "task2" ? "Client Meeting" :
                           value === "task3" ? "Court Appearance" :
                           value === "task4" ? "Legal Research" : ""
                })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select Task" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="task1">Document Review</SelectItem>
                  <SelectItem value="task2">Client Meeting</SelectItem>
                  <SelectItem value="task3">Court Appearance</SelectItem>
                  <SelectItem value="task4">Legal Research</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="col-span-4 md:col-span-1">
              <Input 
                placeholder="Description (optional)" 
                value={currentEntry.description}
                onChange={(e) => setCurrentEntry({...currentEntry, description: e.target.value})}
              />
            </div>
            
            <div className="col-span-4 md:col-span-1">
              <Button 
                onClick={toggleTracking}
                disabled={isTracking ? false : !currentEntry.case_id || !currentEntry.task_id}
                className={isTracking ? "bg-red-500 hover:bg-red-600 w-full" : "bg-navy hover:bg-navy/90 w-full"}
              >
                {isTracking ? (
                  <>
                    <Square className="mr-2 h-4 w-4" />
                    Stop ({formatTime(timer)})
                  </>
                ) : startTracking.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Starting...
                  </>
                ) : (
                  <>
                    <Play className="mr-2 h-4 w-4" />
                    Start Timer
                  </>
                )}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <TimeTrackingStats />

      <Tabs defaultValue="recent" value={selectedTab} onValueChange={setSelectedTab}>
        <div className="flex items-center justify-between mb-4">
          <TabsList>
            <TabsTrigger value="recent">Recent</TabsTrigger>
            <TabsTrigger value="today">Today</TabsTrigger>
            <TabsTrigger value="week">This Week</TabsTrigger>
            <TabsTrigger value="month">This Month</TabsTrigger>
          </TabsList>
          
          <Button variant="outline" size="sm">
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
        </div>
        
        <TabsContent value="recent" className="space-y-4">
          {isLoading ? (
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="animate-pulse">
                  <CardContent className="p-4">
                    <div className="h-16 bg-gray-200 rounded"></div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : timeEntries.length > 0 ? (
            timeEntries.map((entry) => (
              <TimeEntryCard 
                key={entry.id}
                entry={entry}
                onEdit={handleEditEntry}
                onDelete={handleDeleteEntry}
              />
            ))
          ) : (
            <div className="text-center py-10">
              <Activity className="mx-auto h-8 w-8 text-gray-400" />
              <h3 className="mt-4 text-lg font-medium">No Time Entries</h3>
              <p className="mt-2 text-sm text-gray-500">Start tracking time or add manual entries.</p>
              <Button className="mt-4" onClick={() => setIsManualEntryOpen(true)}>
                <Plus className="mr-2 h-4 w-4" />
                Add Your First Entry
              </Button>
            </div>
          )}
        </TabsContent>
        
        {['today', 'week', 'month'].map((tab) => (
          <TabsContent key={tab} value={tab} className="space-y-4">
            {isLoading ? (
              <div className="space-y-4">
                {[1, 2].map((i) => (
                  <Card key={i} className="animate-pulse">
                    <CardContent className="p-4">
                      <div className="h-16 bg-gray-200 rounded"></div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : timeEntries.length > 0 ? (
              timeEntries.map((entry) => (
                <TimeEntryCard 
                  key={entry.id}
                  entry={entry}
                  onEdit={handleEditEntry}
                  onDelete={handleDeleteEntry}
                />
              ))
            ) : (
              <div className="text-center py-10">
                <Activity className="mx-auto h-8 w-8 text-gray-400" />
                <h3 className="mt-4 text-lg font-medium">No {tab === 'today' ? "Today's" : tab === 'week' ? "This Week's" : "This Month's"} Time Entries</h3>
                <p className="mt-2 text-sm text-gray-500">Start tracking time for this period.</p>
              </div>
            )}
          </TabsContent>
        ))}
      </Tabs>

      {/* Add Manual Entry Dialog */}
      <TimeEntryDialog 
        open={isManualEntryOpen}
        onOpenChange={setIsManualEntryOpen}
        onSave={(entryData) => {
          addManualEntry.mutate(entryData);
        }}
        mode="add"
      />

      {/* Edit Entry Dialog */}
      <TimeEntryDialog 
        open={isEditEntryOpen}
        onOpenChange={setIsEditEntryOpen}
        onSave={handleSaveEdit}
        initialEntry={editingEntry || undefined}
        mode="edit"
      />
    </div>
  );
};

export default TimeTracking;
