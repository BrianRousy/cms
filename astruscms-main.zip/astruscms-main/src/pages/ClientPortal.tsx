
import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { 
  Plus, 
  Users, 
  MessageCircle, 
  CreditCard, 
  Settings, 
  Link, 
  Search, 
  FileText, 
  Mail, 
  Bell, 
  Clock,
  Download,
  ExternalLink,
  RefreshCcw,
  CheckCircle,
  Eye
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";

const ClientPortal = () => {
  const [activeTab, setActiveTab] = useState("clients");
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();
  
  const handleAddClient = () => {
    toast({
      title: "Client Access Created",
      description: "An invitation has been sent to the client's email",
    });
  };
  
  const handleSendInvite = (clientName: string) => {
    toast({
      title: "Invitation Sent",
      description: `Access link has been sent to ${clientName}`,
    });
  };
  
  const handleSendMessage = () => {
    toast({
      title: "Message Sent",
      description: "Your message has been sent to the client",
    });
  };
  
  const handleUpdateSettings = () => {
    toast({
      title: "Settings Updated",
      description: "Portal settings have been successfully updated",
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Client Portal</h1>
        <Dialog>
          <DialogTrigger asChild>
            <Button className="bg-navy hover:bg-navy/90">
              <Plus className="mr-2 h-4 w-4" />
              Add Client Access
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[550px]">
            <DialogHeader>
              <DialogTitle>Add Client Portal Access</DialogTitle>
              <DialogDescription>
                Create portal access for a client and send them an invitation email
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <label htmlFor="firstName" className="text-sm font-medium">First Name</label>
                  <Input id="firstName" placeholder="First name" />
                </div>
                <div className="grid gap-2">
                  <label htmlFor="lastName" className="text-sm font-medium">Last Name</label>
                  <Input id="lastName" placeholder="Last name" />
                </div>
              </div>
              <div className="grid gap-2">
                <label htmlFor="email" className="text-sm font-medium">Email Address</label>
                <Input id="email" type="email" placeholder="client@example.com" />
              </div>
              <div className="grid gap-2">
                <label htmlFor="phone" className="text-sm font-medium">Phone Number</label>
                <Input id="phone" placeholder="Phone number" />
              </div>
              <div className="grid gap-2">
                <label htmlFor="case" className="text-sm font-medium">Associated Case</label>
                <Select>
                  <SelectTrigger id="case">
                    <SelectValue placeholder="Select a case" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="case1">Smith v. Jones</SelectItem>
                    <SelectItem value="case2">ABC Corp Litigation</SelectItem>
                    <SelectItem value="case3">Estate of Williams</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <label htmlFor="access" className="text-sm font-medium">Access Level</label>
                <Select defaultValue="standard">
                  <SelectTrigger id="access">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="limited">Limited (Documents Only)</SelectItem>
                    <SelectItem value="standard">Standard (Documents & Messages)</SelectItem>
                    <SelectItem value="full">Full (Documents, Messages & Invoices)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="sendInvite" defaultChecked />
                <label htmlFor="sendInvite" className="text-sm">
                  Send invitation email immediately
                </label>
              </div>
            </div>
            <DialogFooter>
              <Button type="submit" onClick={handleAddClient}>
                Create Access
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Client Portal Dashboard</CardTitle>
          <CardDescription>
            Manage your client portal settings and monitor client activity
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-6 md:grid-cols-3">
          <div className="flex flex-col items-center justify-center p-6 bg-gray-50 rounded-lg">
            <Users className="h-10 w-10 text-navy mb-2" />
            <h3 className="font-medium">12</h3>
            <p className="text-sm text-gray-500">Active Client Accounts</p>
          </div>
          <div className="flex flex-col items-center justify-center p-6 bg-gray-50 rounded-lg">
            <MessageCircle className="h-10 w-10 text-navy mb-2" />
            <h3 className="font-medium">24</h3>
            <p className="text-sm text-gray-500">Unread Messages</p>
          </div>
          <div className="flex flex-col items-center justify-center p-6 bg-gray-50 rounded-lg">
            <CreditCard className="h-10 w-10 text-navy mb-2" />
            <h3 className="font-medium">$8,450</h3>
            <p className="text-sm text-gray-500">Pending Payments</p>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="clients" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="w-full md:w-auto grid grid-cols-4 md:inline-flex">
          <TabsTrigger value="clients">Client Access</TabsTrigger>
          <TabsTrigger value="messages">Messages</TabsTrigger>
          <TabsTrigger value="documents">Documents</TabsTrigger>
          <TabsTrigger value="settings">Portal Settings</TabsTrigger>
        </TabsList>
        
        <TabsContent value="clients" className="mt-6">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Client Portal Access</CardTitle>
                  <CardDescription>
                    Manage clients with access to the portal
                  </CardDescription>
                </div>
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                  <Input 
                    placeholder="Search clients..." 
                    className="pl-8 w-60" 
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  {
                    id: 1,
                    initials: "JD",
                    name: "John Doe",
                    email: "john@example.com",
                    status: "Active",
                    lastLogin: "Today, 10:45 AM",
                    case: "Smith v. Jones"
                  },
                  {
                    id: 2,
                    initials: "MS",
                    name: "Martha Smith",
                    email: "martha@example.com",
                    status: "Pending",
                    lastLogin: "Never",
                    case: "Estate of Williams"
                  },
                  {
                    id: 3,
                    initials: "AK",
                    name: "Alex Kepler",
                    email: "alex@example.com",
                    status: "Active",
                    lastLogin: "Yesterday, 3:20 PM",
                    case: "ABC Corp Litigation"
                  }
                ].map((client) => (
                  <div key={client.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center text-sm font-medium">
                        {client.initials}
                      </div>
                      <div>
                        <h4 className="font-medium">{client.name}</h4>
                        <p className="text-sm text-gray-500">{client.email}</p>
                        <p className="text-xs text-gray-500">Case: {client.case}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Badge className={client.status === "Pending" ? "bg-amber-500" : "bg-green-600"}>
                        {client.status}
                      </Badge>
                      <div className="text-xs text-gray-500 hidden md:block">
                        Last login: {client.status === "Pending" ? "Never" : client.lastLogin}
                      </div>
                      <Button 
                        size="sm" 
                        variant="outline" 
                        onClick={() => handleSendInvite(client.name)}
                      >
                        <Link className="h-4 w-4 mr-2" />
                        Send Link
                      </Button>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button size="sm" variant="ghost">Manage</Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Manage Client Access</DialogTitle>
                            <DialogDescription>
                              Update access settings for {client.name}
                            </DialogDescription>
                          </DialogHeader>
                          <div className="py-4">
                            <div className="space-y-4">
                              <div className="flex justify-between items-center">
                                <div className="space-y-0.5">
                                  <h4 className="text-sm font-medium">Documents Access</h4>
                                  <p className="text-xs text-gray-500">Allow client to view shared documents</p>
                                </div>
                                <Switch defaultChecked id="documents-access" />
                              </div>
                              <div className="flex justify-between items-center">
                                <div className="space-y-0.5">
                                  <h4 className="text-sm font-medium">Messaging</h4>
                                  <p className="text-xs text-gray-500">Allow client to send and receive messages</p>
                                </div>
                                <Switch defaultChecked id="messaging-access" />
                              </div>
                              <div className="flex justify-between items-center">
                                <div className="space-y-0.5">
                                  <h4 className="text-sm font-medium">Invoices & Payments</h4>
                                  <p className="text-xs text-gray-500">Allow client to view and pay invoices</p>
                                </div>
                                <Switch defaultChecked id="invoice-access" />
                              </div>
                              <div className="flex justify-between items-center">
                                <div className="space-y-0.5">
                                  <h4 className="text-sm font-medium">Calendar Access</h4>
                                  <p className="text-xs text-gray-500">Allow client to view events and schedule meetings</p>
                                </div>
                                <Switch id="calendar-access" />
                              </div>
                              <div className="pt-4 border-t">
                                <Button variant="destructive" className="w-full">Reset Password</Button>
                              </div>
                              <div className="pt-4">
                                <Button variant="outline" className="w-full text-red-600 hover:text-red-700 hover:bg-red-50">
                                  Disable Access
                                </Button>
                              </div>
                            </div>
                          </div>
                          <DialogFooter>
                            <Button onClick={() => toast({ title: "Access Updated", description: `Access settings for ${client.name} have been updated` })}>
                              Save Changes
                            </Button>
                          </DialogFooter>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
            <CardFooter className="border-t px-6 py-4">
              <div className="flex items-center justify-between w-full">
                <p className="text-sm text-gray-500">Showing 3 of 12 clients</p>
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm" disabled>
                    Previous
                  </Button>
                  <Button variant="outline" size="sm">
                    Next
                  </Button>
                </div>
              </div>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="messages" className="mt-6 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Client Messages</CardTitle>
              <CardDescription>
                View and respond to client messages
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="border rounded-md overflow-hidden">
                <div className="border-b bg-gray-50 p-3 flex justify-between items-center">
                  <div className="flex items-center space-x-2">
                    <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center">
                      <span className="font-medium text-sm text-blue-700">JD</span>
                    </div>
                    <div>
                      <h4 className="font-medium">John Doe</h4>
                      <p className="text-xs text-gray-500">Smith v. Jones</p>
                    </div>
                  </div>
                  <Badge>3 Unread</Badge>
                </div>
                
                <div className="h-64 p-4 space-y-4 overflow-y-auto">
                  <div className="flex flex-col max-w-[80%] space-y-1">
                    <div className="bg-gray-100 rounded-lg p-3">
                      <p className="text-sm">Hello, I wanted to ask about the status of my case documents.</p>
                    </div>
                    <span className="text-xs text-gray-500">John Doe • Apr 10, 9:23 AM</span>
                  </div>
                  
                  <div className="flex flex-col max-w-[80%] ml-auto items-end space-y-1">
                    <div className="bg-blue-100 rounded-lg p-3">
                      <p className="text-sm">Hi John, I've reviewed the documents and will be uploading them to the portal shortly.</p>
                    </div>
                    <span className="text-xs text-gray-500">You • Apr 10, 10:15 AM</span>
                  </div>
                  
                  <div className="flex flex-col max-w-[80%] space-y-1">
                    <div className="bg-gray-100 rounded-lg p-3">
                      <p className="text-sm">Thank you! Also, when is our next court date?</p>
                    </div>
                    <span className="text-xs text-gray-500">John Doe • Apr 10, 10:17 AM</span>
                  </div>
                  
                  <div className="flex flex-col max-w-[80%] space-y-1">
                    <div className="bg-gray-100 rounded-lg p-3">
                      <p className="text-sm">I need to request time off from work.</p>
                    </div>
                    <span className="text-xs text-gray-500">John Doe • Apr 10, 10:18 AM</span>
                  </div>
                </div>
                
                <div className="p-4 border-t">
                  <div className="flex space-x-2">
                    <Input placeholder="Type your message..." className="flex-1" />
                    <Button onClick={handleSendMessage}>
                      <MessageCircle className="h-4 w-4 mr-2" />
                      Send
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <div className="grid gap-6 md:grid-cols-3">
            <Card className="md:col-span-1">
              <CardHeader>
                <CardTitle>Recent Conversations</CardTitle>
                <CardDescription>Client message threads</CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                <div className="divide-y">
                  {[
                    { name: "John Doe", initials: "JD", case: "Smith v. Jones", time: "10:18 AM", unread: 3 },
                    { name: "Martha Smith", initials: "MS", case: "Estate of Williams", time: "Yesterday", unread: 0 },
                    { name: "Alex Kepler", initials: "AK", case: "ABC Corp Litigation", time: "Apr 9", unread: 1 },
                  ].map((client, idx) => (
                    <div key={idx} className={`flex items-center space-x-3 p-4 hover:bg-gray-50 cursor-pointer ${idx === 0 ? 'bg-gray-50' : ''}`}>
                      <div className={`h-10 w-10 rounded-full flex items-center justify-center text-sm font-medium ${client.unread > 0 ? 'bg-blue-100 text-blue-700' : 'bg-gray-200'}`}>
                        {client.initials}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-center">
                          <h4 className="font-medium">{client.name}</h4>
                          <span className="text-xs text-gray-500">{client.time}</span>
                        </div>
                        <p className="text-sm text-gray-500 truncate">{client.case}</p>
                      </div>
                      {client.unread > 0 && (
                        <Badge className="bg-blue-500">{client.unread}</Badge>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>Message Templates</CardTitle>
                <CardDescription>Quickly respond using pre-defined templates</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {[
                  { title: "Case Update", content: "Dear [Client Name], I'm writing with an update on your case..." },
                  { title: "Document Request", content: "Hello [Client Name], We need the following documents to proceed..." },
                  { title: "Meeting Schedule", content: "Hi [Client Name], I'd like to schedule a meeting to discuss..." },
                ].map((template, idx) => (
                  <div key={idx} className="border rounded-md p-3">
                    <div className="flex justify-between items-center mb-2">
                      <h4 className="font-medium">{template.title}</h4>
                      <Button size="sm" variant="ghost" onClick={() => toast({ title: "Template Applied", description: "Message template has been applied" })}>
                        Use Template
                      </Button>
                    </div>
                    <p className="text-sm text-gray-500">{template.content}</p>
                  </div>
                ))}
                <Button variant="outline" className="w-full" onClick={() => toast({ title: "Coming Soon", description: "Template creation will be available soon" })}>
                  <Plus className="h-4 w-4 mr-2" />
                  Create New Template
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="documents" className="mt-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Shared Documents</CardTitle>
                  <CardDescription>
                    Manage documents shared with clients through the portal
                  </CardDescription>
                </div>
                <Button onClick={() => toast({ title: "Coming Soon", description: "Document sharing feature will be available soon" })}>
                  <Plus className="mr-2 h-4 w-4" />
                  Share Document
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { title: "Contract Draft v2.pdf", client: "John Doe", case: "Smith v. Jones", date: "Apr 10, 2024", size: "2.4 MB", status: "Viewed" },
                  { title: "Settlement Agreement.docx", client: "Martha Smith", case: "Estate of Williams", date: "Apr 8, 2024", size: "1.1 MB", status: "Not Viewed" },
                  { title: "Litigation Schedule.pdf", client: "Alex Kepler", case: "ABC Corp Litigation", date: "Apr 5, 2024", size: "843 KB", status: "Viewed" },
                ].map((doc, idx) => (
                  <div key={idx} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="h-10 w-10 rounded-md bg-gray-100 flex items-center justify-center">
                        <FileText className="h-5 w-5 text-gray-500" />
                      </div>
                      <div>
                        <h4 className="font-medium">{doc.title}</h4>
                        <p className="text-xs text-gray-500">
                          Shared with {doc.client} • {doc.case}
                        </p>
                        <div className="flex items-center mt-1 text-xs text-gray-500 space-x-2">
                          <span>Shared on {doc.date}</span>
                          <span>•</span>
                          <span>{doc.size}</span>
                          <span>•</span>
                          <span className="flex items-center">
                            {doc.status === "Viewed" ? (
                              <>
                                <Eye className="h-3 w-3 mr-1 text-green-600" />
                                <span className="text-green-600">Viewed</span>
                              </>
                            ) : (
                              <>
                                <Clock className="h-3 w-3 mr-1 text-amber-500" />
                                <span className="text-amber-500">Not Viewed</span>
                              </>
                            )}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button size="sm" variant="outline">
                        <Download className="h-4 w-4 mr-2" />
                        Download
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => toast({ title: "Revoked", description: `Access to ${doc.title} has been revoked` })}>
                        Revoke
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
          
          <div className="grid gap-6 md:grid-cols-2 mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Document Activity</CardTitle>
                <CardDescription>Recent client document interactions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { action: "viewed", client: "John Doe", doc: "Contract Draft v2.pdf", time: "Today, 11:23 AM" },
                    { action: "downloaded", client: "Alex Kepler", doc: "Litigation Schedule.pdf", time: "Yesterday, 3:45 PM" },
                    { action: "viewed", client: "John Doe", doc: "Case Brief.pdf", time: "Apr 8, 2024" },
                  ].map((activity, idx) => (
                    <div key={idx} className="flex items-center space-x-3">
                      <div className={`h-8 w-8 rounded-full flex items-center justify-center ${activity.action === 'viewed' ? 'bg-blue-100' : 'bg-green-100'}`}>
                        {activity.action === 'viewed' ? (
                          <Eye className="h-4 w-4 text-blue-600" />
                        ) : (
                          <Download className="h-4 w-4 text-green-600" />
                        )}
                      </div>
                      <div className="flex-1">
                        <p className="text-sm">
                          <span className="font-medium">{activity.client}</span> {activity.action} <span className="font-medium">{activity.doc}</span>
                        </p>
                        <p className="text-xs text-gray-500">{activity.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Document Request Forms</CardTitle>
                <CardDescription>Manage client document requests</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <p className="text-sm text-gray-500">Allow clients to submit document requests through customizable forms</p>
                  <Button className="w-full" onClick={() => toast({ title: "Coming Soon", description: "Document request forms will be available in the next update" })}>
                    <Plus className="mr-2 h-4 w-4" />
                    Create Request Form
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="settings" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Portal Settings</CardTitle>
              <CardDescription>
                Configure your client portal settings
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Appearance</h3>
                  <div className="space-y-4">
                    <div className="flex items-start space-x-4">
                      <div className="h-16 w-16 border rounded flex items-center justify-center">
                        <svg
                          className="h-12 w-12 text-navy"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <path d="M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z" />
                        </svg>
                      </div>
                      <div className="space-y-1">
                        <h4 className="font-medium">Firm Logo</h4>
                        <p className="text-sm text-gray-500">Upload your firm logo to display in the client portal</p>
                        <Button variant="outline" size="sm">Upload Logo</Button>
                      </div>
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium">Portal Color Theme</label>
                      <div className="grid grid-cols-5 gap-2 mt-2">
                        {["bg-navy", "bg-blue-600", "bg-green-600", "bg-purple-600", "bg-red-600"].map((color, idx) => (
                          <div 
                            key={idx} 
                            className={`h-8 rounded-md cursor-pointer ${color} ${idx === 0 ? 'ring-2 ring-offset-2 ring-navy' : ''}`}
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="pt-6 border-t space-y-4">
                  <h3 className="text-lg font-medium">Features & Access</h3>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <div className="space-y-0.5">
                        <h4 className="text-sm font-medium">Document Sharing</h4>
                        <p className="text-xs text-gray-500">Allow clients to view and download shared documents</p>
                      </div>
                      <Switch defaultChecked id="docs-feature" />
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <div className="space-y-0.5">
                        <h4 className="text-sm font-medium">Messaging System</h4>
                        <p className="text-xs text-gray-500">Enable secure messaging between clients and legal team</p>
                      </div>
                      <Switch defaultChecked id="messaging-feature" />
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <div className="space-y-0.5">
                        <h4 className="text-sm font-medium">Invoice & Payment</h4>
                        <p className="text-xs text-gray-500">Allow clients to view and pay invoices online</p>
                      </div>
                      <Switch defaultChecked id="invoice-feature" />
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <div className="space-y-0.5">
                        <h4 className="text-sm font-medium">Case Calendar</h4>
                        <p className="text-xs text-gray-500">Show relevant case dates and events to clients</p>
                      </div>
                      <Switch defaultChecked id="calendar-feature" />
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <div className="space-y-0.5">
                        <h4 className="text-sm font-medium">Document Requests</h4>
                        <p className="text-xs text-gray-500">Allow clients to submit document requests</p>
                      </div>
                      <Switch id="doc-requests-feature" />
                    </div>
                  </div>
                </div>
                
                <div className="pt-6 border-t space-y-4">
                  <h3 className="text-lg font-medium">Notifications</h3>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <div className="space-y-0.5">
                        <h4 className="text-sm font-medium">Email Notifications</h4>
                        <p className="text-xs text-gray-500">Send email notifications for portal activity</p>
                      </div>
                      <Switch defaultChecked id="email-notifications" />
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Input id="welcome-subject" placeholder="Welcome Email Subject" defaultValue="Welcome to [Firm Name] Client Portal" />
                    </div>
                    
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Welcome Email Template</label>
                      <Textarea 
                        id="welcome-template" 
                        className="min-h-[100px]" 
                        defaultValue="Dear [Client Name],\n\nWelcome to our client portal. Your account has been created and you can access your case information securely through our online platform.\n\nYour login details are below:\n[Login Details]\n\nIf you have any questions, please don't hesitate to contact us.\n\nBest regards,\n[Attorney Name]\n[Firm Name]"
                      />
                    </div>
                  </div>
                </div>
                
                <div className="pt-6 border-t space-y-4">
                  <h3 className="text-lg font-medium">Security</h3>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <div className="space-y-0.5">
                        <h4 className="text-sm font-medium">Two-Factor Authentication</h4>
                        <p className="text-xs text-gray-500">Require 2FA for client logins</p>
                      </div>
                      <Switch id="2fa-setting" />
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <div className="space-y-0.5">
                        <h4 className="text-sm font-medium">Session Timeout</h4>
                        <p className="text-xs text-gray-500">Automatically log out inactive users</p>
                      </div>
                      <Select defaultValue="30">
                        <SelectTrigger className="w-24">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="15">15 min</SelectItem>
                          <SelectItem value="30">30 min</SelectItem>
                          <SelectItem value="60">60 min</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="border-t flex justify-between">
              <Button variant="outline">Reset to Defaults</Button>
              <Button onClick={handleUpdateSettings}>Save Settings</Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ClientPortal;
