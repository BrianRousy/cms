
import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import {
  Users,
  UserPlus,
  Clock,
  Calendar,
  DollarSign,
  Search,
  Filter,
  Download,
  FileText,
  Mail,
  Check,
  X,
  Briefcase,
  UserCheck,
  CalendarDays,
  BarChart
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

// Mock employee data
const employees = [
  {
    id: "1",
    name: "James Wilson",
    position: "Senior Associate",
    department: "Litigation",
    email: "jwilson@example.com",
    phone: "(555) 123-4567",
    status: "active",
    hireDate: "2020-03-15",
    salary: 110000
  },
  {
    id: "2",
    name: "Sarah Chen",
    position: "Paralegal",
    department: "Corporate",
    email: "schen@example.com",
    phone: "(555) 234-5678",
    status: "active",
    hireDate: "2021-07-22",
    salary: 65000
  },
  {
    id: "3",
    name: "Michael Rodriguez",
    position: "Associate",
    department: "Family Law",
    email: "mrodriguez@example.com",
    phone: "(555) 345-6789",
    status: "active",
    hireDate: "2022-01-10",
    salary: 85000
  },
  {
    id: "4",
    name: "Emily Johnson",
    position: "Legal Secretary",
    department: "Litigation",
    email: "ejohnson@example.com",
    phone: "(555) 456-7890",
    status: "active",
    hireDate: "2021-05-03",
    salary: 52000
  },
];

// Mock leave requests
const leaveRequests = [
  {
    id: "1",
    employeeId: "1",
    employeeName: "James Wilson",
    type: "Vacation",
    startDate: "2024-04-22",
    endDate: "2024-04-26",
    status: "approved",
    requestDate: "2024-03-25"
  },
  {
    id: "2",
    employeeId: "2",
    employeeName: "Sarah Chen",
    type: "Sick",
    startDate: "2024-04-15",
    endDate: "2024-04-16",
    status: "approved",
    requestDate: "2024-04-14"
  },
  {
    id: "3",
    employeeId: "3",
    employeeName: "Michael Rodriguez",
    type: "Vacation",
    startDate: "2024-05-10",
    endDate: "2024-05-17",
    status: "pending",
    requestDate: "2024-04-05"
  }
];

const HumanResources = () => {
  const [activeTab, setActiveTab] = useState("employees");
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();
  
  const handleAddEmployee = () => {
    toast({
      title: "Employee Added",
      description: "New employee has been added successfully",
    });
  };
  
  const handleProcessPayroll = () => {
    toast({
      title: "Payroll Processing",
      description: "Payroll is being processed for the current period",
    });
  };

  const handleApproveLeave = (id: string) => {
    toast({
      title: "Leave Approved",
      description: "Leave request has been approved",
    });
  };
  
  const handleRejectLeave = (id: string) => {
    toast({
      title: "Leave Rejected",
      description: "Leave request has been rejected",
    });
  };

  // Filter employees based on search query
  const filteredEmployees = employees.filter(employee => {
    if (!searchQuery) return true;
    
    return (
      employee.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      employee.position.toLowerCase().includes(searchQuery.toLowerCase()) ||
      employee.department.toLowerCase().includes(searchQuery.toLowerCase())
    );
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Human Resources</h1>
          <p className="text-sm text-gray-500">
            Manage employees, payroll, and attendance
          </p>
        </div>
        <Dialog>
          <DialogTrigger asChild>
            <Button className="bg-navy hover:bg-navy/90">
              <UserPlus className="mr-2 h-4 w-4" />
              Add Employee
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[550px]">
            <DialogHeader>
              <DialogTitle>Add New Employee</DialogTitle>
              <DialogDescription>
                Enter the details of the new employee
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <label htmlFor="firstName" className="text-sm font-medium">First Name</label>
                  <Input id="firstName" placeholder="First name" />
                </div>
                <div className="grid gap-2">
                  <label htmlFor="lastName" className="text-sm font-medium">Last Name</label>
                  <Input id="lastName" placeholder="Last name" />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <label htmlFor="position" className="text-sm font-medium">Position</label>
                  <Input id="position" placeholder="Job position" />
                </div>
                <div className="grid gap-2">
                  <label htmlFor="department" className="text-sm font-medium">Department</label>
                  <Select>
                    <SelectTrigger id="department">
                      <SelectValue placeholder="Select department" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="litigation">Litigation</SelectItem>
                      <SelectItem value="corporate">Corporate</SelectItem>
                      <SelectItem value="family">Family Law</SelectItem>
                      <SelectItem value="realestate">Real Estate</SelectItem>
                      <SelectItem value="admin">Administration</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="grid gap-2">
                <label htmlFor="email" className="text-sm font-medium">Email</label>
                <Input id="email" type="email" placeholder="Email address" />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <label htmlFor="phone" className="text-sm font-medium">Phone</label>
                  <Input id="phone" placeholder="Phone number" />
                </div>
                <div className="grid gap-2">
                  <label htmlFor="startDate" className="text-sm font-medium">Start Date</label>
                  <Input id="startDate" type="date" />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <label htmlFor="salary" className="text-sm font-medium">Salary</label>
                  <div className="relative">
                    <span className="absolute left-3 top-2.5">$</span>
                    <Input id="salary" type="number" className="pl-7" placeholder="Annual salary" />
                  </div>
                </div>
                <div className="grid gap-2">
                  <label htmlFor="employmentType" className="text-sm font-medium">Employment Type</label>
                  <Select>
                    <SelectTrigger id="employmentType">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="fullTime">Full-time</SelectItem>
                      <SelectItem value="partTime">Part-time</SelectItem>
                      <SelectItem value="contract">Contract</SelectItem>
                      <SelectItem value="intern">Intern</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button type="submit" onClick={handleAddEmployee}>
                Add Employee
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="employees" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="w-full md:w-auto grid grid-cols-3 md:inline-flex">
          <TabsTrigger value="employees">Employee Directory</TabsTrigger>
          <TabsTrigger value="payroll">Payroll</TabsTrigger>
          <TabsTrigger value="attendance">Attendance & Leave</TabsTrigger>
        </TabsList>
        
        <TabsContent value="employees" className="mt-6">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                  <CardTitle>Employee Directory</CardTitle>
                  <CardDescription>
                    Manage your firm's employees
                  </CardDescription>
                </div>
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                  <Input 
                    placeholder="Search employees..." 
                    className="pl-8 w-full md:w-60" 
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <div className="relative w-full overflow-auto">
                  <table className="w-full caption-bottom text-sm">
                    <thead>
                      <tr className="border-b bg-gray-50">
                        <th className="h-10 px-4 text-left font-medium text-gray-500">Name</th>
                        <th className="h-10 px-4 text-left font-medium text-gray-500">Position</th>
                        <th className="h-10 px-4 text-left font-medium text-gray-500 hidden md:table-cell">Department</th>
                        <th className="h-10 px-4 text-left font-medium text-gray-500 hidden md:table-cell">Email</th>
                        <th className="h-10 px-4 text-right font-medium text-gray-500">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredEmployees.map((employee) => (
                        <tr key={employee.id} className="border-b hover:bg-gray-50">
                          <td className="p-4">
                            <div className="flex items-center">
                              <Avatar className="h-8 w-8 mr-2">
                                <AvatarFallback className="bg-navy text-white">
                                  {employee.name.split(' ').map(n => n[0]).join('')}
                                </AvatarFallback>
                              </Avatar>
                              <span>{employee.name}</span>
                            </div>
                          </td>
                          <td className="p-4">{employee.position}</td>
                          <td className="p-4 hidden md:table-cell">{employee.department}</td>
                          <td className="p-4 hidden md:table-cell">{employee.email}</td>
                          <td className="p-4 text-right">
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button variant="ghost" size="sm">View Details</Button>
                              </DialogTrigger>
                              <DialogContent className="sm:max-w-[550px]">
                                <DialogHeader>
                                  <DialogTitle>Employee Details</DialogTitle>
                                  <DialogDescription>
                                    Comprehensive information about {employee.name}
                                  </DialogDescription>
                                </DialogHeader>
                                <div className="py-4">
                                  <div className="flex flex-col items-center mb-6">
                                    <Avatar className="h-20 w-20 mb-3">
                                      <AvatarFallback className="bg-navy text-white text-xl">
                                        {employee.name.split(' ').map(n => n[0]).join('')}
                                      </AvatarFallback>
                                    </Avatar>
                                    <h3 className="text-xl font-medium">{employee.name}</h3>
                                    <p className="text-gray-500">{employee.position}</p>
                                  </div>
                                  
                                  <div className="grid grid-cols-2 gap-4">
                                    <div>
                                      <p className="text-sm text-gray-500">Department</p>
                                      <p className="font-medium">{employee.department}</p>
                                    </div>
                                    <div>
                                      <p className="text-sm text-gray-500">Hire Date</p>
                                      <p className="font-medium">{new Date(employee.hireDate).toLocaleDateString()}</p>
                                    </div>
                                    <div>
                                      <p className="text-sm text-gray-500">Email</p>
                                      <p className="font-medium">{employee.email}</p>
                                    </div>
                                    <div>
                                      <p className="text-sm text-gray-500">Phone</p>
                                      <p className="font-medium">{employee.phone}</p>
                                    </div>
                                    <div>
                                      <p className="text-sm text-gray-500">Status</p>
                                      <Badge className="bg-green-600">Active</Badge>
                                    </div>
                                    <div>
                                      <p className="text-sm text-gray-500">Annual Salary</p>
                                      <p className="font-medium">${employee.salary.toLocaleString()}</p>
                                    </div>
                                  </div>
                                  
                                  <div className="mt-6 space-y-4">
                                    <div className="flex justify-between border-t pt-4">
                                      <h4 className="font-medium">Leave Balance</h4>
                                      <div className="text-right">
                                        <p className="text-sm">Vacation: 12 days</p>
                                        <p className="text-sm">Sick: 5 days</p>
                                      </div>
                                    </div>
                                    
                                    <div className="border-t pt-4">
                                      <h4 className="font-medium mb-2">Current Case Assignments</h4>
                                      <div className="space-y-2">
                                        <p className="text-sm">Smith v. Jones (Lead)</p>
                                        <p className="text-sm">ABC Corp Litigation (Support)</p>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                <DialogFooter className="flex space-x-2">
                                  <Button variant="outline">Edit Details</Button>
                                  <Button>Download Information</Button>
                                </DialogFooter>
                              </DialogContent>
                            </Dialog>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between border-t px-6 py-4">
              <div className="text-sm text-gray-500">
                Showing {filteredEmployees.length} of {employees.length} employees
              </div>
              <div className="space-x-2">
                <Button variant="outline" size="sm" disabled>Previous</Button>
                <Button variant="outline" size="sm" disabled>Next</Button>
              </div>
            </CardFooter>
          </Card>
          
          <div className="grid gap-6 md:grid-cols-2 mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Briefcase className="h-5 w-5 mr-2" />
                  <span>Department Overview</span>
                </CardTitle>
                <CardDescription>Employee distribution by department</CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-4">
                  {[
                    { department: "Litigation", count: 8, percentage: 40 },
                    { department: "Corporate", count: 5, percentage: 25 },
                    { department: "Family Law", count: 3, percentage: 15 },
                    { department: "Real Estate", count: 2, percentage: 10 },
                    { department: "Administration", count: 2, percentage: 10 },
                  ].map((dept) => (
                    <div key={dept.department} className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span>{dept.department}</span>
                        <span className="text-gray-500">{dept.count} employees</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div
                          className="bg-navy h-2.5 rounded-full"
                          style={{ width: `${dept.percentage}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <UserCheck className="h-5 w-5 mr-2" />
                  <span>New Hires</span>
                </CardTitle>
                <CardDescription>Recently added employees</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {employees
                    .sort((a, b) => new Date(b.hireDate).getTime() - new Date(a.hireDate).getTime())
                    .slice(0, 3)
                    .map((employee) => (
                    <div key={employee.id} className="flex items-center space-x-3">
                      <Avatar className="h-10 w-10">
                        <AvatarFallback className="bg-navy text-white">
                          {employee.name.split(' ').map(n => n[0]).join('')}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <p className="font-medium">{employee.name}</p>
                        <p className="text-sm text-gray-500">{employee.position} • {employee.department}</p>
                      </div>
                      <div className="text-sm text-gray-500">
                        Joined {new Date(employee.hireDate).toLocaleDateString()}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
              <CardFooter className="border-t">
                <Button variant="ghost" className="w-full" size="sm">
                  View All Employees
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="payroll" className="mt-6">
          <Card>
            <CardHeader>
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                  <CardTitle>Payroll Management</CardTitle>
                  <CardDescription>
                    Process and manage employee compensation
                  </CardDescription>
                </div>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button className="bg-navy">
                      <DollarSign className="h-4 w-4 mr-2" />
                      Process Payroll
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Process Payroll</DialogTitle>
                      <DialogDescription>
                        Process payroll for the current period
                      </DialogDescription>
                    </DialogHeader>
                    <div className="py-4 space-y-4">
                      <div className="grid gap-2">
                        <label className="text-sm font-medium">Pay Period</label>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="grid gap-2">
                            <label className="text-xs text-gray-500">Start Date</label>
                            <Input type="date" defaultValue="2024-04-01" />
                          </div>
                          <div className="grid gap-2">
                            <label className="text-xs text-gray-500">End Date</label>
                            <Input type="date" defaultValue="2024-04-15" />
                          </div>
                        </div>
                      </div>
                      
                      <div className="grid gap-2">
                        <label className="text-sm font-medium">Payment Date</label>
                        <Input type="date" defaultValue="2024-04-20" />
                      </div>
                      
                      <div className="bg-gray-50 p-4 rounded-md space-y-2">
                        <h4 className="font-medium text-sm">Payroll Summary</h4>
                        <div className="flex justify-between text-sm">
                          <span>Total Employees</span>
                          <span>20</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Gross Pay</span>
                          <span>$78,125.00</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Deductions</span>
                          <span>$23,437.50</span>
                        </div>
                        <div className="flex justify-between text-sm font-medium pt-2 border-t">
                          <span>Net Pay</span>
                          <span>$54,687.50</span>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <input type="checkbox" id="confirmCheck" className="rounded border-gray-300" />
                        <label htmlFor="confirmCheck" className="text-sm">
                          I confirm that all time entries have been reviewed and approved
                        </label>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button type="submit" onClick={handleProcessPayroll}>
                        Process Now
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid gap-6 md:grid-cols-3">
                  <div className="flex flex-col p-6 bg-gray-50 rounded-lg">
                    <div className="flex items-center text-gray-500 mb-2">
                      <Calendar className="h-4 w-4 mr-2" />
                      <span className="text-sm">Current Pay Period</span>
                    </div>
                    <p className="font-medium">Apr 1 - Apr 15, 2024</p>
                    <p className="text-sm text-gray-500 mt-1">Payment Date: Apr 20</p>
                  </div>
                  
                  <div className="flex flex-col p-6 bg-gray-50 rounded-lg">
                    <div className="flex items-center text-gray-500 mb-2">
                      <DollarSign className="h-4 w-4 mr-2" />
                      <span className="text-sm">Total Payroll</span>
                    </div>
                    <p className="font-medium">$78,125.00</p>
                    <p className="text-sm text-gray-500 mt-1">20 Employees</p>
                  </div>
                  
                  <div className="flex flex-col p-6 bg-gray-50 rounded-lg">
                    <div className="flex items-center text-gray-500 mb-2">
                      <Clock className="h-4 w-4 mr-2" />
                      <span className="text-sm">Time Entry</span>
                    </div>
                    <p className="font-medium">18 Pending Approvals</p>
                    <Button variant="ghost" size="sm" className="-ml-3 mt-1">Review Now</Button>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium mb-4">Recent Payroll History</h3>
                  <div className="rounded-md border">
                    <div className="relative w-full overflow-auto">
                      <table className="w-full caption-bottom text-sm">
                        <thead>
                          <tr className="border-b bg-gray-50">
                            <th className="h-10 px-4 text-left font-medium text-gray-500">Pay Period</th>
                            <th className="h-10 px-4 text-left font-medium text-gray-500">Payment Date</th>
                            <th className="h-10 px-4 text-left font-medium text-gray-500">Employees</th>
                            <th className="h-10 px-4 text-left font-medium text-gray-500">Total Amount</th>
                            <th className="h-10 px-4 text-right font-medium text-gray-500">Status</th>
                            <th className="h-10 px-4 text-right font-medium text-gray-500">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {[
                            { period: "Mar 16 - Mar 31, 2024", date: "Apr 5, 2024", employees: 20, amount: "$78,125.00", status: "Completed" },
                            { period: "Mar 1 - Mar 15, 2024", date: "Mar 20, 2024", employees: 20, amount: "$78,125.00", status: "Completed" },
                            { period: "Feb 16 - Feb 29, 2024", date: "Mar 5, 2024", employees: 19, amount: "$75,250.00", status: "Completed" },
                          ].map((payroll, idx) => (
                            <tr key={idx} className="border-b hover:bg-gray-50">
                              <td className="p-4">{payroll.period}</td>
                              <td className="p-4">{payroll.date}</td>
                              <td className="p-4">{payroll.employees}</td>
                              <td className="p-4">{payroll.amount}</td>
                              <td className="p-4 text-right">
                                <Badge className="bg-green-600">
                                  {payroll.status}
                                </Badge>
                              </td>
                              <td className="p-4 text-right">
                                <Button variant="ghost" size="sm">View Details</Button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <div className="grid gap-6 md:grid-cols-2 mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BarChart className="h-5 w-5 mr-2" />
                  <span>Payroll Breakdown</span>
                </CardTitle>
                <CardDescription>Distribution by department</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { department: "Litigation", percentage: 42, amount: "$32,812.50" },
                    { department: "Corporate", percentage: 25, amount: "$19,531.25" },
                    { department: "Family Law", percentage: 18, amount: "$14,062.50" },
                    { department: "Other Departments", percentage: 15, amount: "$11,718.75" },
                  ].map((dept) => (
                    <div key={dept.department} className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span>{dept.department}</span>
                        <span className="text-gray-500">{dept.amount}</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div
                          className={`h-2.5 rounded-full ${
                            dept.department === "Litigation" ? "bg-navy" : 
                            dept.department === "Corporate" ? "bg-blue-500" : 
                            dept.department === "Family Law" ? "bg-green-500" : "bg-amber-500"
                          }`}
                          style={{ width: `${dept.percentage}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Tax Documents</CardTitle>
                <CardDescription>Annual tax forms and reports</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { title: "W-2 Forms (2023)", description: "Employee wage and tax statements", date: "Jan 31, 2024" },
                    { title: "1099 Forms (2023)", description: "Independent contractor payments", date: "Jan 31, 2024" },
                    { title: "Quarterly Tax Return Q1", description: "Form 941", date: "Apr 30, 2024" },
                  ].map((doc, idx) => (
                    <div key={idx} className="flex items-start space-x-3">
                      <div className="h-10 w-10 rounded-md bg-gray-100 flex items-center justify-center">
                        <FileText className="h-5 w-5 text-gray-500" />
                      </div>
                      <div className="flex-1">
                        <p className="font-medium">{doc.title}</p>
                        <p className="text-xs text-gray-500">{doc.description}</p>
                        <p className="text-xs text-gray-500 mt-1">Filed: {doc.date}</p>
                      </div>
                      <Button variant="ghost" size="sm">
                        <Download className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                  
                  <Button variant="outline" className="w-full">
                    View All Tax Documents
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="attendance" className="mt-6">
          <div className="grid gap-6 md:grid-cols-3">
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>Leave Requests</CardTitle>
                <CardDescription>
                  Manage employee time off requests
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="rounded-md border">
                  <div className="relative w-full overflow-auto">
                    <table className="w-full caption-bottom text-sm">
                      <thead>
                        <tr className="border-b bg-gray-50">
                          <th className="h-10 px-4 text-left font-medium text-gray-500">Employee</th>
                          <th className="h-10 px-4 text-left font-medium text-gray-500">Leave Type</th>
                          <th className="h-10 px-4 text-left font-medium text-gray-500">Date Range</th>
                          <th className="h-10 px-4 text-left font-medium text-gray-500">Duration</th>
                          <th className="h-10 px-4 text-left font-medium text-gray-500">Status</th>
                          <th className="h-10 px-4 text-right font-medium text-gray-500">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {leaveRequests.map((request) => {
                          const startDate = new Date(request.startDate);
                          const endDate = new Date(request.endDate);
                          const days = Math.round((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)) + 1;
                          
                          return (
                            <tr key={request.id} className="border-b hover:bg-gray-50">
                              <td className="p-4">
                                <div className="flex items-center">
                                  <Avatar className="h-8 w-8 mr-2">
                                    <AvatarFallback className="bg-navy text-white">
                                      {request.employeeName.split(' ').map(n => n[0]).join('')}
                                    </AvatarFallback>
                                  </Avatar>
                                  <span>{request.employeeName}</span>
                                </div>
                              </td>
                              <td className="p-4">{request.type}</td>
                              <td className="p-4">{new Date(request.startDate).toLocaleDateString()} - {new Date(request.endDate).toLocaleDateString()}</td>
                              <td className="p-4">{days} day{days !== 1 ? 's' : ''}</td>
                              <td className="p-4">
                                <Badge
                                  className={
                                    request.status === "approved" ? "bg-green-600" : 
                                    request.status === "rejected" ? "bg-red-600" : "bg-amber-500"
                                  }
                                >
                                  {request.status.charAt(0).toUpperCase() + request.status.slice(1)}
                                </Badge>
                              </td>
                              <td className="p-4 text-right">
                                {request.status === "pending" ? (
                                  <div className="flex justify-end space-x-2">
                                    <Button 
                                      size="sm" 
                                      variant="ghost" 
                                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                                      onClick={() => handleRejectLeave(request.id)}
                                    >
                                      <X className="h-4 w-4 mr-1" />
                                      Reject
                                    </Button>
                                    <Button
                                      size="sm" 
                                      variant="outline" 
                                      className="text-green-600 hover:text-green-700 hover:bg-green-50"
                                      onClick={() => handleApproveLeave(request.id)}
                                    >
                                      <Check className="h-4 w-4 mr-1" />
                                      Approve
                                    </Button>
                                  </div>
                                ) : (
                                  <Button variant="ghost" size="sm">View Details</Button>
                                )}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="border-t">
                <Button variant="outline" className="w-full">
                  View All Leave Requests
                </Button>
              </CardFooter>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Leave Balances</CardTitle>
                <CardDescription>
                  Employee time off availability
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-5">
                  {employees.map((employee) => (
                    <div key={employee.id} className="border-b pb-4 last:border-b-0 last:pb-0">
                      <div className="flex justify-between items-center mb-2">
                        <div className="flex items-center">
                          <Avatar className="h-6 w-6 mr-2">
                            <AvatarFallback className="bg-navy text-white text-xs">
                              {employee.name.split(' ').map(n => n[0]).join('')}
                            </AvatarFallback>
                          </Avatar>
                          <span className="font-medium text-sm">{employee.name}</span>
                        </div>
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button variant="ghost" size="sm" className="text-xs h-7">
                              Adjust
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="sm:max-w-[400px]">
                            <DialogHeader>
                              <DialogTitle>Adjust Leave Balance</DialogTitle>
                              <DialogDescription>
                                Update leave balances for {employee.name}
                              </DialogDescription>
                            </DialogHeader>
                            <div className="py-4 space-y-4">
                              <div className="grid gap-2">
                                <label className="text-sm font-medium">Vacation Days</label>
                                <Input type="number" defaultValue="12" />
                              </div>
                              <div className="grid gap-2">
                                <label className="text-sm font-medium">Sick Days</label>
                                <Input type="number" defaultValue="5" />
                              </div>
                              <div className="grid gap-2">
                                <label className="text-sm font-medium">Personal Days</label>
                                <Input type="number" defaultValue="3" />
                              </div>
                              <div className="grid gap-2">
                                <label className="text-sm font-medium">Reason for Adjustment</label>
                                <Input placeholder="Enter reason for adjustment" />
                              </div>
                            </div>
                            <DialogFooter>
                              <Button onClick={() => toast({
                                title: "Balance Updated",
                                description: `Leave balance for ${employee.name} has been updated`
                              })}>
                                Save Changes
                              </Button>
                            </DialogFooter>
                          </DialogContent>
                        </Dialog>
                      </div>
                      
                      <div className="grid grid-cols-3 gap-2 text-center text-xs">
                        <div className="bg-blue-50 p-2 rounded-md">
                          <p className="text-gray-500">Vacation</p>
                          <p className="font-medium text-sm">12 days</p>
                        </div>
                        <div className="bg-green-50 p-2 rounded-md">
                          <p className="text-gray-500">Sick</p>
                          <p className="font-medium text-sm">5 days</p>
                        </div>
                        <div className="bg-amber-50 p-2 rounded-md">
                          <p className="text-gray-500">Personal</p>
                          <p className="font-medium text-sm">3 days</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
          
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="flex items-center">
                <CalendarDays className="h-5 w-5 mr-2" />
                <span>Attendance Calendar</span>
              </CardTitle>
              <CardDescription>
                Employee attendance and time off overview
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <CalendarDays className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium">Attendance Calendar</h3>
                <p className="text-sm text-gray-500 mt-1 mb-4 max-w-md mx-auto">
                  The calendar view will show who is in the office and who is out each day, 
                  along with attendance patterns and time off scheduling.
                </p>
                <Button onClick={() => toast({
                  title: "Coming Soon",
                  description: "This feature will be available in the next update"
                })}>
                  View Calendar
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default HumanResources;
