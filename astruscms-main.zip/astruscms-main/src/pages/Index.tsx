
import { useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "@/context/auth-context";
import { Scale, CheckCircle, Shield, Calendar, FileText, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

const Index = () => {
  const navigate = useNavigate();
  const { user, isLoading } = useAuth();

  useEffect(() => {
    if (!isLoading && user) {
      navigate("/dashboard");
    }
  }, [user, navigate, isLoading]);

  const features = [
    {
      icon: <FileText className="h-10 w-10 text-navy" />,
      title: "Case Management",
      description: "Track and manage all your legal cases in one centralized location with powerful organization tools."
    },
    {
      icon: <Calendar className="h-10 w-10 text-navy" />,
      title: "Calendar & Scheduling",
      description: "Never miss a court date or client meeting with integrated calendar and automated reminders."
    },
    {
      icon: <CheckCircle className="h-10 w-10 text-navy" />,
      title: "Task Tracking",
      description: "Assign and monitor tasks with deadlines, priorities, and progress tracking for your entire team."
    },
    {
      icon: <Users className="h-10 w-10 text-navy" />,
      title: "Client Portal",
      description: "Provide clients with secure access to case updates, documents, and communication."
    },
    {
      icon: <Shield className="h-10 w-10 text-navy" />,
      title: "Secure Document Storage",
      description: "Store and organize case documents with enterprise-grade security and easy retrieval."
    },
    {
      icon: <Scale className="h-10 w-10 text-navy" />,
      title: "AI Legal Assistant",
      description: "Leverage AI to streamline legal research, draft documents, and analyze case information."
    },
  ];

  const testimonials = [
    {
      quote: "Astrus CMS has transformed how our firm manages cases. The efficiency gains have been remarkable.",
      author: "Sarah Johnson",
      role: "Senior Partner, Johnson & Associates"
    },
    {
      quote: "The AI assistant feature alone has saved our team countless hours on legal research and document preparation.",
      author: "Michael Rodriguez",
      role: "Managing Partner, Rodriguez Law Group"
    },
    {
      quote: "The most intuitive legal case management system we've ever used. Our entire staff was up and running in days.",
      author: "Rebecca Chen",
      role: "Litigation Director, Chen Legal Services"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100">
      {/* Hero Section */}
      <section className="relative pt-16 pb-20 md:pt-24 md:pb-32">
        <div className="absolute inset-0 bg-navy/5 z-0"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="flex flex-col md:flex-row items-center">
            <div className="w-full md:w-1/2 mb-10 md:mb-0">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-navy mb-6 leading-tight">
                Modern Legal Case Management for Today's Law Firms
              </h1>
              <p className="text-xl text-gray-700 mb-8 max-w-lg">
                Streamline your practice with our comprehensive legal case management system designed specifically for legal professionals.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                {isLoading ? (
                  <div className="h-12 w-40 bg-gray-200 animate-pulse rounded-lg"></div>
                ) : user ? (
                  <Button 
                    className="bg-navy hover:bg-navy/90 text-white py-3 px-8 rounded-lg text-lg font-semibold"
                    onClick={() => navigate("/dashboard")}
                  >
                    Go to Dashboard
                  </Button>
                ) : (
                  <>
                    <Button 
                      className="bg-navy hover:bg-navy/90 text-white py-3 px-8 rounded-lg text-lg font-semibold"
                      onClick={() => navigate("/login")}
                    >
                      Get Started
                    </Button>
                    <Button 
                      variant="outline" 
                      className="border-navy text-navy hover:bg-navy/10 py-3 px-8 rounded-lg text-lg font-semibold"
                      onClick={() => document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' })}
                    >
                      Learn More
                    </Button>
                  </>
                )}
              </div>
            </div>
            <div className="w-full md:w-1/2 flex justify-center md:justify-end">
              <div className="relative">
                <div className="absolute -top-6 -left-6 w-full h-full rounded-xl bg-navy/10 -z-10"></div>
                <div className="bg-white p-6 rounded-xl shadow-xl">
                  <div className="bg-navy text-white p-10 rounded-lg mb-6 text-center">
                    <Scale className="h-24 w-24 mx-auto mb-4" />
                    <h2 className="text-3xl font-bold">Astrus CMS</h2>
                    <p className="mt-2 opacity-90">Legal Case Management System</p>
                  </div>
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <CheckCircle className="h-5 w-5 text-green-500" />
                      <span>Streamlined case management</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <CheckCircle className="h-5 w-5 text-green-500" />
                      <span>AI-powered legal research</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <CheckCircle className="h-5 w-5 text-green-500" />
                      <span>Secure document storage</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <CheckCircle className="h-5 w-5 text-green-500" />
                      <span>Time & billing integration</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-navy mb-4">Powerful Features for Legal Professionals</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Astrus CMS offers a comprehensive suite of tools designed specifically for law firms and legal departments.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="border border-gray-200 hover:shadow-lg transition-shadow duration-300">
                <CardContent className="p-6">
                  <div className="bg-navy/5 rounded-full p-4 inline-block mb-4">
                    {feature.icon}
                  </div>
                  <h3 className="text-xl font-bold text-navy mb-2">{feature.title}</h3>
                  <p className="text-gray-600">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 bg-navy/5">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-navy mb-4">Trusted by Legal Professionals</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              See what law firms and legal departments are saying about Astrus CMS.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="border-0 shadow-lg">
                <CardContent className="p-8">
                  <div className="flex flex-col h-full">
                    <div className="mb-6 text-2xl text-navy/80">"</div>
                    <p className="text-lg mb-8 flex-grow italic text-gray-700">{testimonial.quote}</p>
                    <div>
                      <p className="font-bold text-navy">{testimonial.author}</p>
                      <p className="text-gray-500 text-sm">{testimonial.role}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-navy text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Transform Your Legal Practice?</h2>
          <p className="text-xl opacity-90 mb-8 max-w-2xl mx-auto">
            Join thousands of legal professionals who use Astrus CMS to streamline their case management.
          </p>
          <div className="flex justify-center gap-4">
            <Button 
              className="bg-white text-navy hover:bg-gray-100 py-3 px-8 rounded-lg text-lg font-semibold"
              onClick={() => navigate("/login")}
            >
              Get Started Today
            </Button>
            <Button 
              variant="outline"
              className="border-white text-white hover:bg-white/10 py-3 px-8 rounded-lg text-lg font-semibold"
            >
              Schedule a Demo
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="text-xl font-bold mb-4">Astrus CMS</h3>
              <p className="text-gray-300">
                Modern legal case management for today's law firms.
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Product</h4>
              <ul className="space-y-2">
                <li><Link to="/" className="text-gray-300 hover:text-white">Features</Link></li>
                <li><Link to="/" className="text-gray-300 hover:text-white">Pricing</Link></li>
                <li><Link to="/" className="text-gray-300 hover:text-white">Security</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Resources</h4>
              <ul className="space-y-2">
                <li><Link to="/" className="text-gray-300 hover:text-white">Blog</Link></li>
                <li><Link to="/" className="text-gray-300 hover:text-white">Documentation</Link></li>
                <li><Link to="/help" className="text-gray-300 hover:text-white">Support</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Company</h4>
              <ul className="space-y-2">
                <li><Link to="/" className="text-gray-300 hover:text-white">About Us</Link></li>
                <li><Link to="/" className="text-gray-300 hover:text-white">Contact</Link></li>
                <li><Link to="/" className="text-gray-300 hover:text-white">Careers</Link></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 mb-4 md:mb-0">
              &copy; 2025 Astrus Legal Technologies. All rights reserved.
            </p>
            <div className="flex space-x-4">
              <Link to="/terms-of-service" className="text-gray-400 hover:text-white">
                Terms of Service
              </Link>
              <Link to="/privacy-policy" className="text-gray-400 hover:text-white">
                Privacy Policy
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
