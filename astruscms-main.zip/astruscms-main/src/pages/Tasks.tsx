
import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { format, addDays, parseISO } from "date-fns";
import { cn } from "@/lib/utils";
import { toast } from "@/hooks/use-toast";
import { Calendar as CalendarIcon, Clock, Search, Filter, Plus, CheckCircle2, X, AlertCircle, CalendarClock, UserCircle2 } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";

// Mock data for tasks
const initialTasks = [
  {
    id: 1,
    title: "Review Johnson Contract",
    description: "Review and finalize contract terms before client meeting",
    dueDate: new Date(),
    priority: "high",
    status: "in-progress",
    case: "Johnson Divorce",
    assignedTo: "John Smith",
    completed: false,
    tags: ["contract", "review"]
  },
  {
    id: 2,
    title: "Prepare for Smith Hearing",
    description: "Review case documents and prepare arguments",
    dueDate: addDays(new Date(), 2),
    priority: "high",
    status: "not-started",
    case: "Smith v. Davis",
    assignedTo: "Jane Doe",
    completed: false,
    tags: ["hearing", "preparation"]
  },
  {
    id: 3,
    title: "File Brown Estate Documents",
    description: "Submit estate planning documents to court",
    dueDate: addDays(new Date(), 5),
    priority: "medium",
    status: "in-progress",
    case: "Brown Estate",
    assignedTo: "John Smith",
    completed: false,
    tags: ["filing", "estate"]
  },
  {
    id: 4,
    title: "Client Follow-up Call",
    description: "Call Mr. Wilson to discuss case progress",
    dueDate: addDays(new Date(), -1),
    priority: "low",
    status: "in-progress",
    case: "Wilson Appeal",
    assignedTo: "Sarah Johnson",
    completed: true,
    tags: ["call", "follow-up"]
  }
];

const TasksPage = () => {
  const [tasks, setTasks] = useState(initialTasks);
  const [searchTerm, setSearchTerm] = useState("");
  const [newTask, setNewTask] = useState({
    title: "",
    description: "",
    dueDate: new Date(),
    priority: "medium",
    status: "not-started",
    case: "",
    assignedTo: "",
    completed: false,
    tags: ""
  });
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  
  const handleAddTask = () => {
    const createdTask = {
      ...newTask,
      id: tasks.length + 1,
      tags: newTask.tags ? newTask.tags.split(',').map(tag => tag.trim()) : [],
      completed: false
    };
    
    setTasks([...tasks, createdTask]);
    setIsDialogOpen(false);
    
    toast({
      title: "Task Created",
      description: `${createdTask.title} has been added to your tasks.`,
      duration: 3000,
    });

    // Reset form fields
    setNewTask({
      title: "",
      description: "",
      dueDate: new Date(),
      priority: "medium",
      status: "not-started",
      case: "",
      assignedTo: "",
      completed: false,
      tags: ""
    });
  };

  const toggleTaskCompletion = (taskId: number) => {
    setTasks(tasks.map(task => 
      task.id === taskId
        ? { ...task, completed: !task.completed, status: !task.completed ? "completed" : "in-progress" }
        : task
    ));
    
    const task = tasks.find(t => t.id === taskId);
    if (task) {
      toast({
        title: task.completed ? "Task Reopened" : "Task Completed",
        description: `"${task.title}" ${task.completed ? "has been reopened" : "marked as complete"}.`,
        duration: 3000,
      });
    }
  };

  const filteredTasks = tasks.filter(
    (task) =>
      task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      task.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      task.case.toLowerCase().includes(searchTerm.toLowerCase()) ||
      task.assignedTo.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getPriorityStyles = (priority: string) => {
    switch(priority) {
      case "high":
        return "bg-red-100 text-red-800 border-red-200";
      case "medium":
        return "bg-amber-100 text-amber-800 border-amber-200";
      case "low":
        return "bg-green-100 text-green-800 border-green-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getStatusStyles = (status: string) => {
    switch(status) {
      case "completed":
        return "bg-green-100 text-green-800 border-green-200";
      case "in-progress":
        return "bg-blue-100 text-blue-800 border-blue-200";
      case "not-started":
        return "bg-gray-100 text-gray-800 border-gray-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getDueDateStyles = (dueDate: Date) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const taskDate = new Date(dueDate);
    taskDate.setHours(0, 0, 0, 0);
    
    if (taskDate.getTime() < today.getTime()) {
      return "text-red-600";
    } else if (taskDate.getTime() === today.getTime()) {
      return "text-amber-600 font-medium";
    }
    return "text-gray-600";
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Tasks</h1>
          <p className="text-sm text-gray-500">
            Track and manage your case-related tasks
          </p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-navy hover:bg-navy/90">
              <Plus className="mr-2 h-4 w-4" />
              New Task
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[525px]">
            <DialogHeader>
              <DialogTitle>Add New Task</DialogTitle>
              <DialogDescription>
                Create a new task for your cases or general work.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="title">Task Title</Label>
                <Input 
                  id="title" 
                  value={newTask.title} 
                  onChange={(e) => setNewTask({...newTask, title: e.target.value})} 
                  placeholder="Enter task title"
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="description">Description</Label>
                <Textarea 
                  id="description" 
                  value={newTask.description} 
                  onChange={(e) => setNewTask({...newTask, description: e.target.value})} 
                  placeholder="Add details about this task"
                />
              </div>
              
              <div className="grid gap-2">
                <Label>Due Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant={"outline"}
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !newTask.dueDate && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {newTask.dueDate ? format(newTask.dueDate, "PPP") : "Select date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={newTask.dueDate}
                      onSelect={(date) => date && setNewTask({...newTask, dueDate: date})}
                      initialFocus
                      className="p-3 pointer-events-auto"
                    />
                  </PopoverContent>
                </Popover>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="priority">Priority</Label>
                  <Select 
                    value={newTask.priority}
                    onValueChange={(value) => setNewTask({...newTask, priority: value})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select priority" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="low">Low</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="grid gap-2">
                  <Label htmlFor="status">Status</Label>
                  <Select 
                    value={newTask.status}
                    onValueChange={(value) => setNewTask({...newTask, status: value})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="not-started">Not Started</SelectItem>
                      <SelectItem value="in-progress">In Progress</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="case">Related Case</Label>
                  <Input 
                    id="case" 
                    value={newTask.case} 
                    onChange={(e) => setNewTask({...newTask, case: e.target.value})} 
                    placeholder="Case name or ID"
                  />
                </div>
                
                <div className="grid gap-2">
                  <Label htmlFor="assignedTo">Assigned To</Label>
                  <Input 
                    id="assignedTo" 
                    value={newTask.assignedTo} 
                    onChange={(e) => setNewTask({...newTask, assignedTo: e.target.value})} 
                    placeholder="Team member name"
                  />
                </div>
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="tags">Tags</Label>
                <Input 
                  id="tags" 
                  value={newTask.tags} 
                  onChange={(e) => setNewTask({...newTask, tags: e.target.value})} 
                  placeholder="Comma-separated tags (e.g. urgent, filing, research)"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
              <Button onClick={handleAddTask} disabled={!newTask.title}>Create Task</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Tasks</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{tasks.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Completed</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{tasks.filter(task => task.completed).length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">In Progress</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{tasks.filter(task => task.status === "in-progress").length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">High Priority</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{tasks.filter(task => task.priority === "high").length}</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Task Management</CardTitle>
          <CardDescription>Create and track tasks related to your cases</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4 mb-4 items-start md:items-center justify-between">
            <div className="relative w-full md:w-96">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
              <Input 
                type="search" 
                placeholder="Search tasks..." 
                className="pl-8 w-full"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            <div className="flex gap-2">
              <Button variant="outline" size="sm" className="h-9">
                <Filter className="mr-2 h-4 w-4" />
                Filter
              </Button>
            </div>
          </div>

          <Tabs defaultValue="all" className="w-full">
            <TabsList className="mb-4">
              <TabsTrigger value="all">All Tasks</TabsTrigger>
              <TabsTrigger value="in-progress">In Progress</TabsTrigger>
              <TabsTrigger value="completed">Completed</TabsTrigger>
              <TabsTrigger value="overdue">Overdue</TabsTrigger>
            </TabsList>
            <TabsContent value="all" className="space-y-4">
              {filteredTasks.length > 0 ? (
                filteredTasks.map((task) => (
                  <Card key={task.id} className={cn("overflow-hidden", task.completed ? "bg-gray-50" : "")}>
                    <CardHeader className="p-4 pb-0">
                      <div className="flex justify-between items-start">
                        <div className="flex items-start gap-2">
                          <Checkbox 
                            checked={task.completed}
                            onCheckedChange={() => toggleTaskCompletion(task.id)}
                            className="mt-1"
                          />
                          <div>
                            <CardTitle className={cn("text-lg", task.completed ? "line-through text-gray-500" : "")}>
                              {task.title}
                            </CardTitle>
                            <CardDescription>
                              {task.case && <span>Case: {task.case}</span>}
                            </CardDescription>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Badge variant="outline" className={getPriorityStyles(task.priority)}>
                            {task.priority}
                          </Badge>
                          <Badge variant="outline" className={getStatusStyles(task.status)}>
                            {task.status.replace('-', ' ')}
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="p-4 pt-2">
                      <p className={cn("text-sm mb-3", task.completed ? "text-gray-400" : "text-gray-700")}>
                        {task.description}
                      </p>
                      
                      <div className="flex flex-wrap gap-1 mb-3">
                        {task.tags && task.tags.map((tag, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                      
                      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 text-xs text-gray-500">
                        <div className={cn("flex items-center gap-1", getDueDateStyles(task.dueDate))}>
                          <CalendarClock className="h-3 w-3" />
                          <span>Due: {format(new Date(task.dueDate), "MMM d, yyyy")}</span>
                        </div>
                        
                        {task.assignedTo && (
                          <div className="flex items-center gap-1">
                            <UserCircle2 className="h-3 w-3" />
                            <span>Assigned to: {task.assignedTo}</span>
                          </div>
                        )}
                      </div>
                    </CardContent>
                    <CardFooter className="p-2 bg-gray-50 flex justify-end gap-2 border-t">
                      <Button variant="outline" size="sm">
                        Edit
                      </Button>
                      {!task.completed ? (
                        <Button size="sm" className="bg-green-600 hover:bg-green-700" onClick={() => toggleTaskCompletion(task.id)}>
                          <CheckCircle2 className="h-3 w-3 mr-1" /> Complete
                        </Button>
                      ) : (
                        <Button size="sm" variant="outline" onClick={() => toggleTaskCompletion(task.id)}>
                          <X className="h-3 w-3 mr-1" /> Reopen
                        </Button>
                      )}
                    </CardFooter>
                  </Card>
                ))
              ) : (
                <div className="text-center py-10">
                  <CheckCircle2 className="h-12 w-12 mx-auto text-gray-300 mb-3" />
                  <h3 className="text-lg font-medium text-gray-900">No Tasks Found</h3>
                  <p className="text-gray-500 mt-1 mb-3">
                    {searchTerm ? "Try adjusting your search" : "You don't have any tasks yet"}
                  </p>
                  <Button onClick={() => setIsDialogOpen(true)} className="mx-auto">
                    <Plus className="h-4 w-4 mr-2" /> Create Your First Task
                  </Button>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="in-progress" className="space-y-4">
              {filteredTasks.filter(t => t.status === "in-progress").length > 0 ? (
                filteredTasks.filter(t => t.status === "in-progress").map((task) => (
                  <Card key={task.id} className="overflow-hidden">
                    {/* Same card content as above */}
                  </Card>
                ))
              ) : (
                <div className="text-center py-10">
                  <AlertCircle className="h-12 w-12 mx-auto text-gray-300 mb-3" />
                  <h3 className="text-lg font-medium text-gray-900">No In-Progress Tasks</h3>
                  <p className="text-gray-500 mt-1">
                    You don't have any tasks in progress
                  </p>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="completed" className="space-y-4">
              {filteredTasks.filter(t => t.completed).length > 0 ? (
                filteredTasks.filter(t => t.completed).map((task) => (
                  <Card key={task.id} className="overflow-hidden bg-gray-50">
                    {/* Same card content as above */}
                  </Card>
                ))
              ) : (
                <div className="text-center py-10">
                  <CheckCircle2 className="h-12 w-12 mx-auto text-gray-300 mb-3" />
                  <h3 className="text-lg font-medium text-gray-900">No Completed Tasks</h3>
                  <p className="text-gray-500 mt-1">
                    You haven't completed any tasks yet
                  </p>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="overdue" className="space-y-4">
              {filteredTasks.filter(t => new Date(t.dueDate) < new Date() && !t.completed).length > 0 ? (
                filteredTasks.filter(t => new Date(t.dueDate) < new Date() && !t.completed).map((task) => (
                  <Card key={task.id} className="overflow-hidden border-l-4 border-l-red-500">
                    {/* Same card content as above */}
                  </Card>
                ))
              ) : (
                <div className="text-center py-10">
                  <AlertCircle className="h-12 w-12 mx-auto text-gray-300 mb-3" />
                  <h3 className="text-lg font-medium text-gray-900">No Overdue Tasks</h3>
                  <p className="text-gray-500 mt-1">
                    You don't have any overdue tasks
                  </p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default TasksPage;
