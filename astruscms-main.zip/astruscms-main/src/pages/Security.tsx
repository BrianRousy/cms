import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Avatar,
  AvatarFallback,
  AvatarImage,
} from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";
import {
  Shield,
  User,
  Users,
  Lock,
  FileText,
  Settings,
  Key,
  Eye,
  MoreHorizontal,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  UserPlus,
  Edit,
  Trash2,
  UserCheck,
  LogIn
} from "lucide-react";

// Mock user data
const mockUsers = [
  {
    id: 1,
    name: "John Smith",
    email: "john@astrus-cms.com",
    role: "Administrator",
    status: "active",
    lastLogin: "2024-04-12 09:15 AM",
    twoFactorEnabled: true,
  },
  {
    id: 2,
    name: "Sarah Johnson",
    email: "sarah@astrus-cms.com",
    role: "Legal Partner",
    status: "active",
    lastLogin: "2024-04-12 08:30 AM",
    twoFactorEnabled: true,
  },
  {
    id: 3,
    name: "Michael Williams",
    email: "michael@astrus-cms.com",
    role: "Associate",
    status: "active",
    lastLogin: "2024-04-11 04:22 PM",
    twoFactorEnabled: false,
  },
  {
    id: 4,
    name: "Emily Davis",
    email: "emily@astrus-cms.com",
    role: "Paralegal",
    status: "active",
    lastLogin: "2024-04-10 02:45 PM",
    twoFactorEnabled: true,
  },
  {
    id: 5,
    name: "Robert Brown",
    email: "robert@astrus-cms.com",
    role: "IT Manager",
    status: "inactive",
    lastLogin: "2024-03-28 10:30 AM",
    twoFactorEnabled: true,
  },
  {
    id: 6,
    name: "Jennifer Wilson",
    email: "jennifer@astrus-cms.com",
    role: "Office Manager",
    status: "active",
    lastLogin: "2024-04-11 09:05 AM",
    twoFactorEnabled: false,
  },
];

// Mock roles with permissions
const roles = [
  {
    id: 1,
    name: "Administrator",
    description: "Full access to all features and settings",
    userCount: 2,
    permissions: {
      cases: "full",
      documents: "full",
      billing: "full",
      reports: "full",
      settings: "full",
      users: "full",
    }
  },
  {
    id: 2,
    name: "Legal Partner",
    description: "Access to all cases and billing features",
    userCount: 4,
    permissions: {
      cases: "full",
      documents: "full",
      billing: "full",
      reports: "view",
      settings: "none",
      users: "none",
    }
  },
  {
    id: 3,
    name: "Associate",
    description: "Access to assigned cases and documents",
    userCount: 6,
    permissions: {
      cases: "assigned",
      documents: "assigned",
      billing: "view",
      reports: "view",
      settings: "none",
      users: "none",
    }
  },
  {
    id: 4,
    name: "Paralegal",
    description: "Limited access to cases and documents",
    userCount: 5,
    permissions: {
      cases: "assigned",
      documents: "assigned",
      billing: "none",
      reports: "none",
      settings: "none",
      users: "none",
    }
  },
  {
    id: 5,
    name: "Office Manager",
    description: "Admin access except for cases",
    userCount: 2,
    permissions: {
      cases: "view",
      documents: "view",
      billing: "full",
      reports: "view",
      settings: "view",
      users: "view",
    }
  },
];

// Mock audit logs
const auditLogs = [
  {
    id: 1,
    action: "User Login",
    user: "John Smith",
    timestamp: "2024-04-12 09:15:22",
    ipAddress: "192.168.1.105",
    details: "Successful login",
    status: "success"
  },
  {
    id: 2,
    action: "Create Document",
    user: "Sarah Johnson",
    timestamp: "2024-04-12 08:42:15",
    ipAddress: "192.168.1.110",
    details: "Created document: Motion to Dismiss.docx",
    status: "success"
  },
  {
    id: 3,
    action: "Update Case",
    user: "Michael Williams",
    timestamp: "2024-04-11 16:22:48",
    ipAddress: "192.168.1.115",
    details: "Updated case #1234: Changed status to In Progress",
    status: "success"
  },
  {
    id: 4,
    action: "Failed Login",
    user: "Unknown",
    timestamp: "2024-04-11 14:05:33",
    ipAddress: "202.45.67.89",
    details: "Failed login attempt for user: robert@astrus-cms.com",
    status: "error"
  },
  {
    id: 5,
    action: "Access Denied",
    user: "Emily Davis",
    timestamp: "2024-04-10 15:33:12",
    ipAddress: "192.168.1.120",
    details: "Attempted to access restricted billing report",
    status: "warning"
  },
  {
    id: 6,
    action: "Password Reset",
    user: "System",
    timestamp: "2024-04-10 11:15:08",
    ipAddress: "192.168.1.1",
    details: "Password reset link sent to jennifer@astrus-cms.com",
    status: "success"
  },
  {
    id: 7,
    action: "User Added",
    user: "John Smith",
    timestamp: "2024-04-09 10:22:45",
    ipAddress: "192.168.1.105",
    details: "Added new user: alex@astrus-cms.com",
    status: "success"
  },
  {
    id: 8,
    action: "Permission Changed",
    user: "John Smith",
    timestamp: "2024-04-08 14:55:22",
    ipAddress: "192.168.1.105",
    details: "Modified permissions for role: Associate",
    status: "success"
  },
];

const Security = () => {
  const { toast } = useToast();
  const [showAddUserDialog, setShowAddUserDialog] = useState(false);
  const [securitySettings, setSecuritySettings] = useState({
    passwordPolicy: "strong",
    passwordExpiry: "90",
    failedAttempts: "5",
    sessionTimeout: "30",
    twoFactorAuth: "optional",
    ipRestriction: false,
    allowedIPs: "",
    mfaForSensitive: true,
    auditLogging: true,
  });

  const [pendingApproval, setPendingApproval] = useState([
    {
      id: 1,
      name: "Alex Thompson",
      email: "alex@example.com",
      role: "Associate",
      requestDate: "2024-04-11"
    },
    {
      id: 2,
      name: "Lisa Chen",
      email: "lisa@example.com",
      role: "Paralegal",
      requestDate: "2024-04-10"
    }
  ]);

  const handleSaveSecuritySettings = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Security Settings Updated",
      description: "Your security settings have been updated successfully.",
    });
  };

  const handleAddUser = () => {
    setShowAddUserDialog(false);
    toast({
      title: "User Added",
      description: "The new user has been added successfully.",
    });
  };

  const handleApproveUser = (id: number) => {
    setPendingApproval(pendingApproval.filter(user => user.id !== id));
    toast({
      title: "User Approved",
      description: "The user account has been approved.",
    });
  };

  const handleRejectUser = (id: number) => {
    setPendingApproval(pendingApproval.filter(user => user.id !== id));
    toast({
      title: "User Rejected",
      description: "The user account request has been rejected.",
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Security & Access</h1>
          <p className="text-sm text-gray-500">Manage users, roles, and security settings</p>
        </div>
        <Button className="bg-navy hover:bg-navy/90" onClick={() => setShowAddUserDialog(true)}>
          <UserPlus className="mr-2 h-4 w-4" />
          Add User
        </Button>
      </div>

      <Tabs defaultValue="users">
        <TabsList>
          <TabsTrigger value="users" className="flex items-center gap-1">
            <Users className="h-4 w-4" />
            Users
          </TabsTrigger>
          <TabsTrigger value="roles" className="flex items-center gap-1">
            <Shield className="h-4 w-4" />
            Roles & Permissions
          </TabsTrigger>
          <TabsTrigger value="settings" className="flex items-center gap-1">
            <Settings className="h-4 w-4" />
            Security Settings
          </TabsTrigger>
          <TabsTrigger value="audit" className="flex items-center gap-1">
            <FileText className="h-4 w-4" />
            Audit Logs
          </TabsTrigger>
        </TabsList>

        <TabsContent value="users" className="space-y-4 pt-4">
          {pendingApproval.length > 0 && (
            <Card className="border-amber-200 bg-amber-50">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Pending Approval</CardTitle>
                <CardDescription>Users waiting for account approval</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {pendingApproval.map(user => (
                    <div key={user.id} className="flex items-center justify-between p-2 bg-white rounded-md shadow-sm">
                      <div className="flex items-center gap-3">
                        <Avatar>
                          <AvatarFallback className="bg-navy text-white">
                            {user.name.split(' ').map(n => n[0]).join('')}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{user.name}</p>
                          <p className="text-sm text-gray-500">{user.email} • {user.role}</p>
                          <p className="text-xs text-gray-400">Requested on {new Date(user.requestDate).toLocaleDateString()}</p>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" className="text-green-600" onClick={() => handleApproveUser(user.id)}>
                          <CheckCircle2 className="h-4 w-4 mr-1" />
                          Approve
                        </Button>
                        <Button variant="outline" size="sm" className="text-red-600" onClick={() => handleRejectUser(user.id)}>
                          <XCircle className="h-4 w-4 mr-1" />
                          Reject
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-navy" />
                  <CardTitle>User Management</CardTitle>
                </div>
                <Input
                  placeholder="Search users..."
                  className="max-w-xs"
                />
              </div>
              <CardDescription>Manage user accounts and access levels</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>User</TableHead>
                      <TableHead>Role</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>2FA</TableHead>
                      <TableHead>Last Login</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {mockUsers.map((user) => (
                      <TableRow key={user.id} className={user.status === 'inactive' ? 'bg-gray-50' : ''}>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <Avatar>
                              <AvatarImage src={`/placeholder.svg`} alt={user.name} />
                              <AvatarFallback className="bg-navy text-white">
                                {user.name.split(' ').map(n => n[0]).join('')}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="font-medium">{user.name}</p>
                              <p className="text-sm text-gray-500">{user.email}</p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant={user.role === "Administrator" ? "default" : "outline"}>
                            {user.role}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant="outline"
                            className={
                              user.status === 'active'
                                ? 'bg-green-50 text-green-600 border-green-200'
                                : 'bg-gray-50 text-gray-600 border-gray-200'
                            }
                          >
                            {user.status === 'active' ? 'Active' : 'Inactive'}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {user.twoFactorEnabled ? (
                            <CheckCircle2 className="h-5 w-5 text-green-500" />
                          ) : (
                            <XCircle className="h-5 w-5 text-amber-500" />
                          )}
                        </TableCell>
                        <TableCell>
                          {user.lastLogin}
                        </TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-4 w-4" />
                                <span className="sr-only">Actions</span>
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem>
                                <Edit className="mr-2 h-4 w-4" />
                                Edit User
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Key className="mr-2 h-4 w-4" />
                                Reset Password
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                {user.status === 'active' ? (
                                  <>
                                    <XCircle className="mr-2 h-4 w-4" />
                                    Deactivate User
                                  </>
                                ) : (
                                  <>
                                    <CheckCircle2 className="mr-2 h-4 w-4" />
                                    Activate User
                                  </>
                                )}
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem className="text-red-600">
                                <Trash2 className="mr-2 h-4 w-4" />
                                Delete User
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <div className="text-sm text-gray-500">
                Showing {mockUsers.length} of {mockUsers.length} users
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" disabled>
                  Previous
                </Button>
                <Button variant="outline" size="sm" disabled>
                  Next
                </Button>
              </div>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="roles" className="space-y-4 pt-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-navy" />
                  <CardTitle>Roles & Permissions</CardTitle>
                </div>
                <Button variant="outline">
                  Create Role
                </Button>
              </div>
              <CardDescription>Configure access levels and permissions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {roles.map((role) => (
                  <Card key={role.id} className="hover:shadow-sm transition-shadow">
                    <CardHeader className="pb-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <h3 className="text-lg font-medium">{role.name}</h3>
                          <Badge variant="outline" className="ml-2">{role.userCount} users</Badge>
                        </div>
                        <div className="flex gap-2">
                          <Button variant="ghost" size="sm">Edit</Button>
                          <Button variant="ghost" size="sm" className="text-red-600">Delete</Button>
                        </div>
                      </div>
                      <p className="text-sm text-gray-500">{role.description}</p>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                        <div className="space-y-1">
                          <p className="text-xs font-medium">Cases</p>
                          <Badge 
                            variant="outline"
                            className={
                              role.permissions.cases === 'full' 
                                ? 'bg-green-50 text-green-600 border-green-200' 
                                : role.permissions.cases === 'assigned'
                                ? 'bg-amber-50 text-amber-600 border-amber-200'
                                : role.permissions.cases === 'view'
                                ? 'bg-blue-50 text-blue-600 border-blue-200'
                                : 'bg-gray-50 text-gray-600 border-gray-200'
                            }
                          >
                            {role.permissions.cases === 'full' 
                              ? 'Full Access' 
                              : role.permissions.cases === 'assigned'
                              ? 'Assigned Only'
                              : role.permissions.cases === 'view'
                              ? 'View Only'
                              : 'No Access'}
                          </Badge>
                        </div>
                        <div className="space-y-1">
                          <p className="text-xs font-medium">Documents</p>
                          <Badge 
                            variant="outline"
                            className={
                              role.permissions.documents === 'full' 
                                ? 'bg-green-50 text-green-600 border-green-200' 
                                : role.permissions.documents === 'assigned'
                                ? 'bg-amber-50 text-amber-600 border-amber-200'
                                : role.permissions.documents === 'view'
                                ? 'bg-blue-50 text-blue-600 border-blue-200'
                                : 'bg-gray-50 text-gray-600 border-gray-200'
                            }
                          >
                            {role.permissions.documents === 'full' 
                              ? 'Full Access' 
                              : role.permissions.documents === 'assigned'
                              ? 'Assigned Only'
                              : role.permissions.documents === 'view'
                              ? 'View Only'
                              : 'No Access'}
                          </Badge>
                        </div>
                        <div className="space-y-1">
                          <p className="text-xs font-medium">Billing</p>
                          <Badge 
                            variant="outline"
                            className={
                              role.permissions.billing === 'full' 
                                ? 'bg-green-50 text-green-600 border-green-200' 
                                : role.permissions.billing === 'view'
                                ? 'bg-blue-50 text-blue-600 border-blue-200'
                                : 'bg-gray-50 text-gray-600 border-gray-200'
                            }
                          >
                            {role.permissions.billing === 'full' 
                              ? 'Full Access' 
                              : role.permissions.billing === 'view'
                              ? 'View Only'
                              : 'No Access'}
                          </Badge>
                        </div>
                        <div className="space-y-1">
                          <p className="text-xs font-medium">Reports</p>
                          <Badge 
                            variant="outline"
                            className={
                              role.permissions.reports === 'full' 
                                ? 'bg-green-50 text-green-600 border-green-200' 
                                : role.permissions.reports === 'view'
                                ? 'bg-blue-50 text-blue-600 border-blue-200'
                                : 'bg-gray-50 text-gray-600 border-gray-200'
                            }
                          >
                            {role.permissions.reports === 'full' 
                              ? 'Full Access' 
                              : role.permissions.reports === 'view'
                              ? 'View Only'
                              : 'No Access'}
                          </Badge>
                        </div>
                        <div className="space-y-1">
                          <p className="text-xs font-medium">Settings</p>
                          <Badge 
                            variant="outline"
                            className={
                              role.permissions.settings === 'full' 
                                ? 'bg-green-50 text-green-600 border-green-200' 
                                : role.permissions.settings === 'view'
                                ? 'bg-blue-50 text-blue-600 border-blue-200'
                                : 'bg-gray-50 text-gray-600 border-gray-200'
                            }
                          >
                            {role.permissions.settings === 'full' 
                              ? 'Full Access' 
                              : role.permissions.settings === 'view'
                              ? 'View Only'
                              : 'No Access'}
                          </Badge>
                        </div>
                        <div className="space-y-1">
                          <p className="text-xs font-medium">Users</p>
                          <Badge 
                            variant="outline"
                            className={
                              role.permissions.users === 'full' 
                                ? 'bg-green-50 text-green-600 border-green-200' 
                                : role.permissions.users === 'view'
                                ? 'bg-blue-50 text-blue-600 border-blue-200'
                                : 'bg-gray-50 text-gray-600 border-gray-200'
                            }
                          >
                            {role.permissions.users === 'full' 
                              ? 'Full Access' 
                              : role.permissions.users === 'view'
                              ? 'View Only'
                              : 'No Access'}
                          </Badge>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-4 pt-4">
          <Card>
            <form onSubmit={handleSaveSecuritySettings}>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Lock className="h-5 w-5 text-navy" />
                  <CardTitle>Security Settings</CardTitle>
                </div>
                <CardDescription>Configure system-wide security policies</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Password Policies</h3>
                  
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="passwordPolicy">Password Complexity</Label>
                      <Select 
                        value={securitySettings.passwordPolicy} 
                        onValueChange={(value) => setSecuritySettings({...securitySettings, passwordPolicy: value})}
                      >
                        <SelectTrigger id="passwordPolicy">
                          <SelectValue placeholder="Select password policy" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="basic">Basic (8+ characters)</SelectItem>
                          <SelectItem value="medium">Medium (8+ chars with numbers)</SelectItem>
                          <SelectItem value="strong">Strong (8+ chars with numbers, symbols)</SelectItem>
                          <SelectItem value="very-strong">Very Strong (12+ chars with numbers, symbols, mixed case)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="passwordExpiry">Password Expiration (Days)</Label>
                      <Input 
                        id="passwordExpiry" 
                        type="number" 
                        value={securitySettings.passwordExpiry}
                        onChange={(e) => setSecuritySettings({...securitySettings, passwordExpiry: e.target.value})}
                      />
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Access Controls</h3>
                  
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="failedAttempts">Max Failed Login Attempts</Label>
                      <Input 
                        id="failedAttempts" 
                        type="number" 
                        value={securitySettings.failedAttempts}
                        onChange={(e) => setSecuritySettings({...securitySettings, failedAttempts: e.target.value})}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="sessionTimeout">Session Timeout (Minutes)</Label>
                      <Input 
                        id="sessionTimeout" 
                        type="number"
                        value={securitySettings.sessionTimeout}
                        onChange={(e) => setSecuritySettings({...securitySettings, sessionTimeout: e.target.value})}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="twoFactorAuth">Two-Factor Authentication</Label>
                      <Select 
                        value={securitySettings.twoFactorAuth}
                        onValueChange={(value) => setSecuritySettings({...securitySettings, twoFactorAuth: value})}
                      >
                        <SelectTrigger id="twoFactorAuth">
                          <SelectValue placeholder="Select 2FA policy" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="disabled">Disabled</SelectItem>
                          <SelectItem value="optional">Optional</SelectItem>
                          <SelectItem value="required">Required for All Users</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="mfaForSensitive" className="text-base font-medium">MFA for Sensitive Operations</Label>
                        <p className="text-sm text-gray-500">Require MFA for sensitive actions like payments</p>
                      </div>
                      <Switch 
                        id="mfaForSensitive" 
                        checked={securitySettings.mfaForSensitive}
                        onCheckedChange={(checked) => setSecuritySettings({...securitySettings, mfaForSensitive: checked})}
                      />
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Network Security</h3>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="ipRestriction" className="text-base font-medium">IP Address Restriction</Label>
                      <p className="text-sm text-gray-500">Allow access only from specific IP addresses</p>
                    </div>
                    <Switch 
                      id="ipRestriction" 
                      checked={securitySettings.ipRestriction}
                      onCheckedChange={(checked) => setSecuritySettings({...securitySettings, ipRestriction: checked})}
                    />
                  </div>
                  
                  {securitySettings.ipRestriction && (
                    <div className="space-y-2">
                      <Label htmlFor="allowedIPs">Allowed IP Addresses</Label>
                      <Input 
                        id="allowedIPs" 
                        placeholder="Enter comma-separated IP addresses"
                        value={securitySettings.allowedIPs}
                        onChange={(e) => setSecuritySettings({...securitySettings, allowedIPs: e.target.value})}
                      />
                      <p className="text-xs text-gray-500">Format: 192.168.1.1, 10.0.0.0/24</p>
                    </div>
                  )}
                </div>
                
                <Separator />
                
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Audit & Logging</h3>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="auditLogging" className="text-base font-medium">Enable Audit Logging</Label>
                      <p className="text-sm text-gray-500">Track all security-relevant user actions</p>
                    </div>
                    <Switch 
                      id="auditLogging" 
                      checked={securitySettings.auditLogging}
                      onCheckedChange={(checked) => setSecuritySettings({...securitySettings, auditLogging: checked})}
                    />
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button type="submit" className="bg-navy hover:bg-navy/90">Save Security Settings</Button>
              </CardFooter>
            </form>
          </Card>
        </TabsContent>

        <TabsContent value="audit" className="space-y-4 pt-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <FileText className="h-5 w-5 text-navy" />
                  <CardTitle>Audit Logs</CardTitle>
                </div>
                <div className="flex gap-2">
                  <Input 
                    placeholder="Search logs..." 
                    className="w-60"
                  />
                  <Button variant="outline">Export Logs</Button>
                </div>
              </div>
              <CardDescription>System-wide activity and security audit trail</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Action</TableHead>
                      <TableHead>User</TableHead>
                      <TableHead>Timestamp</TableHead>
                      <TableHead>IP Address</TableHead>
                      <TableHead>Details</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {auditLogs.map((log) => (
                      <TableRow key={log.id}>
                        <TableCell>{log.action}</TableCell>
                        <TableCell>{log.user}</TableCell>
                        <TableCell>{log.timestamp}</TableCell>
                        <TableCell>{log.ipAddress}</TableCell>
                        <TableCell className="max-w-xs truncate">{log.details}</TableCell>
                        <TableCell>
                          <Badge
                            className={
                              log.status === 'success'
                                ? 'bg-green-50 text-green-600 border-green-200'
                                : log.status === 'warning'
                                ? 'bg-amber-50 text-amber-600 border-amber-200'
                                : 'bg-red-50 text-red-600 border-red-200'
                            }
                            variant="outline"
                          >
                            {log.status === 'success'
                              ? <CheckCircle2 className="h-3 w-3 mr-1 inline" />
                              : log.status === 'warning'
                              ? <AlertTriangle className="h-3 w-3 mr-1 inline" />
                              : <XCircle className="h-3 w-3 mr-1 inline" />
                            }
                            {log.status}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <div className="text-sm text-gray-500">
                Showing {auditLogs.length} of 256 logs
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  Previous
                </Button>
                <Button variant="outline" size="sm">
                  Next
                </Button>
              </div>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Add User Dialog */}
      {showAddUserDialog && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <Card className="w-full max-w-md mx-4">
            <CardHeader>
              <CardTitle>Add New User</CardTitle>
              <CardDescription>Create a new user account</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name</Label>
                  <Input id="name" placeholder="Enter user's full name" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email Address</Label>
                  <Input id="email" type="email" placeholder="Enter user's email address" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="role">Role</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select role" />
                    </SelectTrigger>
                    <SelectContent>
                      {roles.map(role => (
                        <SelectItem key={role.id} value={role.name}>{role.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center space-x-2 pt-2">
                  <Checkbox id="sendWelcome" />
                  <Label htmlFor="sendWelcome">Send welcome email with password setup instructions</Label>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={() => setShowAddUserDialog(false)}>Cancel</Button>
              <Button className="bg-navy hover:bg-navy/90" onClick={handleAddUser}>Add User</Button>
            </CardFooter>
          </Card>
        </div>
      )}
    </div>
  );
};

export default Security;
