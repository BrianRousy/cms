
import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import {
  Search,
  Filter,
  PlusCircle,
  Clock,
  Calendar,
  User,
  BarChart3,
  Tag,
  FileText,
  Briefcase,
  MoreHorizontal,
  ArrowUpDown,
  Scale,
  Link,
  Star
} from "lucide-react";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel
} from "@/components/ui/dropdown-menu";
import { supabase } from "@/integrations/supabase/client";

// Mock case data
const mockCases = [
  {
    id: 1,
    name: "Smith v. Johnson",
    number: "CL-2023-001",
    status: "Active",
    practice_area: "Contract Litigation",
    client_name: "John Smith",
    attorney: "Michael Thompson",
    open_date: "2023-06-15",
    next_court_date: "2024-05-20",
    priority: "High",
    last_updated: "2024-04-01"
  },
  {
    id: 2,
    name: "Johnson Real Estate Holdings",
    number: "CL-2023-002",
    status: "Discovery",
    practice_area: "Real Estate",
    client_name: "Johnson LLC",
    attorney: "Sarah Williams",
    open_date: "2023-08-22",
    next_court_date: "2024-06-12",
    priority: "Medium",
    last_updated: "2024-04-05"
  },
  {
    id: 3,
    name: "Robertson Bankruptcy Proceeding",
    number: "BK-2023-045",
    status: "Filed",
    practice_area: "Bankruptcy",
    client_name: "James Robertson",
    attorney: "Michael Thompson",
    open_date: "2023-10-05",
    next_court_date: null,
    priority: "Low",
    last_updated: "2024-03-15"
  },
  {
    id: 4,
    name: "ABC Corp Merger Review",
    number: "CP-2024-010",
    status: "Review",
    practice_area: "Corporate",
    client_name: "ABC Corporation",
    attorney: "Jennifer Davis",
    open_date: "2024-01-10",
    next_court_date: null,
    priority: "High",
    last_updated: "2024-04-10"
  },
  {
    id: 5,
    name: "Estate of Williams",
    number: "PR-2023-089",
    status: "Pending",
    practice_area: "Estate Planning",
    client_name: "Williams Family",
    attorney: "Sarah Williams",
    open_date: "2023-07-18",
    next_court_date: "2024-05-05",
    priority: "Medium",
    last_updated: "2024-04-02"
  },
  {
    id: 6,
    name: "Carter v. City of Springfield",
    number: "CV-2022-156",
    status: "Appeal",
    practice_area: "Municipal Law",
    client_name: "Thomas Carter",
    attorney: "Jennifer Davis",
    open_date: "2022-11-30",
    next_court_date: "2024-07-15",
    priority: "High",
    last_updated: "2024-03-28"
  }
];

interface Case {
  id: number;
  name: string;
  number: string;
  status: string;
  practice_area: string;
  client_name: string;
  attorney: string;
  open_date: string;
  next_court_date: string | null;
  priority: string;
  last_updated: string;
}

const CaseStatusBadge = ({ status }: { status: string }) => {
  const statusStyles = {
    Active: "bg-green-100 text-green-800 border-green-200",
    Discovery: "bg-blue-100 text-blue-800 border-blue-200",
    Filed: "bg-purple-100 text-purple-800 border-purple-200",
    Review: "bg-yellow-100 text-yellow-800 border-yellow-200",
    Pending: "bg-orange-100 text-orange-800 border-orange-200",
    Appeal: "bg-red-100 text-red-800 border-red-200",
    Closed: "bg-gray-100 text-gray-800 border-gray-200"
  };

  const style = statusStyles[status as keyof typeof statusStyles] || "bg-gray-100 text-gray-800";

  return (
    <Badge className={`${style} rounded-full font-medium`} variant="outline">
      {status}
    </Badge>
  );
};

const PriorityBadge = ({ priority }: { priority: string }) => {
  const priorityStyles = {
    High: "bg-red-100 text-red-800 border-red-200",
    Medium: "bg-yellow-100 text-yellow-800 border-yellow-200",
    Low: "bg-green-100 text-green-800 border-green-200"
  };

  const style = priorityStyles[priority as keyof typeof priorityStyles] || "bg-gray-100 text-gray-800";

  return (
    <Badge className={`${style} rounded-full font-medium`} variant="outline">
      {priority}
    </Badge>
  );
};

const CaseCard = ({ caseItem }: { caseItem: Case }) => {
  const { toast } = useToast();

  const handleCaseAction = (action: string) => {
    toast({
      title: `Case ${action}`,
      description: `${caseItem.name} has been ${action.toLowerCase()}`
    });
  };

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-lg">{caseItem.name}</CardTitle>
            <CardDescription>{caseItem.number}</CardDescription>
          </div>
          <div className="flex items-center space-x-2">
            <CaseStatusBadge status={caseItem.status} />
            <PriorityBadge priority={caseItem.priority} />
          </div>
        </div>
      </CardHeader>
      <CardContent className="pb-4">
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div className="flex items-center gap-2">
            <Briefcase className="h-4 w-4 text-gray-500" />
            <span>{caseItem.practice_area}</span>
          </div>
          <div className="flex items-center gap-2">
            <User className="h-4 w-4 text-gray-500" />
            <span>{caseItem.client_name}</span>
          </div>
          <div className="flex items-center gap-2">
            <User className="h-4 w-4 text-gray-500" />
            <span>{caseItem.attorney}</span>
          </div>
          <div className="flex items-center gap-2">
            <Calendar className="h-4 w-4 text-gray-500" />
            <span>{new Date(caseItem.open_date).toLocaleDateString()}</span>
          </div>
          {caseItem.next_court_date && (
            <div className="flex items-center gap-2 col-span-2">
              <Calendar className="h-4 w-4 text-gray-500" />
              <span>Next Court Date: {new Date(caseItem.next_court_date).toLocaleDateString()}</span>
            </div>
          )}
          <div className="flex items-center gap-2 col-span-2">
            <Clock className="h-4 w-4 text-gray-500" />
            <span>Updated {new Date(caseItem.last_updated).toLocaleDateString()}</span>
          </div>
        </div>
      </CardContent>
      <CardFooter className="pt-0 pb-4 flex justify-between">
        <Button className="bg-navy hover:bg-navy/90" size="sm">
          <FileText className="mr-1 h-4 w-4" />
          View Details
        </Button>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="sm">
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => handleCaseAction("Updated")}>
              <FileText className="mr-2 h-4 w-4" />
              Edit Case
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleCaseAction("Archived")}>
              <FileText className="mr-2 h-4 w-4" />
              Archive Case
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => handleCaseAction("Shared")}>
              <Link className="mr-2 h-4 w-4" />
              Share Case
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleCaseAction("Added to Favorites")}>
              <Star className="mr-2 h-4 w-4" />
              Add to Favorites
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </CardFooter>
    </Card>
  );
};

const CaseDatabase = () => {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [practiceAreaFilter, setPracticeAreaFilter] = useState<string | undefined>(undefined);
  const [statusFilter, setStatusFilter] = useState<string | undefined>(undefined);
  const [cases, setCases] = useState<Case[]>(mockCases);

  // Get unique practice areas from cases
  const practiceAreas = Array.from(new Set(mockCases.map(c => c.practice_area)));
  
  // Get unique statuses from cases
  const statuses = Array.from(new Set(mockCases.map(c => c.status)));

  const handleAddCase = () => {
    toast({
      title: "New Case",
      description: "Form to create a new case would open here",
    });
  };

  // Filter cases based on search term and filters
  const filteredCases = cases.filter(c => {
    const matchesSearch = searchTerm === "" || 
                          c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          c.number.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          c.client_name.toLowerCase().includes(searchTerm.toLowerCase());
                          
    const matchesPracticeArea = !practiceAreaFilter || c.practice_area === practiceAreaFilter;
    const matchesStatus = !statusFilter || c.status === statusFilter;
    
    return matchesSearch && matchesPracticeArea && matchesStatus;
  });

  const clearFilters = () => {
    setSearchTerm("");
    setPracticeAreaFilter(undefined);
    setStatusFilter(undefined);
  };

  // Simulate fetching cases from Supabase
  const fetchCases = async () => {
    try {
      // In a real implementation, we would use Supabase to fetch cases
      // const { data, error } = await supabase
      //  .from('cases')
      //  .select('*')
      
      // For now, we'll just use our mock data
      setCases(mockCases);
    } catch (error) {
      console.error('Error fetching cases:', error);
      toast({
        title: "Error",
        description: "Could not fetch case data",
        variant: "destructive"
      });
    }
  };

  React.useEffect(() => {
    fetchCases();
  }, []);

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold">Case Database</h1>
          <p className="text-sm text-gray-500">Manage and track all your legal cases</p>
        </div>
        <Button 
          onClick={handleAddCase}
          className="bg-navy hover:bg-navy/90 w-full sm:w-auto"
        >
          <PlusCircle className="mr-2 h-4 w-4" />
          Add New Case
        </Button>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg">Search & Filter Cases</CardTitle>
            {(searchTerm || practiceAreaFilter || statusFilter) && (
              <Button 
                variant="link" 
                size="sm"
                onClick={clearFilters}
                className="h-auto p-0"
              >
                Clear All Filters
              </Button>
            )}
          </div>
          <CardDescription>Find cases by name, number, client, or status</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-4">
            <div className="relative md:col-span-2">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
              <Input
                placeholder="Search cases..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>
            
            <Select value={practiceAreaFilter} onValueChange={setPracticeAreaFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Practice Area" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Practice Areas</SelectItem>
                {practiceAreas.map(area => (
                  <SelectItem key={area} value={area}>{area}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Statuses</SelectItem>
                {statuses.map(status => (
                  <SelectItem key={status} value={status}>{status}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredCases.length > 0 ? (
          filteredCases.map(caseItem => (
            <CaseCard key={caseItem.id} caseItem={caseItem} />
          ))
        ) : (
          <div className="col-span-2 text-center py-12">
            <Briefcase className="mx-auto h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-medium">No cases found</h3>
            <p className="text-gray-500 mt-2">Try adjusting your search or filters</p>
            <Button 
              variant="outline" 
              className="mt-4"
              onClick={clearFilters}
            >
              Clear Filters
            </Button>
          </div>
        )}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-navy" />
            <span>Case Analytics</span>
          </CardTitle>
          <CardDescription>Overview of your case portfolio</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-gray-50 rounded-lg p-4">
              <h3 className="text-sm font-medium text-gray-500">By Status</h3>
              <div className="mt-3 space-y-2">
                <div className="flex justify-between items-center">
                  <span>Active</span>
                  <span className="font-medium">28%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-green-500 h-2 rounded-full" style={{ width: "28%" }}></div>
                </div>
                
                <div className="flex justify-between items-center">
                  <span>Discovery</span>
                  <span className="font-medium">45%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-blue-500 h-2 rounded-full" style={{ width: "45%" }}></div>
                </div>
                
                <div className="flex justify-between items-center">
                  <span>Appeal</span>
                  <span className="font-medium">15%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-red-500 h-2 rounded-full" style={{ width: "15%" }}></div>
                </div>
                
                <div className="flex justify-between items-center">
                  <span>Other</span>
                  <span className="font-medium">12%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-gray-500 h-2 rounded-full" style={{ width: "12%" }}></div>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-4">
              <h3 className="text-sm font-medium text-gray-500">By Practice Area</h3>
              <div className="mt-3 space-y-2">
                <div className="flex justify-between items-center">
                  <span>Contract Litigation</span>
                  <span className="font-medium">32%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-navy h-2 rounded-full" style={{ width: "32%" }}></div>
                </div>
                
                <div className="flex justify-between items-center">
                  <span>Real Estate</span>
                  <span className="font-medium">24%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-teal-500 h-2 rounded-full" style={{ width: "24%" }}></div>
                </div>
                
                <div className="flex justify-between items-center">
                  <span>Corporate</span>
                  <span className="font-medium">18%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-purple-500 h-2 rounded-full" style={{ width: "18%" }}></div>
                </div>
                
                <div className="flex justify-between items-center">
                  <span>Other</span>
                  <span className="font-medium">26%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-gray-500 h-2 rounded-full" style={{ width: "26%" }}></div>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-4">
              <h3 className="text-sm font-medium text-gray-500">Upcoming Deadlines</h3>
              <div className="mt-3 space-y-3">
                <div className="flex items-start gap-2">
                  <Calendar className="h-4 w-4 text-red-500 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="font-medium">Smith v. Johnson</p>
                    <p className="text-xs text-gray-500">Court Date: May 20, 2024</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-2">
                  <Calendar className="h-4 w-4 text-orange-500 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="font-medium">Estate of Williams</p>
                    <p className="text-xs text-gray-500">Filing Deadline: May 5, 2024</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-2">
                  <Calendar className="h-4 w-4 text-blue-500 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="font-medium">Johnson Real Estate</p>
                    <p className="text-xs text-gray-500">Discovery Due: June 12, 2024</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default CaseDatabase;
