
import React from "react";
import { ScrollArea } from "@/components/ui/scroll-area";
import Layout from "@/components/layout";
import { Separator } from "@/components/ui/separator";

const TermsOfService = () => {
  return (
    <Layout>
      <div className="container max-w-4xl mx-auto py-8 px-4">
        <h1 className="text-3xl font-bold text-navy mb-6">Terms of Service</h1>
        <Separator className="mb-6" />
        
        <ScrollArea className="h-[70vh]">
          <div className="space-y-6 pr-4">
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">1. Introduction</h2>
              <p className="text-gray-700">
                Welcome to Astrus CMS ("we," "our," or "us"). By accessing or using our legal case management system, you agree to be bound by these Terms of Service ("Terms"). Please read these Terms carefully before using the Service.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">2. Acceptance of Terms</h2>
              <p className="text-gray-700">
                By accessing or using our Service, you agree to be bound by these Terms and our Privacy Policy. If you do not agree to these Terms, you may not access or use the Service.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">3. Description of Service</h2>
              <p className="text-gray-700">
                Astrus CMS provides a comprehensive legal case management platform designed for law firms and legal professionals. The Service includes features such as case management, document management, client portal, calendar management, billing, and reporting tools.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">4. User Accounts</h2>
              <p className="text-gray-700 mb-3">
                To access certain features of the Service, you must create an account. You are responsible for:
              </p>
              <ul className="list-disc pl-6 space-y-2 text-gray-700">
                <li>Maintaining the confidentiality of your account credentials</li>
                <li>Restricting access to your account</li>
                <li>All activities that occur under your account</li>
                <li>Notifying us immediately of any unauthorized use of your account</li>
              </ul>
              <p className="text-gray-700 mt-3">
                We reserve the right to terminate accounts, remove or edit content, or cancel services at our sole discretion.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">5. User Content</h2>
              <p className="text-gray-700 mb-3">
                Our Service allows you to upload, store, and share content. You retain all rights to your content, and you are responsible for:
              </p>
              <ul className="list-disc pl-6 space-y-2 text-gray-700">
                <li>The accuracy, quality, integrity, legality, and appropriateness of your content</li>
                <li>Ensuring you have the right to upload and share content</li>
                <li>Backing up your content</li>
              </ul>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">6. Confidentiality and Data Security</h2>
              <p className="text-gray-700">
                We understand the sensitive nature of legal information and implement appropriate security measures to protect your data. However, no system can guarantee absolute security. You acknowledge that you provide your information at your own risk. We will handle all confidential information in accordance with applicable laws and professional standards.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">7. Intellectual Property Rights</h2>
              <p className="text-gray-700">
                The Service and its original content (excluding user content), features, and functionality are owned by Astrus Legal Technologies and are protected by copyright, trademark, and other intellectual property laws. You may not reproduce, distribute, modify, create derivative works of, publicly display, or exploit any part of our Service without our prior written consent.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">8. Payment Terms</h2>
              <p className="text-gray-700">
                Some aspects of our Service may require payment. By subscribing to a paid plan, you agree to pay all fees in accordance with the pricing and payment terms presented to you. Fees are non-refundable except as required by law or as explicitly stated in these Terms.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">9. Limitation of Liability</h2>
              <p className="text-gray-700">
                To the maximum extent permitted by law, Astrus Legal Technologies shall not be liable for any indirect, incidental, special, consequential, or punitive damages, including loss of profits, data, or business opportunities arising out of or related to your use of the Service.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">10. Changes to Terms</h2>
              <p className="text-gray-700">
                We reserve the right to modify these Terms at any time. We will provide notice of significant changes by posting the new Terms on our website or through the Service. Your continued use of the Service after changes constitutes your acceptance of the modified Terms.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">11. Governing Law</h2>
              <p className="text-gray-700">
                These Terms shall be governed by and construed in accordance with the laws of the jurisdiction in which our company is registered, without regard to its conflict of law provisions.
              </p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-navy mb-3">12. Contact Us</h2>
              <p className="text-gray-700">
                If you have any questions about these Terms, please contact us at legal@astruscms.com.
              </p>
            </section>
            
            <div className="mt-8 text-gray-500 text-sm">
              <p>Last Updated: April 13, 2025</p>
            </div>
          </div>
        </ScrollArea>
      </div>
    </Layout>
  );
};

export default TermsOfService;
