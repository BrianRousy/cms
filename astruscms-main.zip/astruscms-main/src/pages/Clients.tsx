
import React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Plus, Search, UserPlus, Users, Filter } from "lucide-react";

const Clients = () => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Client Management</h1>
        <Button className="bg-navy hover:bg-navy/90">
          <UserPlus className="mr-2 h-4 w-4" />
          Add New Client
        </Button>
      </div>

      <div className="flex items-center justify-between gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
          <Input
            type="search"
            placeholder="Search clients..."
            className="w-full pl-8"
          />
        </div>
        <Button variant="outline" className="shrink-0">
          <Filter className="mr-2 h-4 w-4" />
          Filters
        </Button>
      </div>

      <Tabs defaultValue="all">
        <TabsList>
          <TabsTrigger value="all">All Clients</TabsTrigger>
          <TabsTrigger value="active">Active</TabsTrigger>
          <TabsTrigger value="inactive">Inactive</TabsTrigger>
          <TabsTrigger value="potential">Potential</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all" className="mt-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Card key={i}>
                <CardHeader className="pb-2">
                  <CardTitle>Client Name {i}</CardTitle>
                  <CardDescription>client{i}@example.com</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-sm space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-500">Active Cases:</span>
                      <span className="font-medium">{i}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Total Billing:</span>
                      <span className="font-medium">${i * 1000}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Last Contact:</span>
                      <span className="font-medium">June {i+10}, 2025</span>
                    </div>
                  </div>
                  <div className="flex justify-end mt-4">
                    <Button variant="outline" size="sm">View Details</Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
        
        <TabsContent value="active">
          <div className="text-center py-10">
            <Users className="mx-auto h-8 w-8 text-gray-400" />
            <h3 className="mt-4 text-lg font-medium">Active Clients</h3>
            <p className="mt-2 text-sm text-gray-500">Filter view will be implemented soon.</p>
          </div>
        </TabsContent>
        
        <TabsContent value="inactive">
          <div className="text-center py-10">
            <Users className="mx-auto h-8 w-8 text-gray-400" />
            <h3 className="mt-4 text-lg font-medium">Inactive Clients</h3>
            <p className="mt-2 text-sm text-gray-500">Filter view will be implemented soon.</p>
          </div>
        </TabsContent>
        
        <TabsContent value="potential">
          <div className="text-center py-10">
            <Users className="mx-auto h-8 w-8 text-gray-400" />
            <h3 className="mt-4 text-lg font-medium">Potential Clients</h3>
            <p className="mt-2 text-sm text-gray-500">Filter view will be implemented soon.</p>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Clients;
