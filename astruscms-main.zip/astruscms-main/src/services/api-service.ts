
import { casesApi, aiApi, researchApi, documentsApi } from './api';

export const apiService = {
  cases: casesApi,
  ai: aiApi,
  research: researchApi,
  documents: documentsApi
};
