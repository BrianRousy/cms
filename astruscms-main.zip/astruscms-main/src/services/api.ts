import { supabase } from "@/integrations/supabase/client";

export interface Case {
  id: string;
  title: string;
  case_number: string;
  description?: string;
  client_name: string;
  client_email?: string;
  status: string;
  priority: string;
  practice_area?: string;
  assigned_attorney?: string;
  open_date: string;
  due_date?: string;
  next_court_date?: string;
  progress: number;
  creator_id?: string;
  created_at: string;
  updated_at: string;
}

export interface CreateCaseParams {
  title: string;
  case_number: string;
  description?: string;
  client_name: string;
  client_email?: string;
  status?: string;
  priority?: string;
  practice_area?: string;
  due_date?: string;
  next_court_date?: string;
}

export interface UpdateCaseParams {
  title?: string;
  description?: string;
  client_name?: string;
  client_email?: string;
  status?: string;
  priority?: string;
  practice_area?: string;
  assigned_attorney?: string;
  due_date?: string;
  next_court_date?: string;
  progress?: number;
}

export interface ChatMessage {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp?: string;
}

export interface ResearchResult {
  query: string;
  results: string;
  sources: string[];
  timestamp: string;
}

// Case management APIs
export const casesApi = {
  getCases: async (params?: {
    status?: string;
    practice_area?: string;
    search?: string;
    priority?: string;
    limit?: number;
    offset?: number;
  }) => {
    const session = await supabase.auth.getSession();
    if (!session.data.session) throw new Error("Not authenticated");
    
    try {
      let queryParams = {};
      if (params) {
        queryParams = { ...params };
      }
      
      console.log("Fetching cases with params:", queryParams);
      
      const { data, error } = await supabase.functions.invoke("get-cases", {
        body: {},
        headers: { 
          Authorization: `Bearer ${session.data.session.access_token}` 
        },
        ...(Object.keys(queryParams).length > 0 ? { params: queryParams } : {})
      });
      
      if (error) {
        console.error("Error fetching cases:", error);
        throw error;
      }
      
      console.log("Retrieved cases:", data);
      return data.data;
    } catch (error) {
      console.error("Exception in getCases:", error);
      throw error;
    }
  },
  
  getCase: async (id: string) => {
    const session = await supabase.auth.getSession();
    if (!session.data.session) throw new Error("Not authenticated");
    
    try {
      console.log(`Fetching case with ID: ${id}`);
      
      const { data, error } = await supabase.functions.invoke(`manage-case/${id}`, {
        headers: { 
          Authorization: `Bearer ${session.data.session.access_token}` 
        }
      });
      
      if (error) {
        console.error("Error fetching case:", error);
        throw error;
      }
      
      console.log("Retrieved case:", data);
      return data.data;
    } catch (error) {
      console.error(`Exception in getCase(${id}):`, error);
      throw error;
    }
  },
  
  createCase: async (caseData: CreateCaseParams) => {
    const session = await supabase.auth.getSession();
    if (!session.data.session) throw new Error("Not authenticated");
    
    try {
      console.log("Creating new case:", caseData);
      
      const { data, error } = await supabase.functions.invoke("manage-case", {
        method: "POST",
        body: caseData,
        headers: { 
          Authorization: `Bearer ${session.data.session.access_token}` 
        }
      });
      
      if (error) {
        console.error("Error creating case:", error);
        throw error;
      }
      
      console.log("Case created successfully:", data);
      return data;
    } catch (error) {
      console.error("Exception in createCase:", error);
      throw error;
    }
  },
  
  updateCase: async (id: string, updates: UpdateCaseParams) => {
    const session = await supabase.auth.getSession();
    if (!session.data.session) throw new Error("Not authenticated");
    
    try {
      console.log(`Updating case ${id}:`, updates);
      
      const { data, error } = await supabase.functions.invoke(`manage-case/${id}`, {
        method: "PUT",
        body: updates,
        headers: { 
          Authorization: `Bearer ${session.data.session.access_token}` 
        }
      });
      
      if (error) {
        console.error("Error updating case:", error);
        throw error;
      }
      
      console.log("Case updated successfully:", data);
      return data;
    } catch (error) {
      console.error(`Exception in updateCase(${id}):`, error);
      throw error;
    }
  },
  
  deleteCase: async (id: string) => {
    const session = await supabase.auth.getSession();
    if (!session.data.session) throw new Error("Not authenticated");
    
    try {
      console.log(`Deleting case ${id}`);
      
      const { data, error } = await supabase.functions.invoke(`manage-case/${id}`, {
        method: "DELETE",
        headers: { 
          Authorization: `Bearer ${session.data.session.access_token}` 
        }
      });
      
      if (error) {
        console.error("Error deleting case:", error);
        throw error;
      }
      
      console.log("Case deleted successfully");
      return data;
    } catch (error) {
      console.error(`Exception in deleteCase(${id}):`, error);
      throw error;
    }
  }
};

// AI assistant API
export const aiApi = {
  sendMessage: async (messages: ChatMessage[], sessionId?: string) => {
    const session = await supabase.auth.getSession();
    if (!session.data.session) throw new Error("Not authenticated");
    
    const { data, error } = await supabase.functions.invoke("ai-legal-assistant", {
      body: { 
        messages: messages.map(msg => ({
          role: msg.role,
          content: msg.content
        })),
        sessionId
      },
      headers: { 
        Authorization: `Bearer ${session.data.session.access_token}` 
      }
    });
    
    if (error) throw error;
    return data as { message: string, id: string, sessionId: string };
  },
  
  saveChat: async (sessionId: string, messages: ChatMessage[], topic?: string) => {
    // Prepare messages for JSON storage
    const messagesJson = messages.map(msg => ({
      id: msg.id,
      content: msg.content,
      role: msg.role,
      timestamp: msg.timestamp
    }));
    
    const { data, error } = await supabase
      .from('ai_chat_history')
      .insert({
        session_id: sessionId,
        messages: messagesJson,
        topic: topic || messages[0]?.content.substring(0, 100) || 'New conversation'
      });
      
    if (error) throw error;
    return data;
  },
  
  getChats: async () => {
    const { data, error } = await supabase
      .from('ai_chat_history')
      .select('*')
      .order('created_at', { ascending: false });
      
    if (error) throw error;
    return data;
  },
  
  getChat: async (sessionId: string) => {
    const { data, error } = await supabase
      .from('ai_chat_history')
      .select('*')
      .eq('session_id', sessionId)
      .single();
      
    if (error) throw error;
    return data;
  }
};

// Legal research API
export const researchApi = {
  performResearch: async (query: string, saveResults: boolean = false) => {
    const session = await supabase.auth.getSession();
    if (!session.data.session) throw new Error("Not authenticated");
    
    const { data, error } = await supabase.functions.invoke("legal-research", {
      body: { 
        query,
        saveResults
      },
      headers: { 
        Authorization: `Bearer ${session.data.session.access_token}` 
      }
    });
    
    if (error) throw error;
    return data as ResearchResult;
  },
  
  getSavedResearch: async () => {
    const { data, error } = await supabase
      .from('legal_research')
      .select('*')
      .eq('saved', true)
      .order('created_at', { ascending: false });
      
    if (error) throw error;
    return data;
  }
};

// Document management APIs
export const documentsApi = {
  uploadDocument: async (file: File, caseId: string, name: string, description?: string) => {
    const session = await supabase.auth.getSession();
    if (!session.data.session) throw new Error("Not authenticated");
    
    const user = session.data.session.user;
    const fileExt = file.name.split('.').pop();
    const filePath = `${caseId}/${crypto.randomUUID()}.${fileExt}`;
    
    // Upload file to storage
    const { data: storageData, error: storageError } = await supabase.storage
      .from('case_documents')
      .upload(filePath, file);
      
    if (storageError) throw storageError;
    
    // Create document record in database
    const { data, error } = await supabase
      .from('case_documents')
      .insert({
        case_id: caseId,
        name: name || file.name,
        description,
        file_path: filePath,
        file_type: file.type,
        file_size: file.size,
        uploaded_by: user.id
      })
      .select()
      .single();
      
    if (error) throw error;
    return data;
  },
  
  getDocuments: async (caseId?: string) => {
    let query = supabase.from('case_documents').select('*');
    
    if (caseId) {
      query = query.eq('case_id', caseId);
    }
    
    const { data, error } = await query.order('created_at', { ascending: false });
    
    if (error) throw error;
    return data;
  },
  
  getDocumentUrl: async (filePath: string) => {
    const { data, error } = await supabase.storage
      .from('case_documents')
      .createSignedUrl(filePath, 60 * 60); // 1 hour expiry
      
    if (error) throw error;
    return data.signedUrl;
  },
  
  deleteDocument: async (id: string, filePath: string) => {
    // Delete from storage
    const { error: storageError } = await supabase.storage
      .from('case_documents')
      .remove([filePath]);
      
    if (storageError) throw storageError;
    
    // Delete from database
    const { error } = await supabase
      .from('case_documents')
      .delete()
      .eq('id', id);
      
    if (error) throw error;
    return { success: true };
  }
};
