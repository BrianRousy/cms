
import { supabase } from "@/integrations/supabase/client";
import { ApiClient } from "@/lib/api-client";

export interface TimeEntry {
  id?: string;
  case_id?: string;
  case_name?: string;
  task_id?: string;
  task_name?: string;
  description?: string;
  start_time: string;
  end_time?: string;
  duration?: number;
  billable: boolean;
  billable_amount?: number;
  user_id: string;
  status: 'active' | 'completed' | 'billed' | 'unbilled';
  created_at?: string;
  updated_at?: string;
}

export const timeTrackingService = {
  // Get all time entries for the current user
  getTimeEntries: async () => {
    return ApiClient.fetch({
      queryFn: async () => {
        const session = await supabase.auth.getSession();
        if (!session.data.session) throw new Error("Not authenticated");

        // Get time entries directly from the database
        const { data, error } = await supabase
          .from('time_entries')
          .select('*')
          .eq('user_id', session.data.session.user.id)
          .order('start_time', { ascending: false });

        if (error) throw error;
        return data as TimeEntry[];
      },
      errorMessage: "Failed to fetch time entries",
    });
  },

  // Get time entries for specific period
  getTimeEntriesForPeriod: async (startDate: Date, endDate: Date) => {
    return ApiClient.fetch({
      queryFn: async () => {
        const session = await supabase.auth.getSession();
        if (!session.data.session) throw new Error("Not authenticated");

        // Get time entries directly from the database for the specific period
        const { data, error } = await supabase
          .from('time_entries')
          .select('*')
          .eq('user_id', session.data.session.user.id)
          .gte('start_time', startDate.toISOString())
          .lte('start_time', endDate.toISOString())
          .order('start_time', { ascending: false });

        if (error) throw error;
        return data as TimeEntry[];
      },
      errorMessage: "Failed to fetch time entries for the specified period",
    });
  },

  // Start a new time entry
  startTimeEntry: async (entry: Omit<TimeEntry, 'id' | 'created_at' | 'updated_at'>) => {
    return ApiClient.mutate({
      mutateFn: async () => {
        const session = await supabase.auth.getSession();
        if (!session.data.session) throw new Error("Not authenticated");

        const { data, error } = await supabase
          .from('time_entries')
          .insert({
            ...entry,
            user_id: session.data.session.user.id,
          })
          .select()
          .single();

        if (error) throw error;
        return data as TimeEntry;
      },
      successMessage: "Time tracking started",
      errorMessage: "Failed to start time tracking",
    });
  },

  // Stop an active time entry
  stopTimeEntry: async (id: string, endTime: string, duration: number) => {
    return ApiClient.mutate({
      mutateFn: async () => {
        const session = await supabase.auth.getSession();
        if (!session.data.session) throw new Error("Not authenticated");

        // Calculate billable amount (assuming $150/hour rate)
        const hourlyRate = 150;
        const hours = duration / 3600;
        const billable_amount = Math.round(hourlyRate * hours);

        const { data, error } = await supabase
          .from('time_entries')
          .update({
            end_time: endTime,
            duration: duration,
            status: 'completed',
            billable_amount: billable_amount
          })
          .eq('id', id)
          .eq('user_id', session.data.session.user.id)
          .select()
          .single();

        if (error) throw error;
        return data as TimeEntry;
      },
      successMessage: "Time tracking stopped",
      errorMessage: "Failed to stop time tracking",
    });
  },

  // Add a manual time entry
  addManualEntry: async (entry: Omit<TimeEntry, 'id' | 'created_at' | 'updated_at'>) => {
    return ApiClient.mutate({
      mutateFn: async () => {
        const session = await supabase.auth.getSession();
        if (!session.data.session) throw new Error("Not authenticated");

        const { data, error } = await supabase
          .from('time_entries')
          .insert({
            ...entry,
            user_id: session.data.session.user.id,
          })
          .select()
          .single();

        if (error) throw error;
        return data as TimeEntry;
      },
      successMessage: "Time entry added",
      errorMessage: "Failed to add time entry",
    });
  },

  // Update a time entry
  updateTimeEntry: async (id: string, updates: Partial<TimeEntry>) => {
    return ApiClient.mutate({
      mutateFn: async () => {
        const session = await supabase.auth.getSession();
        if (!session.data.session) throw new Error("Not authenticated");

        const { data, error } = await supabase
          .from('time_entries')
          .update({
            ...updates,
            updated_at: new Date().toISOString()
          })
          .eq('id', id)
          .eq('user_id', session.data.session.user.id)
          .select()
          .single();

        if (error) throw error;
        return data as TimeEntry;
      },
      successMessage: "Time entry updated",
      errorMessage: "Failed to update time entry",
    });
  },

  // Delete a time entry
  deleteTimeEntry: async (id: string) => {
    return ApiClient.mutate({
      mutateFn: async () => {
        const session = await supabase.auth.getSession();
        if (!session.data.session) throw new Error("Not authenticated");

        const { error } = await supabase
          .from('time_entries')
          .delete()
          .eq('id', id)
          .eq('user_id', session.data.session.user.id);

        if (error) throw error;
        return { success: true };
      },
      successMessage: "Time entry deleted",
      errorMessage: "Failed to delete time entry",
    });
  },

  // Get time entry statistics
  getTimeEntryStats: async (startDate: Date, endDate: Date) => {
    return ApiClient.fetch({
      queryFn: async () => {
        const session = await supabase.auth.getSession();
        if (!session.data.session) throw new Error("Not authenticated");

        const { data, error } = await supabase
          .from('time_entries')
          .select('duration, billable_amount')
          .eq('user_id', session.data.session.user.id)
          .gte('start_time', startDate.toISOString())
          .lte('start_time', endDate.toISOString());

        if (error) throw error;
        return data;
      },
      errorMessage: "Failed to fetch time entry statistics",
    });
  },

  // Export time entries
  exportTimeEntries: async (startDate: Date, endDate: Date, format: 'csv' | 'pdf') => {
    return ApiClient.fetch({
      queryFn: async () => {
        const session = await supabase.auth.getSession();
        if (!session.data.session) throw new Error("Not authenticated");

        // In a real implementation, this would generate a file for download
        const { data, error } = await supabase
          .from('time_entries')
          .select('*')
          .eq('user_id', session.data.session.user.id)
          .gte('start_time', startDate.toISOString())
          .lte('start_time', endDate.toISOString())
          .order('start_time', { ascending: false });

        if (error) throw error;
        return { data, format, downloadUrl: '#' };
      },
      errorMessage: `Failed to export time entries as ${format}`,
    });
  },
};
