import { User, Case, Task, Document, CalendarEvent } from "../types";

export const mockUsers: User[] = [
  {
    id: "1",
    name: "John Smith",
    email: "john@lawfirm.com",
    role: "admin",
    avatar: "/placeholder.svg",
  },
  {
    id: "2",
    name: "Sarah Johnson",
    email: "sarah@lawfirm.com",
    role: "lawyer",
    avatar: "/placeholder.svg",
  },
  {
    id: "3",
    name: "Michael Brown",
    email: "michael@lawfirm.com",
    role: "paralegal",
    avatar: "/placeholder.svg",
  },
  {
    id: "4",
    name: "Emily Davis",
    email: "emily@lawfirm.com",
    role: "lawyer",
    avatar: "/placeholder.svg",
  },
  {
    id: "5",
    name: "Robert Wilson",
    email: "robert@lawfirm.com",
    role: "assistant",
    avatar: "/placeholder.svg",
  },
];

export const mockCases: Case[] = [
  {
    id: "1",
    title: "Johnson vs. Smith Property Dispute",
    caseNumber: "CV-2023-1234",
    client: "Johnson Family Trust",
    clientId: "cl-001",
    status: "open",
    priority: "high",
    stage: "discovery",
    dueDate: "2025-06-15",
    assignedTo: ["2", "3"],
    description: "Property boundary dispute involving commercial real estate in downtown area.",
    progress: 45,
    tags: ["property", "commercial", "dispute"],
    createdAt: "2025-01-15T08:30:00Z",
    updatedAt: "2025-04-02T14:45:00Z",
  },
  {
    id: "2",
    title: "Williams Injury Claim",
    caseNumber: "PI-2023-5678",
    client: "Thomas Williams",
    clientId: "cl-002",
    status: "open",
    priority: "medium",
    stage: "negotiation",
    dueDate: "2025-05-20",
    assignedTo: ["4"],
    description: "Personal injury claim following workplace accident at construction site.",
    progress: 70,
    tags: ["personal injury", "workplace", "insurance"],
    createdAt: "2025-02-10T10:15:00Z",
    updatedAt: "2025-04-05T11:30:00Z",
  },
  {
    id: "3",
    title: "Garcia Incorporation",
    caseNumber: "BL-2023-9012",
    client: "Garcia Family Restaurants",
    clientId: "cl-003",
    status: "pending",
    priority: "low",
    stage: "intake",
    dueDate: "2025-04-30",
    assignedTo: ["2"],
    description: "Business incorporation and license application for new restaurant chain.",
    progress: 15,
    tags: ["business", "incorporation", "licensing"],
    createdAt: "2025-03-25T09:00:00Z",
    updatedAt: "2025-04-01T16:20:00Z",
  },
  {
    id: "4",
    title: "Thompson Divorce Settlement",
    caseNumber: "FM-2023-3456",
    client: "Jessica Thompson",
    clientId: "cl-004",
    status: "open",
    priority: "high",
    stage: "negotiation",
    dueDate: "2025-05-10",
    assignedTo: ["4", "5"],
    description: "Contested divorce with complex asset division and custody arrangements.",
    progress: 60,
    tags: ["family", "divorce", "custody"],
    createdAt: "2024-12-05T11:45:00Z",
    updatedAt: "2025-04-08T13:10:00Z",
  },
  {
    id: "5",
    title: "BlackTech Patent Application",
    caseNumber: "IP-2023-7890",
    client: "BlackTech Solutions",
    clientId: "cl-005",
    status: "open",
    priority: "medium",
    stage: "discovery",
    dueDate: "2025-07-30",
    assignedTo: ["2", "3"],
    description: "Patent application for new AI-driven security software.",
    progress: 35,
    tags: ["intellectual property", "patent", "technology"],
    createdAt: "2025-01-30T14:00:00Z",
    updatedAt: "2025-04-07T10:50:00Z",
  },
];

export const mockTasks: Task[] = [
  {
    id: "1",
    caseId: "1",
    title: "Document Review - Johnson Property Deeds",
    description: "Review historical property documents and boundary surveys",
    assignedTo: "3",
    dueDate: "2025-04-15",
    status: "in-progress",
    priority: "high",
    createdAt: "2025-03-20T09:30:00Z",
    updatedAt: "2025-04-05T11:15:00Z",
  },
  {
    id: "2",
    caseId: "1",
    title: "Schedule Property Inspection",
    description: "Coordinate with surveyor for on-site property measurement",
    assignedTo: "2",
    dueDate: "2025-04-20",
    status: "todo",
    priority: "medium",
    createdAt: "2025-03-25T14:20:00Z",
    updatedAt: "2025-03-25T14:20:00Z",
  },
  {
    id: "3",
    caseId: "2",
    title: "Medical Record Analysis",
    description: "Review and summarize medical records for Williams injury claim",
    assignedTo: "4",
    dueDate: "2025-04-18",
    status: "in-progress",
    priority: "high",
    createdAt: "2025-03-15T10:00:00Z",
    updatedAt: "2025-04-02T16:40:00Z",
  },
  {
    id: "4",
    caseId: "4",
    title: "Draft Articles of Incorporation",
    description: "Prepare incorporation documents for Garcia Restaurants",
    assignedTo: "2",
    dueDate: "2025-04-25",
    status: "todo",
    priority: "medium",
    createdAt: "2025-04-01T11:30:00Z",
    updatedAt: "2025-04-01T11:30:00Z",
  },
  {
    id: "5",
    caseId: "5",
    title: "Asset Inventory Compilation",
    description: "Create comprehensive list of marital assets with documentation",
    assignedTo: "5",
    dueDate: "2025-04-12",
    status: "completed",
    priority: "high",
    createdAt: "2025-03-10T09:15:00Z",
    updatedAt: "2025-04-08T15:20:00Z",
  },
];

export const mockDocuments: Document[] = [
  {
    id: "1",
    caseId: "1",
    name: "Property Deed - 145 Main St.pdf",
    type: "application/pdf",
    size: 1420345,
    uploadedBy: "2",
    uploadedAt: "2025-03-15T10:30:00Z",
    url: "/placeholder.svg",
  },
  {
    id: "2",
    caseId: "1",
    name: "Survey Map 2010.pdf",
    type: "application/pdf",
    size: 2834521,
    uploadedBy: "3",
    uploadedAt: "2025-03-20T14:15:00Z",
    url: "/placeholder.svg",
  },
  {
    id: "3",
    caseId: "2",
    name: "Medical Report - Dr. Stevens.docx",
    type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    size: 528491,
    uploadedBy: "4",
    uploadedAt: "2025-03-25T09:45:00Z",
    url: "/placeholder.svg",
  },
  {
    id: "4",
    caseId: "4",
    name: "Financial Statements 2020-2024.xlsx",
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    size: 1245782,
    uploadedBy: "5",
    uploadedAt: "2025-03-12T11:20:00Z",
    url: "/placeholder.svg",
  },
  {
    id: "5",
    caseId: "5",
    name: "Patent Draft v2.3.docx",
    type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    size: 1876234,
    uploadedBy: "2",
    uploadedAt: "2025-04-01T15:50:00Z",
    url: "/placeholder.svg",
  },
];

export const mockEvents: CalendarEvent[] = [
  {
    id: "1",
    title: "Johnson Property Case - Court Hearing",
    caseId: "1",
    start: "2025-04-20T10:00:00",
    end: "2025-04-20T12:00:00",
    allDay: false,
    location: "District Court, Room 305",
    description: "Initial hearing for property dispute case",
    eventType: "court-date",
    attendees: ["2", "3"],
  },
  {
    id: "2",
    title: "Client Meeting - Williams",
    caseId: "2",
    start: "2025-04-15T14:30:00",
    end: "2025-04-15T15:30:00",
    allDay: false,
    location: "Conference Room B",
    description: "Review settlement offer with client",
    eventType: "client-meeting",
    attendees: ["4", "5"],
  },
  {
    id: "3",
    title: "Discovery Deadline - BlackTech Patent",
    caseId: "5",
    start: "2025-05-01",
    end: "2025-05-01",
    allDay: true,
    description: "Final date for discovery document submission",
    eventType: "deadline",
    attendees: ["2", "3"],
  },
  {
    id: "4",
    title: "Thompson Mediation Session",
    caseId: "4",
    start: "2025-04-25T09:00:00",
    end: "2025-04-25T12:00:00",
    allDay: false,
    location: "Mediation Center, Suite 400",
    description: "Divorce settlement negotiation",
    eventType: "court-date",
    attendees: ["4", "5"],
  },
  {
    id: "5",
    title: "Garcia Business License Submission Deadline",
    caseId: "3",
    start: "2025-04-30",
    end: "2025-04-30",
    allDay: true,
    description: "Last day to submit business license application",
    eventType: "deadline",
    attendees: ["2"],
  },
];

// Mock authenticated user
export const currentUser: User = mockUsers[0];

// Mock notifications
export const mockNotifications = [
  {
    id: 1,
    title: "Deadline Approaching",
    description: "Case #1234 has a filing deadline tomorrow",
    read: false,
    time: "10 minutes ago"
  },
  {
    id: 2,
    title: "New Document Shared",
    description: "John Smith shared 'Motion to Dismiss' with you",
    read: false,
    time: "45 minutes ago"
  },
  {
    id: 3,
    title: "Task Assigned",
    description: "Sarah assigned you to review evidence for Thompson case",
    read: false,
    time: "2 hours ago"
  },
  {
    id: 4,
    title: "Client Message",
    description: "ABC Corp. sent a new message regarding their case",
    read: true,
    time: "Yesterday"
  },
  {
    id: 5,
    title: "Payment Received",
    description: "Invoice #5678 was paid in full",
    read: true,
    time: "2 days ago"
  },
  {
    id: 6,
    title: "New Case Created",
    description: "Case #2345 has been created and assigned to you",
    read: true,
    time: "3 days ago"
  },
  {
    id: 7,
    title: "Meeting Scheduled",
    description: "Team meeting scheduled for April 15 at 2:00 PM",
    read: true,
    time: "4 days ago"
  }
];

// Functions to get filtered data
export const getCasesByStatus = (status: Case['status']) => {
  return mockCases.filter(c => c.status === status);
};

export const getTasksByStatus = (status: Task['status']) => {
  return mockTasks.filter(t => t.status === status);
};

export const getTasksByCaseId = (caseId: string) => {
  return mockTasks.filter(t => t.caseId === caseId);
};

export const getDocumentsByCaseId = (caseId: string) => {
  return mockDocuments.filter(d => d.caseId === caseId);
};

export const getUpcomingEvents = (days: number = 7) => {
  const today = new Date();
  const cutoff = new Date();
  cutoff.setDate(today.getDate() + days);
  
  return mockEvents
    .filter(event => {
      const eventDate = new Date(event.start);
      return eventDate >= today && eventDate <= cutoff;
    })
    .sort((a, b) => new Date(a.start).getTime() - new Date(b.start).getTime());
};

export const getUserById = (userId: string) => {
  return mockUsers.find(user => user.id === userId);
};

export const getCaseById = (caseId: string) => {
  return mockCases.find(c => c.id === caseId);
};
