
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

/**
 * ApiClient provides standardized methods for API operations with built-in error handling
 * and loading state management.
 */
export class ApiClient {
  /**
   * Performs a database fetch operation with error handling.
   */
  static async fetch<T>({
    queryFn,
    errorMessage = "Failed to fetch data",
    showErrorToast = true,
  }: {
    queryFn: () => Promise<T>;
    errorMessage?: string;
    showErrorToast?: boolean;
  }): Promise<{ data: T | null; error: Error | null }> {
    try {
      const data = await queryFn();
      return { data, error: null };
    } catch (err) {
      console.error(`${errorMessage}:`, err);
      
      if (showErrorToast) {
        toast({
          title: "Error",
          description: errorMessage,
          variant: "destructive",
        });
      }
      
      return { data: null, error: err instanceof Error ? err : new Error(String(err)) };
    }
  }

  /**
   * Performs a database mutation operation with error handling.
   */
  static async mutate<T>({
    mutateFn,
    successMessage = "Operation successful",
    errorMessage = "Operation failed",
    showSuccessToast = true,
    showErrorToast = true,
  }: {
    mutateFn: () => Promise<T>;
    successMessage?: string;
    errorMessage?: string;
    showSuccessToast?: boolean;
    showErrorToast?: boolean;
  }): Promise<{ data: T | null; error: Error | null }> {
    try {
      const data = await mutateFn();
      
      if (showSuccessToast) {
        toast({
          title: "Success",
          description: successMessage,
        });
      }
      
      return { data, error: null };
    } catch (err) {
      console.error(`${errorMessage}:`, err);
      
      if (showErrorToast) {
        toast({
          title: "Error",
          description: errorMessage,
          variant: "destructive",
        });
      }
      
      return { data: null, error: err instanceof Error ? err : new Error(String(err)) };
    }
  }

  /**
   * Checks if the user is authenticated and returns the session.
   * If not authenticated, shows an error toast and returns null.
   */
  static async requireAuth(redirectToLogin = false) {
    const { data: { session } } = await supabase.auth.getSession();
    
    if (!session) {
      toast({
        title: "Authentication Required",
        description: "Please log in to continue",
        variant: "destructive",
      });
      
      if (redirectToLogin) {
        window.location.href = "/login";
      }
      
      return null;
    }
    
    return session;
  }
}
