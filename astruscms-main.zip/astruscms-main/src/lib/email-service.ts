
import { supabase } from "@/integrations/supabase/client";
import { ApiClient } from "./api-client";

interface SendEmailParams {
  to: string;
  subject: string;
  html?: string;
  text?: string;
  type?: 'notification' | 'calendar' | 'task' | 'welcome' | 'reminder';
  metadata?: Record<string, any>;
}

export async function sendEmail({
  to,
  subject,
  html,
  text,
  type = 'notification',
  metadata = {}
}: SendEmailParams) {
  return ApiClient.fetch({
    queryFn: async () => {
      const session = await ApiClient.requireAuth();
      if (!session) throw new Error("Authentication required");
      
      // Call the Supabase Edge Function for sending emails
      const { data, error } = await supabase.functions.invoke('send-email', {
        body: {
          to,
          subject,
          html,
          text,
          type,
          metadata
        },
        headers: {
          Authorization: `Bearer ${session.access_token}`
        }
      });

      if (error) {
        throw error;
      }

      return data;
    },
    errorMessage: 'Failed to send email'
  });
}

export async function sendCalendarInvite({
  to,
  eventTitle,
  eventDate,
  eventTime,
  eventLocation,
  description,
  metadata = {}
}: {
  to: string;
  eventTitle: string;
  eventDate: string;
  eventTime: string;
  eventLocation?: string;
  description?: string;
  metadata?: Record<string, any>;
}) {
  const html = `
    <h2>Calendar Invitation: ${eventTitle}</h2>
    <p>You have been invited to the following event:</p>
    <div style="margin: 20px 0; padding: 15px; border-left: 4px solid #9b87f5; background-color: #f8f9fa;">
      <p><strong>Event:</strong> ${eventTitle}</p>
      <p><strong>Date:</strong> ${eventDate}</p>
      <p><strong>Time:</strong> ${eventTime}</p>
      ${eventLocation ? `<p><strong>Location:</strong> ${eventLocation}</p>` : ''}
      ${description ? `<p><strong>Description:</strong> ${description}</p>` : ''}
    </div>
    <p>This event has been added to your Astrus CMS calendar.</p>
    <a href="#" style="display: inline-block; background-color: #9b87f5; color: #ffffff; padding: 12px 24px; text-decoration: none; border-radius: 4px; font-weight: bold; margin: 20px 0;">View in Calendar</a>
  `;

  return sendEmail({
    to,
    subject: `Calendar Invitation: ${eventTitle}`,
    html,
    type: 'calendar',
    metadata: {
      eventTitle,
      eventDate,
      eventTime,
      eventLocation,
      description,
      ...metadata
    }
  });
}

export async function sendTaskNotification({
  to,
  taskTitle,
  dueDate,
  priority,
  assignedBy,
  metadata = {}
}: {
  to: string;
  taskTitle: string;
  dueDate: string;
  priority: 'low' | 'medium' | 'high';
  assignedBy?: string;
  metadata?: Record<string, any>;
}) {
  const priorityColor = 
    priority === 'high' ? '#ef4444' : 
    priority === 'medium' ? '#f59e0b' : 
    '#10b981';
  
  const html = `
    <h2>New Task Assignment</h2>
    <p>A new task has been assigned to you:</p>
    <div style="margin: 20px 0; padding: 15px; border-left: 4px solid ${priorityColor}; background-color: #f8f9fa;">
      <p><strong>Task:</strong> ${taskTitle}</p>
      <p><strong>Due Date:</strong> ${dueDate}</p>
      <p><strong>Priority:</strong> <span style="color: ${priorityColor}; font-weight: bold;">${priority.toUpperCase()}</span></p>
      ${assignedBy ? `<p><strong>Assigned By:</strong> ${assignedBy}</p>` : ''}
    </div>
    <p>Please log into Astrus CMS to view the task details and complete it.</p>
    <a href="#" style="display: inline-block; background-color: #9b87f5; color: #ffffff; padding: 12px 24px; text-decoration: none; border-radius: 4px; font-weight: bold; margin: 20px 0;">View Task</a>
  `;

  return sendEmail({
    to,
    subject: `New Task Assignment: ${taskTitle}`,
    html,
    type: 'task',
    metadata: {
      taskTitle,
      dueDate,
      priority,
      assignedBy,
      ...metadata
    }
  });
}
