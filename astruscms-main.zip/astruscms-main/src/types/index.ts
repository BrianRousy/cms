
export type User = {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'lawyer' | 'paralegal' | 'assistant' | 'client';
  avatar?: string;
  position?: string;
  department?: string;
  phone?: string;
  permissions?: string[];
  lastActive?: string;
};

export type Case = {
  id: string;
  title: string;
  caseNumber: string;
  client: string;
  clientId: string;
  status: 'open' | 'closed' | 'pending' | 'archived';
  priority: 'high' | 'medium' | 'low';
  stage: 'intake' | 'discovery' | 'negotiation' | 'trial' | 'settlement' | 'closed';
  dueDate: string;
  assignedTo: string[];
  description: string;
  progress: number;
  tags: string[];
  createdAt: string;
  updatedAt: string;
  practice_area?: string;
  court?: string;
  opposing_party?: string;
  opposing_counsel?: string;
  judge?: string;
  statute_of_limitations?: string;
  billing_method?: 'hourly' | 'flat_fee' | 'contingency';
  estimated_value?: number;
  retainer_amount?: number;
  related_cases?: string[];
};

export type Document = {
  id: string;
  caseId: string;
  name: string;
  type: string;
  size: number;
  uploadedBy: string;
  uploadedAt: string;
  url: string;
  version?: number;
  tags?: string[];
  status?: 'draft' | 'final' | 'archived';
  description?: string;
  expiresAt?: string;
  access_level?: 'public' | 'team' | 'private';
  signed?: boolean;
  signature_status?: 'unsigned' | 'partially_signed' | 'fully_signed';
};

export type Task = {
  id: string;
  caseId: string;
  title: string;
  description: string;
  assignedTo: string;
  dueDate: string;
  status: 'todo' | 'in-progress' | 'completed';
  priority: 'high' | 'medium' | 'low';
  createdAt: string;
  updatedAt: string;
  estimated_time?: number;
  actual_time?: number;
  reminder?: string;
  parent_task?: string;
  subtasks?: string[];
  notes?: string;
  category?: 'research' | 'drafting' | 'filing' | 'client_communication' | 'court_appearance' | 'other';
  billable?: boolean;
};

export type CalendarEvent = {
  id: string;
  title: string;
  caseId?: string;
  start: string;
  end: string;
  allDay: boolean;
  location?: string;
  description?: string;
  eventType: 'court-date' | 'client-meeting' | 'deadline' | 'other' | 'deposition' | 'filing' | 'hearing';
  attendees: string[];
  reminder?: string;
  recurrence?: string;
  status?: 'confirmed' | 'tentative' | 'cancelled';
  notes?: string;
  virtual_meeting_link?: string;
};

export type Notification = {
  id: string;
  userId: string;
  title: string;
  message: string;
  read: boolean;
  createdAt: string;
  link?: string;
  type?: 'system' | 'case' | 'task' | 'document' | 'billing';
  priority?: 'normal' | 'urgent';
};

export type Client = {
  id: string;
  name: string;
  email: string;
  phone?: string;
  address?: string;
  company?: string;
  type: 'individual' | 'company' | 'non-profit';
  status: 'active' | 'inactive' | 'potential';
  created_at: string;
  notes?: string;
  contacts?: Contact[];
  billing_info?: BillingInfo;
  intake_date?: string;
  referred_by?: string;
  portal_access?: boolean;
};

export type Contact = {
  id: string;
  client_id: string;
  name: string;
  email: string;
  phone?: string;
  role?: string;
  is_primary: boolean;
};

export type BillingInfo = {
  id: string;
  client_id: string;
  billing_address?: string;
  billing_method?: 'credit_card' | 'bank_transfer' | 'check';
  payment_terms?: string;
  account_balance?: number;
  payment_status?: 'current' | 'overdue';
};

export type TimeEntry = {
  id: string;
  user_id: string;
  case_id: string;
  task_id?: string;
  description: string;
  start_time: string;
  end_time?: string;
  duration: number; // in minutes
  billable: boolean;
  rate?: number;
  billing_status: 'unbilled' | 'billed' | 'non-billable';
  invoice_id?: string;
  created_at: string;
  updated_at: string;
};

export type Invoice = {
  id: string;
  client_id: string;
  case_id?: string;
  invoice_number: string;
  issue_date: string;
  due_date: string;
  amount: number;
  tax?: number;
  status: 'draft' | 'sent' | 'paid' | 'overdue' | 'cancelled';
  payment_date?: string;
  notes?: string;
  items: InvoiceItem[];
};

export type InvoiceItem = {
  id: string;
  invoice_id: string;
  description: string;
  quantity: number;
  rate: number;
  amount: number;
  time_entry_id?: string;
  expense_id?: string;
};

export type Expense = {
  id: string;
  case_id: string;
  user_id: string;
  amount: number;
  date: string;
  description: string;
  category: string;
  billable: boolean;
  reimbursable: boolean;
  receipt_url?: string;
  status: 'pending' | 'approved' | 'rejected' | 'reimbursed';
  billing_status: 'unbilled' | 'billed';
  invoice_id?: string;
};

export type Note = {
  id: string;
  case_id?: string;
  client_id?: string;
  user_id: string;
  content: string;
  created_at: string;
  updated_at: string;
  is_private: boolean;
  category?: string;
};

export type LegalResource = {
  id: string;
  title: string;
  type: 'precedent' | 'template' | 'article' | 'statute' | 'case_law';
  description?: string;
  content_url?: string;
  tags: string[];
  practice_area?: string;
  jurisdiction?: string;
  created_at: string;
  updated_at: string;
  created_by: string;
};

export type AuditLog = {
  id: string;
  user_id: string;
  action: string;
  entity_type: 'case' | 'document' | 'task' | 'client' | 'invoice' | 'user';
  entity_id: string;
  details: string;
  timestamp: string;
  ip_address?: string;
};
