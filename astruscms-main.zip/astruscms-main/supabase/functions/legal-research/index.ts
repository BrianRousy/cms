
import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.40.0"

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
}

// Supabase client for the Edge Function
const supabaseClient = createClient(
  Deno.env.get("SUPABASE_URL") ?? "",
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
)

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const GEMINI_API_KEY = Deno.env.get('GEMINI_API_KEY');
    
    if (!GEMINI_API_KEY) {
      throw new Error('GEMINI_API_KEY is not set in environment');
    }

    // Get the authorization header to verify user is logged in
    const authHeader = req.headers.get('Authorization');
    
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: "Not authorized" }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Extract JWT token from Authorization header
    const token = authHeader.replace('Bearer ', '');
    
    // Verify the JWT token
    const { data: { user }, error: authError } = await supabaseClient.auth.getUser(token);
    
    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: "Invalid token", details: authError }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Parse the request body
    const { query, saveResults = false } = await req.json();

    if (!query || typeof query !== 'string') {
      return new Response(
        JSON.stringify({ error: "Invalid query format" }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log("Processing legal research query:", query);

    // Make the API call to Google Gemini
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key=${GEMINI_API_KEY}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        contents: [
          {
            role: "user",
            parts: [{ 
              text: `As a legal research assistant, please provide comprehensive research on the following legal query. Include relevant case law, statutes, legal principles, and cite reliable sources: "${query}"` 
            }]
          }
        ],
        generationConfig: {
          temperature: 0.2,
          topP: 0.95,
          topK: 40,
          maxOutputTokens: 8192,
        }
      })
    });

    if (!response.ok) {
      const errorData = await response.text();
      console.error("Gemini API error:", errorData);
      throw new Error(`Gemini API returned ${response.status}: ${errorData}`);
    }

    const data = await response.json();
    
    if (!data.candidates || data.candidates.length === 0) {
      throw new Error("No response generated from Gemini");
    }

    const candidate = data.candidates[0];
    
    if (!candidate.content?.parts || candidate.content.parts.length === 0) {
      throw new Error("Invalid response structure from Gemini");
    }

    const researchResults = candidate.content.parts[0].text;
    
    // Extract sources mentioned in the response (simplified approach)
    const sourcesPattern = /(\b[A-Za-z\s]+ v\. [A-Za-z\s]+,?\s+\d{1,3}\s+[A-Za-z.\s]+\d{1,4}\b|\b\d{1,4}\s+[A-Za-z.\s]+\d{1,4}\b|U\.S\.C\.\s+§\s*\d+|CFR\s+§\s*\d+)/g;
    const sources = researchResults.match(sourcesPattern) || [];
    
    // Format the results
    const formattedResults = {
      query,
      results: researchResults,
      sources: [...new Set(sources)], // Remove duplicates
      timestamp: new Date().toISOString()
    };
    
    // Save to database if requested
    if (saveResults) {
      const { error: dbError } = await supabaseClient
        .from('legal_research')
        .insert({
          user_id: user.id,
          query: query,
          results: { content: researchResults },
          sources: [...new Set(sources)],
          saved: true
        });
        
      if (dbError) {
        console.error("Error saving research results:", dbError);
      } else {
        console.log("Research results saved to database");
      }
    }

    // Return the research results
    return new Response(
      JSON.stringify(formattedResults),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
    
  } catch (error) {
    console.error("Error in legal-research function:", error);
    
    return new Response(
      JSON.stringify({ error: "Legal Research Error", details: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
})
