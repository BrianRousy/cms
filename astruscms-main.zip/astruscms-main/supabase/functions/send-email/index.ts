
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.40.0";

// Define CORS headers for browser requests
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
};

// Supabase client for the Edge Function
const supabaseClient = createClient(
  Deno.env.get("SUPABASE_URL") ?? "",
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
);

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    // Get authorization token
    const authHeader = req.headers.get('Authorization');
    
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: "Not authorized" }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Extract JWT token from Authorization header
    const token = authHeader.replace('Bearer ', '');
    
    // Verify the JWT token
    const { data: { user }, error: authError } = await supabaseClient.auth.getUser(token);
    
    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: "Invalid token", details: authError }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Parse the request body to get email details
    const requestData = await req.json();
    const { 
      to,  // Can be a string or array of recipients
      subject, 
      html, 
      text, 
      type = "notification", // Can be "notification", "calendar", "task", etc.
      metadata = {},
      recipients = null, // For batch sending (array of user objects with email and full_name)
      event = null  // For calendar invites
    } = requestData;

    // Handle different email sending scenarios
    if (recipients && Array.isArray(recipients) && recipients.length > 0 && event) {
      // Batch email for calendar invites
      const results = [];
      
      for (const recipient of recipients) {
        if (!recipient.email) continue;
        
        const personalizedHtml = generateCalendarEmail({
          recipient: recipient,
          event: event,
        });
        
        // Log this email attempt
        await logEmailSend({
          user_id: user.id,
          recipient_email: recipient.email,
          subject: `Calendar: ${event.title}`,
          type: 'calendar',
          metadata: {
            event_id: event.id,
            recipient_id: recipient.id,
            ...metadata
          }
        });
        
        // In a production system, you would actually send the email here
        results.push({
          recipient: recipient.email,
          status: 'sent'
        });
      }
      
      return new Response(
        JSON.stringify({ 
          success: true, 
          message: `${results.length} calendar invites sent successfully`, 
          results 
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
    else if (!to && (!html || !text) && !subject) {
      return new Response(
        JSON.stringify({ error: "Missing required fields: to, subject, and either html or text" }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
    else {
      // Single email send
      const emailContent = html ? 
        applyEmailTemplate(html, subject) : text;

      // Log the email sending
      await logEmailSend({
        user_id: user.id,
        recipient_email: to,
        subject,
        type,
        metadata
      });
        
      return new Response(
        JSON.stringify({ 
          success: true, 
          message: "Email sent successfully", 
          id: crypto.randomUUID()
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
  } catch (error) {
    console.error("Error in send-email function:", error);
    
    return new Response(
      JSON.stringify({ error: "Internal Server Error", details: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

// Function to generate HTML email with template
function applyEmailTemplate(htmlContent: string, subject: string): string {
  return `<!DOCTYPE html>
  <html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>${subject}</title>
    <style>
      body { 
        font-family: Arial, sans-serif; 
        line-height: 1.6;
        color: #333;
        margin: 0;
        padding: 0;
      }
      .container {
        width: 100%;
        max-width: 600px;
        margin: 0 auto;
        padding: 20px;
      }
      .header {
        background-color: #1A1F2C;
        color: white;
        padding: 20px;
        text-align: center;
      }
      .logo {
        max-width: 150px;
        margin-bottom: 10px;
      }
      .content {
        padding: 20px;
        background-color: #ffffff;
      }
      .footer {
        text-align: center;
        padding: 20px;
        font-size: 12px;
        color: #666;
        background-color: #f5f5f5;
      }
      .button {
        display: inline-block;
        background-color: #9b87f5;
        color: #ffffff;
        padding: 12px 24px;
        text-decoration: none;
        border-radius: 4px;
        font-weight: bold;
        margin: 20px 0;
      }
    </style>
  </head>
  <body>
    <div class="container">
      <div class="header">
        <h1>Astrus CMS</h1>
        <p>Legal Case Management System</p>
      </div>
      <div class="content">
        ${htmlContent}
      </div>
      <div class="footer">
        <p>&copy; ${new Date().getFullYear()} Astrus CMS. All rights reserved.</p>
        <p>This email was sent from Astrus CMS, your legal case management system.</p>
      </div>
    </div>
  </body>
  </html>`;
}

// Function to generate calendar invite email
function generateCalendarEmail({ 
  recipient, 
  event 
}: { 
  recipient: { email: string; full_name?: string; id?: string };
  event: { 
    title: string; 
    start: string; 
    end: string; 
    description?: string;
    location?: string;
    id: string;
    eventType?: string;
  };
}): string {
  const name = recipient.full_name || recipient.email.split('@')[0];
  const eventDate = new Date(event.start).toLocaleDateString('en-US', { 
    weekday: 'long',
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });
  
  const startTime = new Date(event.start).toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true
  });
  
  const endTime = new Date(event.end).toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true
  });
  
  const html = `
    <h2>Calendar Invitation: ${event.title}</h2>
    <p>Hello ${name},</p>
    <p>You have been invited to the following event:</p>
    <div style="margin: 20px 0; padding: 15px; border-left: 4px solid #9b87f5; background-color: #f8f9fa;">
      <p><strong>Event:</strong> ${event.title}</p>
      <p><strong>Date:</strong> ${eventDate}</p>
      <p><strong>Time:</strong> ${startTime} to ${endTime}</p>
      ${event.location ? `<p><strong>Location:</strong> ${event.location}</p>` : ''}
      ${event.description ? `<p><strong>Description:</strong> ${event.description}</p>` : ''}
      ${event.eventType ? `<p><strong>Type:</strong> ${event.eventType}</p>` : ''}
    </div>
    <p>This event has been added to your Astrus CMS calendar.</p>
    <a href="#" style="display: inline-block; background-color: #9b87f5; color: #ffffff; padding: 12px 24px; text-decoration: none; border-radius: 4px; font-weight: bold; margin: 20px 0;">View in Calendar</a>
  `;
  
  return applyEmailTemplate(html, `Calendar: ${event.title}`);
}

// Function to log email send attempts to the database
async function logEmailSend({ 
  user_id, 
  recipient_email, 
  subject,
  type = 'notification',
  metadata = {}
}: { 
  user_id: string; 
  recipient_email: string; 
  subject: string;
  type?: string;
  metadata?: Record<string, any>;
}): Promise<void> {
  try {
    const { error } = await supabaseClient
      .from('email_logs')
      .insert({
        recipient_email,
        sender_email: "notifications@astruscms.com",
        subject,
        type,
        status: 'sent',
        metadata,
        sent_by: user_id
      });
    
    if (error) {
      console.error("Error logging email send:", error);
    }
  } catch (err) {
    console.error("Exception logging email send:", err);
  }
}
