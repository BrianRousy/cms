
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.40.0"

// Define CORS headers for browser requests
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
}

// Supabase client for the Edge Function
const supabaseClient = createClient(
  Deno.env.get("SUPABASE_URL") ?? "",
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
)

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    // Get the authorization header to verify user is logged in
    const authHeader = req.headers.get('Authorization');
    
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: "Not authorized" }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Extract JWT token from Authorization header
    const token = authHeader.replace('Bearer ', '');
    
    // Verify the JWT token
    const { data: { user }, error: authError } = await supabaseClient.auth.getUser(token);
    
    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: "Invalid token", details: authError }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Parse the URL to get the entry ID if present
    const url = new URL(req.url);
    const pathParts = url.pathname.split('/');
    const entryId = pathParts[pathParts.length - 1];

    // Extract body content if present
    let bodyContent = {};
    if (req.method !== 'GET' && req.method !== 'DELETE') {
      bodyContent = await req.json();
    }
    
    // Handle different HTTP methods
    if (req.method === 'POST') {
      // Create a new time entry
      const { 
        case_id, 
        case_name, 
        task_id, 
        task_name, 
        description, 
        start_time, 
        end_time, 
        duration,
        billable,
        billable_amount,
        status
      } = bodyContent as any;
      
      const { data, error } = await supabaseClient.from('time_entries').insert({
        case_id,
        case_name,
        task_id,
        task_name,
        description,
        start_time,
        end_time: end_time || null,
        duration: duration || null,
        billable: billable || true,
        billable_amount: billable_amount || null,
        user_id: user.id,
        status: status || 'active'
      }).select().single();
      
      if (error) {
        return new Response(
          JSON.stringify({ error: "Failed to create time entry", details: error }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      
      return new Response(
        JSON.stringify({ data }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
    else if (req.method === 'PUT' && entryId) {
      // Update an existing time entry
      const updates = bodyContent as any;
      
      const { data, error } = await supabaseClient.from('time_entries')
        .update({
          ...updates,
          updated_at: new Date().toISOString()
        })
        .eq('id', entryId)
        .select()
        .single();
      
      if (error) {
        return new Response(
          JSON.stringify({ error: "Failed to update time entry", details: error }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      
      return new Response(
        JSON.stringify({ data }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
    else if (req.method === 'GET' && entryId) {
      // Get a specific time entry by ID
      const { data, error } = await supabaseClient.from('time_entries')
        .select('*')
        .eq('id', entryId)
        .single();
      
      if (error) {
        return new Response(
          JSON.stringify({ error: "Time entry not found", details: error }),
          { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      
      return new Response(
        JSON.stringify({ data }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
    else if (req.method === 'DELETE' && entryId) {
      // Delete a time entry
      const { error } = await supabaseClient.from('time_entries')
        .delete()
        .eq('id', entryId);
      
      if (error) {
        return new Response(
          JSON.stringify({ error: "Failed to delete time entry", details: error }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      
      return new Response(
        JSON.stringify({ success: true, message: "Time entry deleted successfully" }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
    else if (req.method === 'GET') {
      // Get all time entries or filtered by query params
      const searchParams = url.searchParams;
      const startDate = searchParams.get('start_date') || bodyContent?.start_date;
      const endDate = searchParams.get('end_date') || bodyContent?.end_date;
      const caseId = searchParams.get('case_id') || bodyContent?.case_id;
      const status = searchParams.get('status') || bodyContent?.status;
      
      let query = supabaseClient.from('time_entries').select('*');
      
      // Add filters if present
      if (startDate) {
        query = query.gte('start_time', startDate);
      }
      
      if (endDate) {
        query = query.lte('start_time', endDate);
      }
      
      if (caseId) {
        query = query.eq('case_id', caseId);
      }
      
      if (status) {
        query = query.eq('status', status);
      }
      
      // Always filter by user ID for security
      query = query.eq('user_id', user.id);
      
      // Execute the query
      const { data, error } = await query.order('start_time', { ascending: false });
      
      if (error) {
        console.error("Query error:", error);
        return new Response(
          JSON.stringify({ error: "Failed to get time entries", details: error }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      
      return new Response(
        JSON.stringify({ data }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
    else {
      return new Response(
        JSON.stringify({ error: "Invalid method or missing parameters" }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
  } catch (error) {
    console.error("Error in time-entry function:", error);
    
    return new Response(
      JSON.stringify({ error: "Internal Server Error", details: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
})
