
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.40.0"

// Define CORS headers for browser requests
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

// Supabase client for the Edge Function
const supabaseClient = createClient(
  Deno.env.get("SUPABASE_URL") ?? "",
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
)

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    // Get the authorization header to verify user is logged in
    const authHeader = req.headers.get('Authorization');
    
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: "Not authorized" }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Extract JWT token from Authorization header
    const token = authHeader.replace('Bearer ', '');
    
    // Verify the JWT token
    const { data: { user }, error: authError } = await supabaseClient.auth.getUser(token);
    
    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: "Invalid token", details: authError }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Parse the URL and query parameters
    const url = new URL(req.url);
    const searchParams = url.searchParams;
    
    // Get filter parameters if any
    const status = searchParams.get('status');
    const practice_area = searchParams.get('practice_area');
    const search = searchParams.get('search');
    const priority = searchParams.get('priority');
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');
    
    console.log("Fetching cases with filters:", { status, practice_area, search, priority });
    
    // Build the query with filters
    let query = supabaseClient.from('cases').select('*');
    
    if (status) {
      query = query.eq('status', status);
    }
    
    if (practice_area) {
      query = query.eq('practice_area', practice_area);
    }
    
    if (priority) {
      query = query.eq('priority', priority);
    }
    
    if (search) {
      query = query.or(`title.ilike.%${search}%,case_number.ilike.%${search}%,client_name.ilike.%${search}%`);
    }
    
    // Add pagination
    query = query.range(offset, offset + limit - 1).order('created_at', { ascending: false });
    
    // Execute the query
    const { data: cases, error: queryError } = await query;
    
    if (queryError) {
      console.error("Database query error:", queryError);
      return new Response(
        JSON.stringify({ error: "Database query failed", details: queryError }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
    
    console.log(`Retrieved ${cases?.length} cases with filters:`, { status, practice_area, search, priority });
    
    // Return filtered cases
    return new Response(
      JSON.stringify({ data: cases }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
    
  } catch (error) {
    console.error("Error in get-cases function:", error);
    
    return new Response(
      JSON.stringify({ error: "Internal Server Error", details: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
})
