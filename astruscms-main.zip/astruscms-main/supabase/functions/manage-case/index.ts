
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.40.0"

// Define CORS headers for browser requests
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
}

// Supabase client for the Edge Function
const supabaseClient = createClient(
  Deno.env.get("SUPABASE_URL") ?? "",
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
)

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    // Get the authorization header to verify user is logged in
    const authHeader = req.headers.get('Authorization');
    
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: "Not authorized" }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Extract JWT token from Authorization header
    const token = authHeader.replace('Bearer ', '');
    
    // Verify the JWT token
    const { data: { user }, error: authError } = await supabaseClient.auth.getUser(token);
    
    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: "Invalid token", details: authError }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Parse the URL to get the case ID if present
    const url = new URL(req.url);
    const pathParts = url.pathname.split('/');
    const caseId = pathParts[pathParts.length - 1];
    
    // Handle different HTTP methods
    if (req.method === 'POST') {
      // Create a new case
      const { title, case_number, description, client_name, client_email, status, priority, practice_area, due_date, next_court_date } = await req.json();
      
      console.log("Creating new case:", { title, case_number, client_name });
      
      const { data, error } = await supabaseClient.from('cases').insert({
        title,
        case_number,
        description,
        client_name,
        client_email,
        status: status || 'open',
        priority: priority || 'medium',
        practice_area,
        due_date: due_date || null,
        next_court_date: next_court_date || null,
        assigned_attorney: user.id,
        creator_id: user.id,
        progress: 0
      }).select().single();
      
      if (error) {
        console.error("Error creating case:", error);
        return new Response(
          JSON.stringify({ error: "Failed to create case", details: error }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      
      console.log("Case created successfully:", data);
      
      return new Response(
        JSON.stringify({ data }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
    else if (req.method === 'PUT' && caseId) {
      // Update an existing case
      const updates = await req.json();
      
      console.log(`Updating case ${caseId}:`, updates);
      
      const { data, error } = await supabaseClient.from('cases')
        .update({
          ...updates,
          updated_at: new Date().toISOString()
        })
        .eq('id', caseId)
        .select()
        .single();
      
      if (error) {
        console.error("Error updating case:", error);
        return new Response(
          JSON.stringify({ error: "Failed to update case", details: error }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      
      console.log("Case updated successfully:", data);
      
      return new Response(
        JSON.stringify({ data }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
    else if (req.method === 'GET' && caseId) {
      // Get a specific case by ID
      console.log(`Fetching case with ID: ${caseId}`);
      
      const { data, error } = await supabaseClient.from('cases')
        .select('*')
        .eq('id', caseId)
        .single();
      
      if (error) {
        console.error("Error fetching case:", error);
        return new Response(
          JSON.stringify({ error: "Case not found", details: error }),
          { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      
      console.log("Case fetched successfully:", data);
      
      return new Response(
        JSON.stringify({ data }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
    else if (req.method === 'DELETE' && caseId) {
      // Delete a case
      console.log(`Deleting case with ID: ${caseId}`);
      
      const { error } = await supabaseClient.from('cases')
        .delete()
        .eq('id', caseId);
      
      if (error) {
        console.error("Error deleting case:", error);
        return new Response(
          JSON.stringify({ error: "Failed to delete case", details: error }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      
      console.log(`Case ${caseId} deleted successfully`);
      
      return new Response(
        JSON.stringify({ success: true, message: "Case deleted successfully" }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
    else {
      return new Response(
        JSON.stringify({ error: "Invalid method or missing case ID" }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
  } catch (error) {
    console.error("Error in manage-case function:", error);
    
    return new Response(
      JSON.stringify({ error: "Internal Server Error", details: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
})
