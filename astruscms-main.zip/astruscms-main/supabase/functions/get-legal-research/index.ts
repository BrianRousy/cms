
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.40.0"

// Define CORS headers for browser requests
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

// Supabase client for the Edge Function
const supabaseClient = createClient(
  Deno.env.get("SUPABASE_URL") ?? "",
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
)

// Mock research results
const researchResults = [
  {
    id: 1,
    title: "Smith v. Johnson",
    citation: "123 F.3d 456 (9th Cir. 2022)",
    snippet: "The court held that the defendant's actions constituted negligence under the state law's standard of care for professionals...",
    jurisdiction: "Federal",
    date: "2022-05-15",
    relevance: 92,
    source: "Westlaw",
    type: "Case",
    saved: false
  },
  {
    id: 2,
    title: "Reynolds v. ABC Corporation",
    citation: "234 Cal.App.4th 789 (2021)",
    snippet: "In considering the application of the business judgment rule, the court determined that directors are protected when making good faith decisions...",
    jurisdiction: "California",
    date: "2021-11-03",
    relevance: 88,
    source: "LexisNexis",
    type: "Case",
    saved: false
  },
  {
    id: 3,
    title: "Contract Breach: Elements and Remedies",
    citation: "Harvard Law Review, Vol. 135",
    snippet: "This article examines the evolving standards for establishing breach of contract claims in commercial litigation and explores the available remedies...",
    jurisdiction: "N/A",
    date: "2023-02-18",
    relevance: 85,
    source: "HeinOnline",
    type: "Article",
    saved: false
  },
  {
    id: 4,
    title: "Thompson v. City of Springfield",
    citation: "345 Mass. 567 (2020)",
    snippet: "The Supreme Judicial Court clarified the standard for municipal liability in cases involving alleged police misconduct...",
    jurisdiction: "Massachusetts",
    date: "2020-07-22",
    relevance: 79,
    source: "Westlaw",
    type: "Case",
    saved: false
  },
  {
    id: 5,
    title: "Corporate Governance Act of 2021",
    citation: "Pub. L. No. 117-52, 135 Stat. 124",
    snippet: "Section 4(a)(3) imposes new reporting requirements for corporate boards regarding diversity and environmental impact...",
    jurisdiction: "Federal",
    date: "2021-09-30",
    relevance: 76,
    source: "Government Publishing Office",
    type: "Statute",
    saved: false
  },
  {
    id: 6,
    title: "Fiduciary Duty in Corporate Law",
    citation: "Stanford Law Review, Vol. 68",
    snippet: "This comprehensive analysis explores the evolving standards of fiduciary duties among corporate directors and officers...",
    jurisdiction: "N/A",
    date: "2022-10-18",
    relevance: 74,
    source: "HeinOnline",
    type: "Article",
    saved: false
  },
  {
    id: 7,
    title: "Williams v. Healthcare Partners",
    citation: "567 F.4th 890 (2nd Cir. 2023)",
    snippet: "The court established a new standard for medical malpractice claims involving corporate healthcare providers...",
    jurisdiction: "Federal",
    date: "2023-01-12",
    relevance: 72,
    source: "Westlaw",
    type: "Case",
    saved: false
  },
  {
    id: 8,
    title: "Data Privacy Protection Act",
    citation: "Pub. L. No. 118-23, 136 Stat. 210",
    snippet: "The legislation creates comprehensive data protection requirements for businesses handling consumer information...",
    jurisdiction: "Federal",
    date: "2022-11-15",
    relevance: 68,
    source: "Government Publishing Office",
    type: "Statute",
    saved: false
  }
];

// Mock recent searches
const recentSearches = [
  { id: 1, query: "breach of contract damages", date: "2024-04-10", count: 42 },
  { id: 2, query: "corporate negligence standards", date: "2024-04-08", count: 28 },
  { id: 3, query: "intellectual property infringement", date: "2024-04-05", count: 35 },
  { id: 4, query: "employment discrimination evidence", date: "2024-04-01", count: 23 },
  { id: 5, query: "class action certification requirements", date: "2024-03-28", count: 31 }
];

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const endpoint = url.pathname.split('/').pop();

    if (endpoint === 'history') {
      // Return search history
      return new Response(
        JSON.stringify({ data: recentSearches }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    } else {
      // Default - return search results with optional filtering
      const searchParams = url.searchParams;
      const query = searchParams.get('q');
      const jurisdiction = searchParams.get('jurisdiction');
      const type = searchParams.get('type');
      const source = searchParams.get('source');
      
      // Apply filters if provided
      let results = [...researchResults];
      
      if (query) {
        const queryLower = query.toLowerCase();
        results = results.filter(r => 
          r.title.toLowerCase().includes(queryLower) || 
          r.snippet.toLowerCase().includes(queryLower) ||
          r.citation.toLowerCase().includes(queryLower)
        );
      }
      
      if (jurisdiction) {
        results = results.filter(r => r.jurisdiction === jurisdiction);
      }
      
      if (type) {
        results = results.filter(r => r.type === type);
      }
      
      if (source) {
        results = results.filter(r => r.source === source);
      }
      
      console.log(`Retrieved ${results.length} research results with filters:`, { query, jurisdiction, type, source });
      
      return new Response(
        JSON.stringify({ data: results }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
  } catch (error) {
    console.error("Error in get-legal-research function:", error);
    
    return new Response(
      JSON.stringify({ error: "Internal Server Error", details: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
})
